﻿
/* LOOT BY ДикиЙ */

    

 
stop_winner_animate = false;


function getRandomArbitary(min, max)
{
  return Math.random() * (max - min) + min;
}




 
  function updateloots() {
	 
	  $.ajax( "/getloot/"+GAME ).done(function(data) {
				
				var gaminf = data;
				
				 if(gaminf.status == "0" & gameEnd == false) {
					 
					 	  $.ajax( "/getlootuser/"+GAME ).done(function(data) {
$('.wineinfs').text(gaminf.maxuser-gaminf.users);
	$('.mez').text(data.mez);
			$('#gusersgi').text(gaminf.users);
			
      $('.ticket-'+data.to+' a').attr('lot-empty','false');
					$('.ticket-'+data.to+' img').attr('src', data.avatar);		
				$('.ticket-'+data.to+' a').attr('href', 'http://steamcommunity.com/profiles/'+data.steamid64);
				
				})
					}
				
  if(gaminf.status == "1" & gameEnd == false) {
	  gameEnd = true;
						EndGameFunc(gaminf);
						// $.ajax( "/resetloottest" ).done(function(data) {});
					}
	
	
	});
	  
  }
setInterval(function() {
	if(gameEnd) return;
	updateloots();
	
	}, 3000);

	function EndGameFunc(data) {
		var timeout = start_winner_animate(data.winner_id);
	//start_winner_animate(data.winner_id);
	setTimeout(function(){
		//console.log('стоп');
						stop_winner_animate = true;
						$('#offgamess').html('<form action="https://api.random.org/verify" method="post" target="_blank"><input type="hidden" name="format" value="json" /> <input type="hidden" name="random" value="'+data.randomorg_result+'" /><input type="hidden" name="signature" value="'+data.randomorg_sign+'" /> <button type="submit" style="margin-left: 64px; float: left; padding: 5px; color: white; background: #73b95e;border: 0;" style="margin-top: -30px;" class="btn btn-white btn-sm btn-right">Проверить</button></form>');
						$('.wineinf').text(data.winner);
						$('.gusers2').text(data.winner);
						
						$.ajax( "/newloot" ).done(function(data) {});
						}, timeout + 4200);
	
	}
	
	function start_winner_animate(win_ticket)
{
	var audio = new Audio();
	audio.src = '/assets/sounds/game_start.mp3';
	audio.autoplay = true;
	$('.ticket-'+win_ticket).removeClass('not_animated');
	setTimeout(function(){
		var interval = setInterval(function(){
			var tickets = $('.ticket.not_animated');
			if(tickets.length > 0 && !stop_winner_animate)
			{
				var random_int = getRandomArbitary(0, tickets.length - 1).toFixed();
				var ticket_number = tickets[random_int].getAttribute('data-place');

				$('.ticket-'+ticket_number).removeClass('not_animated');
				$('.ticket-'+ticket_number).animate({
					opacity:0.3
				}, 300);
			}
			else
			{
				clearInterval(interval);
				$('.ticket').css('opacity', 0.3);
				$('.ticket').removeClass('not_animated');
				$('.ticket-'+win_ticket).css('opacity', 1);
			}
		},100);
	}, 1000);
	return $('.ticket').length * 100;
}
	




/* LOOT BY ДикиЙ */