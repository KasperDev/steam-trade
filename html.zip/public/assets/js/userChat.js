function load_chat_messages(){
	$.ajax({
					type : "GET",
					url  : "/chat",
					dataType : "json",
					cache : false,
					success : function(message){
							
						if(message && message.length > 0){
							$('#chat_messages').html('');
							message = message.reverse();
							for(var i in message){

								var item = '	<div class="message">';
			item += '	<div class="top-mess" style="tex-decoration: none">';
			if(message[i].admin == 1){item += '<div class="chat_avatar"><img src="'+message[i].avatar+'" alt="" title="" /></div>';
					item += '<a href="#admin" style="color: #c73f3f; text-decoration: none;">'+message[i].username+'</a>';}else {
					item += '<div class="chat_avatar"><img src="'+message[i].avatar+'" alt="" title="" /></div>';
					item += '<a href="/user/'+message[i].userid+'" data-profile="'+message[i].userid+'" style="color: #2594aa; text-decoration: none; margin-top:1px;" >'+message[i].username+'</a>:';}
					item += '<span></span>';
			item += '	</div>';
				item += '<div class="text">'+message[i].messages+'</div>';
		item += '	</div>';
			
					
					
					
				$('#chat_messages').append(item);
				}
				}
				document.getElementById('chat_messages').scrollTop = document.getElementById('chat_messages').scrollHeight;
						setTimeout(function(){load_chat_messages();},1000);
						
						
				//		setTimeout(function () {$chat_messages.scrollTop($chat_messages[0].scrollHeight - $chat_messages[0].clientHeight);},1000);
					}
	});
}

function add_otvet(e){inner=$(".chat textarea").val(),$(".chat textarea").val(inner+" "+e+" "),$(".chat textarea").focus()}
function add_smile(e){inner=$(".chat textarea").val(),$(".chat textarea").val(inner+" "+e+" "),$(".chat textarea").focus()}

$(document).ready(function(){
	load_chat_messages();
	
		$('.chat input[type="submit"]').on('click',function(event){
			if(typeof window.chat_user != undefined){
				var current_message = $('.chat textarea').val();
				
				var send_data = {
					user_message : current_message
				};
				$('.chat textarea').val('');
				if(send_data.user_message.length > 0 && send_data.user_message.replace(/golucky|html|script|src|scr|frame|gojackpot|starlucky|shop|skinarena|raffle|csgoup|goshuffle|gameluck|casino|goskins/gi,"***").length > 0){
						$.ajax({
							type : "POST",
							url : "/add_message?messages="+current_message,
							data : send_data,
							dataType : "json",
							cache : false,
							success : function(message){
								
								if(message && message.error) alert(message.error);
								if(message && message.clear)  $.notify(message.clear, {className :"error"});
								$('.chat textarea').val('');
								$('.chat textarea').text('');
							},
        error: function() {
            $.notify("Ваше сообщение отправлено", {className :"success"});
        }
						});
					}
			}
			return event.preventDefault();
		});
	
            
		$('#sendie').on('keyup',function(event){
			if(typeof window.chat_user != undefined){
				if(event.keyCode == 13){
					var current_message = $(this).val();

					var send_data = {
						user_message : current_message
					};
					$('#sendie').val('');
					console.log(send_data.user_message.replace(/golucky|html|script|src|scr|frame|gojackpot|starlucky|shop|skinarena|raffle|csgoup|goshuffle|gameluck|casino|goskins/gi,"***"),send_data.user_message.replace(/golucky|html|script|src|scr|frame|gojackpot|starlucky|shop|skinarena|raffle|csgoup|goshuffle|gameluck|casino|goskins/gi,"***").length,send_data.user_message.length);
					if(send_data.user_message.length > 0 && send_data.user_message.replace(/golucky|html|script|src|scr|frame|gojackpot|starlucky|shop|skinarena|raffle|csgoup|goshuffle|gameluck|casino|goskins/gi,"***").length > 0){
						$.ajax({
							type : "POST",
							url : "/add_message?messages="+current_message,
							data : send_data,
							dataType : "json",
							cache : false,
							success : function(message){
								if(message && message.error) alert(message.error);
								if(message && message.clear)  $.notify(message.clear, {className :"error"});
								$('#sendie').val('');
								$('#sendie').text('');
							},
        error: function() {
            $.notify("Ваше сообщение отправлено", {className :"success"});
        }
						});
					}
				}
			}else alert('Вы должны быть авторизованы');
			return false;
		});
});