


$(document).ready(function() {
    $('.historys .short .top ul li a').each(function(){
        $(this).text(replaceLogin($(this).text()));
    });
	
	$('.leftbar .main-game .short .top ul li a').each(function(){
        $(this).text(replaceLogin($(this).text()));
    });

	$('.leftbar .end-game .bottom-game .us-win span').each(function(){
        $(this).text(replaceLogin($(this).text()));
    });
	
	$('.table .list .tb3 a').each(function(){
        $(this).text(replaceLogin($(this).text()));
    });
	
	$('.rightbar .chat .message .top-mess a').each(function(){
        $(this).text(replaceLogin($(this).text()));
    });
	
    FASTLOOT.init();
    $('[data-modal]').click(function() {
        $($(this).data('modal')).arcticmodal();
        return false;
    });

    $('.no-link').click(function () {
        $('.linkMsg').removeClass('msgs-not-visible');
        return false;
    });

    $('.offer-link input, .offer-link-inMsg input')
        .keypress(function(e) {
            if (e.which == 13) $(this).next().click()
        })
        .on('paste', function() {
            var that = $(this);
            setTimeout( function() {
                that.next().click();
            }, 0);
        });

    $('.save-link, .save-link2').click(function () {
        var that = $(this).prev();
        $.ajax({
            url: '/settings/save',
            type: 'POST',
            dataType: 'json',
            data: {trade_link: $(this).prev().val()},
            success: function (data) {
                if (data.status == 'success') {
                    that.notify(data.msg, {position: 'left middle', className :"success"});
                    $('.no-link').attr('href', '/deposit').removeClass('.no-auth').off('click');
                    $('.linkMsg').addClass('msgs-not-visible');
                }
                else {
                    if(data.msg) that.notify(data.msg, {position: 'left middle', className :"error"});
                }
            },
            error: function () {
                that.notify("Произошла ошибка. Попробуйте еще раз", {position: 'left middle', className :"error"});
            }
        });
        return false;
    });


    $(document).on('click', '#checkHash', function () {
        var hash = $('#roundHash1').val();
        var number = $('#roundNumber1').val() || '';
        var bank = $('#roundPrice1').val() || 0;
        var result = $('#checkResult');
        if (hex_md5(number) == hash) {
            var n = Math.floor(bank * parseFloat(number));
            result.html('<center>Хэш Раунда и Число Раунда верны.<br/> ПОБЕДНЫЙ БИЛЕТ - ' + n+'</center>');
        }
        else {
            result.html('<center>Хэш Раунда и Число Раунда не совпадают.</center>');
        }
    });
});

function getRarity(type) {
    var rarity = '';
    var arr = type.split(',');
    if (arr.length == 2) type = arr[1].trim();
    if (arr.length == 3) type = arr[2].trim();
    if (arr.length && arr[0] == 'Нож') type = '★';
    switch (type) {
        case 'Армейское качество':      rarity = 'milspec'; break;
        case 'Запрещенное':             rarity = 'restricted'; break;
        case 'Засекреченное':           rarity = 'classified'; break;
        case 'Тайное':                  rarity = 'covert'; break;
        case 'Ширпотреб':               rarity = 'common'; break;
        case 'Промышленное качество':   rarity = 'common'; break;
        case '★':                       rarity = 'rare'; break;
        case 'card':                    rarity = 'card'; break;
    }
    return rarity;
}

function n2w(n, w) {
    n %= 100;
    if (n > 19) n %= 10;

    switch (n) {
        case 1: return w[0];
        case 2:case 3:case 4: return w[1];
        default: return w[2];
    }
}
function lpad(str, length) {
    while (str.toString().length < length)
        str = '0' + str;
    return str;
}

function replaceLogin(login) {
    var reg = new RegExp(BANNED_DOMAINS, 'i');
    return login.replace(reg, "");
}



if (START) {
    var socket = io.connect('46.30.43.216:7777', {secure: true});
    socket
        .on('connect', function () {
            $('#loader').hide();
        })
        .on('disconnect', function () {
            $('#loader').show();
        })
		.on('online', function(data){
			$("#online").html(data);
			   })
        .on('newDeposit', function(data){
			
            data = JSON.parse(data);
            $('#bets').prepend(data.html);
            var username = $('#bet_'+ data.id +' .short .user .username').text();
            $('#bet_'+ data.id +' .short .user .username').text(replaceLogin(username));
            $('#roundBank').text(Math.round(data.gamePrice)+' руб.');
            $('#progressbar-value').attr('original-title', data.itemsCount + n2w(data.itemsCount, [' предмет', ' предмета', ' предметов']));
            $('#progressbar-value').css('width', data.itemsCount*2 + '%');
			 html_chances = '';
			 data.chances = sortByChance(data.chances);
            data.chances.forEach(function(info){
                if(USER_ID == info.steamid64){
                    $('#myItems').text(info.items + n2w(info.items, [' предмет', ' предмета', ' предметов']));
                    $('#myChance').text(info.chance);
                    $('.myDepositButton').addClass('big').text('Внести еще предметов');
                }
                $('.chance_' + info.steamid64).text('('+ info.chance +' %)');
            html_chances +=
			  '<div class="block"><div class="chance">' + info.chance + '%</div><img src="' + info.avatar + '" alt="" title="" /></div>';
			

            });
		
                $('#game-chances').removeClass('hidden');
               $('#game-chances').html(html_chances);
				$('.leftbar .main-game .short .top ul li a').each(function(){
        $(this).text(replaceLogin($(this).text()));
    });

			$(document).ready(function () {
	
 $('.itemd').tipsy({gravity: 'n'}); 
 $('.line').tipsy({gravity: 'n'}); 
 $('#south').tipsy({gravity: 's'}); 
 $('#user_title_link').tipsy({gravity: 's'}); 
 $('#east').tipsy({gravity: 'e'}); 
 $('#west').tipsy({gravity: 'w'}); 
 }); 
 
 
 function getRandomArbitary(min, max)
{
	return Math.random() * (max - min) + min;
}

 function newBet () {
	 
	var stavka  = new Audio();
	stavka.src = '/assets/sounds/Stavka-' + Math.round(getRandomArbitary(1,3)) + '.mp3';
	stavka.volume = 0.4;
	stavka.play();

}
	if (sounds == 'on') 
					{
                    newBet();

                    }

			
			
			
            FASTLOOT.initTheme();
        })
     
        .on('forceClose', function () {
            $('.forceClose').removeClass('msgs-not-visible');
        })
        .on('timer', function (time) {
            if(timerStatus) {
               // console.log(time);
                timerStatus = false;
                $('.gameEndTimer').empty().removeClass('not-active').countdown({seconds: time});
            }
        })
        .on('slider', function (data) {
            if(ngtimerStatus) {
                ngtimerStatus = false;
                $('.forceClose').addClass('msgs-not-visible');
              //  console.log(data);
                var users = data.users;
                users = mulAndShuffle(users, Math.ceil(110 / users.length));
				users[6] = data.winner;
                users[100] = data.winner;
                html = '';
                users.forEach(function (i) {
                    html += '<li><img src="' + i.avatar + '"></li>';
                });

               
				
					$('#timersik').addClass('hidden');
				$('#timersik2').removeClass('hidden');
				 $('.ngtimer').empty().countdown({seconds: data.time});
				 
				 $('.leftbar .total-game .bottom-inf .right a').html('Внести депозит первым');

                $('.current-round .game-progress').addClass('hidden');
                $('.current-round .details-wrap').addClass('hidden');
                $('#gameCarousel').removeClass('hidden');

                $('.roulette1').html(html);
                $('#winner-cost-value').text(data.game.price);
                $('#winner-ticket').html('???');
	
                $('#winner-ticketall').text('');
                $('#winner-name').html('???');
                $('#winner-name u').text('');
                $('.roulette1').removeClass('active');

                if(data.showSlider) {
                    setTimeout(function () {
                        $('.roulette1').addClass('active');
	
                    }, 500);
                }
                var timeout = data.showSlider ? 13 : 0;
                setTimeout(function () {
                    $('#roundNumber').text(data.round_number);
                    $('.gameEnd.current-round').removeClass('msgs-not-visible');

                    $('#winner-ticket').text('#' + data.ticket);
                   // $('#winner-ticketall').text('(ВСЕГО: ' + data.tickets + ')');
                    $('#winner-name').html('<a data-profile="' + data.winner.steamid64 + '" href="#"></a>');
                    $('#winner-name a').text(replaceLogin(data.winner.username));
                    $('#winner-name u').text('(' + data.chance + '%)');

                    $.post('/getBalance', function (data) {
                        $('.update_balance').text(data);
                    });

                }, 1000 * timeout);
            }
        })
		
		 .on('lastwinner', function (data) {
			 $('#winidrest').html('<a data-profile="'+data.steamid64+'" href="#">'+data.username+'</a>');
			 $('#winmoner').html('Выигрыш: '+data.price+' руб.');
			 $('#winchancet').html('Шанс: '+data.percent+'%');
			 
			 $('#winavatar').html('<img src="'+data.avatar+'" alt="" title="" />');
			     })
        .on('newGame', function (data) {
			 function  newgame () {
	 
	 var  newgames  = new Audio();
	 newgames.src = '/assets/sounds/game-start.mp3';
	 newgames.volume = 0.4;
	 newgames.play();

}
	if (sounds == 'on') 
					{
                    newgame();
					}
						$('#game-chances').addClass('hidden');
			 $('.leftbar .total-game .bottom-inf .right a').html('Внести депозит');
					$('#timersik2').addClass('hidden');
				$('#timersik').removeClass('hidden');
            $('.gameEnd.current-round').addClass('msgs-not-visible');
            $('.current-round .game-progress').removeClass('hidden');
            $('.current-round .details-wrap').removeClass('hidden');
            $('#gameCarousel').addClass('hidden');
            $('.roulette1').removeClass('active');
            $('#bets').html('');
            $('#myItems').text('0 предметов');
            $('#myChance').text(0);
            $('.myDepositButton').removeClass('big').text('Внести предметы');
            $('#roundId').text(data.id);
            $('#roundBank').text(0+' руб.');
			
            $('#roundHash').text(data.hash);
             $('#progressbar-value').attr('original-title', '0');
            $('#progressbar-value').css('width','0%');
            $('.gameEndTimer').addClass('not-active');
            timerStatus = true;
            ngtimerStatus = true;
        })
        .on('queue', function (data) {
          //  console.log(data);
            if (data) {
                var n = data.indexOf(USER_ID);
                if (n !== -1) {
                    $('#vinvoc').text('Ваш депозит обрабатывается. Вы '+(n + 1)+' в очереди.');
                    $('.queueMsg').removeClass('hidden');
                }
                else {
                    $('.queueMsg').addClass('hidden');
                }
            }
        })
        .on('depositDecline', function (data) {
            data = JSON.parse(data);
            if (data.user == USER_ID) {
                clearTimeout(declineTimeout);
                declineTimeout = setTimeout(function() {
                    $('.declineMsg').addClass('hidden');
                }, 1000 * 10)
                $('#tradelinkser').text(data.msg);
                $('.queueMsg').addClass('hidden');
                $('.declineMsg').removeClass('hidden');
            }
        })
    var declineTimeout,
        timerStatus = true,
        ngtimerStatus = true;
}

function loadMyInventory() {
    $('#tbodymyinv').hide();
    $.ajax({
        url: '/myinventory',
        type: 'POST',
        dataType: 'json',
        success: function (data) {
            var text = '<tr><td colspan="4" style="text-align: center">Произошла ошибка. Попробуйте еще раз</td></tr>';
            var totalPrice = 0;

            if (!data.success && data.Error) text = '<tr><td colspan="4" style="text-align: center">'+data.Error+'</td></tr>';

            if (data.success && data.rgInventory && data.rgDescriptions) {
                text = '';
                var items = mergeWithDescriptions(data.rgInventory, data.rgDescriptions);
             //   console.table(items);
                items.sort(function(a, b) { return parseFloat(b.price) - parseFloat(a.price) });
                _.each(items, function(item) {
                    item.price = item.price || 0;
                    totalPrice += parseFloat(item.price);
                    item.price = item.price;
                    item.image = 'https://steamcommunity-a.akamaihd.net/economy/image/class/730/'+item.classid+'/30fx30f';
                    item.market_name = item.market_name || '';
                    text += ''
					 +'<div class="list">'
			 +'<div class="tb1">'+'<img style=" margin: 0px 30px 0px 40px;    width: 30px; height: 30px;" src="'+item.image+'">'+'</div>'
				 +'<div style=" width: 54%; " class="tb2 ' + getRarity(item.type) + '">'+item.name+' </div>'
				// +'<div class="tb2">'+item.market_name.replace(item.name,'').replace('(','').replace(')','')+'</div>'
				 +'<div class="tb3">'+(item.price || '---')+'</div>'
			 +'</div>'
					
					
                 
                });
                $('#totalPrice').text(totalPrice.toFixed(2) );
                $('#tbodymyinv').show();
            }

            $('#tbodymyinv').html('<div class="list"><div class="tb1" style=" width: 15%; ">Картинка</div><div class="tb2"  style=" width: 45%; ">Название</div><div class="tb3" style=" width: 39%; ">Цена (РУБ)</div></div>'+text);
        },
        error: function () {
            $('#tbodymyinv').html('<tr><td colspan="4" style="text-align: center">Произошла ошибка. Попробуйте еще раз<td></tr>');
        }
    });
}

function mergeWithDescriptions(items, descriptions) {
    return Object.keys(items).map(function(id) {
        var item = items[id];
        var description = descriptions[item.classid + '_' + (item.instanceid || '0')];
        for (var key in description) {
            item[key] = description[key];

            delete item['icon_url'];
            delete item['icon_drag_url'];
            delete item['icon_url_large'];
        }
        return item;
    })
}

function mulAndShuffle(arr, k) {
    var
        res = [],
        len = arr.length,
        total = k * len,
        rand, prev;
    while (total) {
        rand = arr[Math.floor(Math.random() * len)];
        if (len == 1) {
            res.push(prev = rand);
            total--;
        }
        else if (rand !== prev) {
            res.push(prev = rand);
            total--;
        }
    }
    return res;
}

$(document).on('click', '.rank-edit', function() {
    var that = $(this);
    $.ajax({
        url: '/ajax',
        type: 'POST',
        dataType: 'json',
        data: { action: 'voteUser', id: $(this).data('profile') },
        success: function(data) {
            if (data.status == 'success') {
                $('.rank').find('#reputatd').text(data.votes || 0);
            }
            else {
                if (data.msg) that.notify(data.msg, {position: 'bottom middle', className :"error"});
            }
        },
        error: function() {
            that.notify("Произошла ошибка. Попробуйте еще раз", {position: 'bottom middle', className :"error"});
        }
    });
});
$(document).ready(function(){
$(document).on('click', '[data-profile]', function() {

	//console.log('тест');
   var modal = $('#myProfile');
    modal.find('.loading').show();
    modal.find('.clearfix').hide();
    modal.arcticmodal();

    var id = $(this).data('profile');
    $.ajax({
        url: '/ajax',
        type: 'POST',
        dataType: 'json',
        data: { action: 'userInfo', id: id },
        success: function(data) {
            modal.find('#profilename').text(replaceLogin(data.username));
            modal.find('#pgames').text(data.games);
            modal.find('#pwinsn').text(data.wins);
            modal.find('#pwinrate').text(data.winrate + '%');
            modal.find('#ptotalBank').text(data.totalBank + ' руб.');
            modal.find('#reputatd').text(data.votes || 0);
            modal.find('#pprofile').attr('href', data.url).text(data.url);
            modal.find('img').attr('src', data.avatar);

            var html = '';
            data.list.forEach(function(game) {
				
				 html += '	<div class="list">';
			 html += '	<div>#'+game.id+'</div>';
				 html += '<div>'+ game.chance + '%' +'</div>';
				 html += '<div>'+ game.bank +' руб.</div>';
				 if (game.win == -1) html += '<div>Не завершена</div>';
                else if (game.win) html += '<div>Победа</div>';
                else html += '<div>Проигрыш</div>';
				html+='</div>';
		
				
             
            });

            modal.find('#history-p').html(html);

            modal.find('.rank-edit').data('profile', id);

            modal.find('.loading').hide();
            modal.find('.clearfix').show();

            if (modal.find('.games-list').is('.ps-container')) modal.find('.games-list').perfectScrollbar('destroy');
            modal.find('.games-list').perfectScrollbar();
        },
        error: function() {
            $.notify("Произошла ошибка. Попробуйте еще раз", {className :"error"});
        }
    });
    return false;
});
});

  jQuery(document).ready(function(){
			   jQuery('body').append("<div class='scrolltotop'><div class='scrolltotop__side'></div><div class='scrolltotop__arrow'></div></div>");
          jQuery(window).scroll(function(){
            if (jQuery(this).scrollTop() > 350) {
                   jQuery('.scrolltotop').fadeIn();
            } else {
                   jQuery('.scrolltotop').fadeOut();
            }
        });
           jQuery('.scrolltotop').click(function(){
              jQuery("html, body").animate({ scrollTop: 0 }, 50);
            return false;
        });
    });
$(document).ready(function () {
	
 $('.itemd').tipsy({gravity: 'n'}); 
 $('.line').tipsy({gravity: 'n'}); 
 $('#south').tipsy({gravity: 's'}); 
$('.js-progress-bar').tipsy({gravity: 's'}); 
 $('.giveaway_subject').tipsy({gravity: 'n'}); 
 $('#user_title_link').tipsy({gravity: 's'}); 
 $('#east').tipsy({gravity: 'e'}); 
 $('#west').tipsy({gravity: 'w'}); 
 }); 
 

	 
	 
	 
/* CHAT start */	 
$(document).ready(function () {


$('.chat > a').click(function (e) {
$(this).toggleClass('active');
$('.chat > .sub').toggle(0);
e.stopPropagation();
});

$('.chat').click(function (e) {
e.stopPropagation();
});

$('html').click(function () {
var link = $('.chat > a');
if (link.hasClass('active')) {
link.click();
}
});

$('.smiles > a').click(function (e) {
$(this).toggleClass('active');
$('.smiles > .sub').toggle(0);
e.stopPropagation();
});

$('.smiles').click(function (e) {
e.stopPropagation();
});

$('html').click(function () {
var link = $('.smiles > a');
if (link.hasClass('active')) {
link.click();
}
});

});
/* CHAT stop */	 


/* SOUNDS start */	 
	var sounds = $.cookie('sounds');
	if (sounds == 'on') {

  $('#otkrm').addClass('hidden');
  $('#zakrm').removeClass('hidden');

	} else {
	
  
  $('#otkrm').removeClass('hidden');
  $('#zakrm').addClass('hidden');

	}


	$(document).on('click', '#otkrm', function(e) {
		e.preventDefault();

    
  $('#otkrm').addClass('hidden');
  $('#zakrm').removeClass('hidden');


         sounds = 'on';
        $.cookie('sounds', 'on', { expires: 365 });
	});

	$(document).on('click', '#zakrm', function(e) {
		e.preventDefault();

  $('#otkrm').removeClass('hidden');
  $('#zakrm').addClass('hidden');

		 sounds = 'off';
        $.cookie('sounds', 'off', { expires: 365 });
	});
/* SOUNDS stop */	 
	 
	 
	 
	 
	 
	 
function sortByChance(arrayPtr){
    var temp = [],
        item = 0;
    for (var counter = 0; counter < arrayPtr.length; counter++)
    {
        temp = arrayPtr[counter];
        item = counter-1;
        while(item >= 0 && arrayPtr[item].chance < temp.chance)
        {
            arrayPtr[item + 1] = arrayPtr[item];
            arrayPtr[item] = temp;
            item--;
        }
    }
    return arrayPtr;
}



function reloadinfo(){$.ajax({type:"POST",url:"/online",success:function(e){}})}setInterval("reloadinfo()", 2500)

function setPlace(number){
		
		$.ajax({
					type : "POST",
					url  : "/addplaceloot",
        dataType: 'json',
        data: { game_id: GAME, place:number },
					success : function(resultss){
						
						
						

 
		var r = resultss.reason;
	//	console.log(r);
		if(r=="ok") {
			$('.wineinfs').text(parseInt($('.wineinfs').text())-1);
			$('.mez').text(parseInt($('.mez').text())+1);
			$('#gusersgi').text(parseInt($('#gusersgi').text())+1);
					$('.ticket-'+number+' img').attr('src', avatar);
			
			
			$.notify("Вы купили билет №"+number+"", {className :"success"});

		}
		else if(r=="placetime") {
			
			$.notify("Подождите...", {className :"error"});
			
				  
		}
		else if(r=="placexm") {
			
			$.notify("Данный билет уже куплен", {className :"error"});
			
				  
		}
		else if(r=="nomoney") {
			
			
				$.notify("Нехватает денег, пополните баланс", {className :"error"});
			
			
	  	}

        }
    });

  }
  
  $.fn.random = function() {
          return this.eq(Math.floor(Math.random() * this.length));
        }
  
  
     $("#add_to_giveaway").click(function(){



        var lot = $("[lot-empty=\'true\']").random();
	
        setPlace(lot.attr("lot-idx"));
    })

   
    $('.addtollot[lot-empty="true"]').click(function(){
        setPlace($(this).attr("lot-idx"));
    })