$(function() {
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });
    window.realList = [];
    window.realListObj = {};
    window.ITEM = {};

    window.itemsHolder = $('#items-list');
    var exterior_all = [
        ['Прямо с завода'	    ,	'Прямо с завода'],
        ['Немного поношенное'	,	'Немного поношенное'],
        ['После полевых испытаний'	,	'После полевых испытаний'],
        ['Поношенное'	        ,	'Поношенное'],
        ['Закаленное в боях'	,	'Закаленное в боях'],
        ['Не покрашено'	        ,	'Не покрашено'],
        [''				        ,	'']
    ];

    var rarity_all = [
        ['Ширпотреб'		,	'Ширпотреб'],
        ['Армейское качество'		,	'Армейское качество'],
        ['Промышленное качество'	,	'Промышленное качество'],
        ['Запрещенное'	,	'Запрещенное'],
        ['Засекреченное'	,	'Засекреченное'],
        ['Тайное'	,	'Тайное']
    ];

    var type_all = [
        ['Пистолет'				,	'Пистолет'],
        ['Пистолет-пулемёт'				,	'Пистолет-пулемёт'],
        ['Винтовка'				,	'Винтовка'],
        ['Дробовик'			,	'Дробовик'],
        ['Снайперская'		,	'Снайперская винтовка'],
        ['Пулемёт'			,	'Пулемёт'],
        ['Нож'				,	'Нож'],
        ['Контейнер'			,	'Контейнер'],
        ['Наклейка'			,	'Наклейка'],
        ['Набор музыки'			,	'Набор музыки'],
        ['Ключ'	,	'Ключ'],
        ['Пропуск'				,	'Пропуск'],
        ['Подарок'			,	'Подарок'],
        ['Ярлык'		,	'Ярлык'],
        ['Инструмент'				,	'Инструмент']
    ];

window.setupSelects = function() {
        type_all.forEach(function(filter) {
            if (filter[0] == 'NONE') return;
            $('#type_all').append('<option value="'+filter[0]+'">'+filter[1]+'</option>');
        });
        rarity_all.forEach(function(filter) {
            if (filter[0] == 'NONE') return;
            $('#rarity_all').append('<option value="'+filter[0]+'">'+filter[1]+'</option>');
        });
        exterior_all.forEach(function(filter) {
            if (filter[0] == 'NONE') return;
            $('#exterior_all').append('<option value="'+filter[0]+'">'+filter[1]+'</option>');
        });

    $('select')
        .show()
        .select2({
            placeholder: "Все",
            tags: true
        })
        .on("change", function(evt) {
        });
    $('.select2-search__field').attr('readonly', true);
    $('.select2-container .select2-selection').append('<span class="add-tag"></span>');

    setupScroller();
};
window.setupScroller = function() {
    var boxHeight = $(window).height() - 163;
    $('.sorting-items-container').height(boxHeight + 'px');
    $(".nano").nanoScroller({ alwaysVisible: true });

    $('.filter-container').height(boxHeight + 'px');

    //$("img.lazy").lazy({
    //    bind: "event",
    //    appendScroll: $(".nano-content")
    //});
};
window.setupSlider = function(max) {
    
   

 document.getElementById('priceFrom'), document.getElementById('priceTo');
    
};
    var timer1;
    window.getSortedItems = function(){
        options.minPrice = parseInt($('#priceFrom').val()) || 0;
        options.maxPrice = parseInt($('#priceTo').val()) || 10e10;
        $.post('/ajax', {action:'shopSort',options:options}, function(items){
            var html = '';
            items.forEach(function(item){
                html += '<div class="short">\
				<div class="picture"><img src="https://steamcommunity-a.akamaihd.net/economy/image/class/730/'+item.classid+'/76fx76f" alt="" title="" /></div>\
				<ul>\
					<li>'+item.name+'</li>\
					<li>'+item.quality+'</li>\
					<span>'+item.rarity+'</span>\
					<li>Цена в Steam: <span>'+item.steam_price+' руб.</span></li>\
					<!--<li><a href="#">Посмотреть в игре</a></li>-->\
				</ul>\
				<div class="right">\
					'+Math.floor(item.price)+' <span>руб.</span>\
					<a  class="by buyItem" data-item="'+item.id+'">Купить</a>\
				</div>\
			</div>\
			<div class="popup_block store-pop" id="popup_name-'+item.id+'">\
	<div class="title">Подтверждение покупки</div>\
	<div class="picture"><img src="item-4.png" alt="" title="" /></div>\
	<ul>\
		<li>'+item.name+'</li>\
		<li>Внешний вид: тайное</li>\
		<li>Качество: '+item.quality+'</li>\
		<li>Цена в Steam: '+item.steam_price+' руб.</li>\
		<li>Наша цена: '+Math.floor(item.price)+' руб.</li>\
	</ul>\
	<div class="clear"></div>\
	<a href="#"  id="buyItem" data-item="'+item.id+'" class="buy">Продолжить</a>\
</div>'




				//'+Math.floor(item.price)+'
            })
            $('#items-list').html(html);
            $('#countItems span').text(items.length);
            $('#countItems').show();
            initBuy();
        });
    }

    window.initBuy =    function(){
        $('.buyItem').click(function () {
            var that = $(this);
            $.ajax({
                url: '/shop/buy',
                type: 'POST',
                dataType: 'json',
                data: {id: $(this).data('item')},
            success: function (data) {
                if (data.success) {
					
                    $.notify(data.msg, {position: 'bottom right', className: "success"});
                    setTimeout(function () {
                        that.parent().parent().parent().hide()
					
                    }, 5500);
                }
                else {
                    if (data.msg) $.notify(data.msg, {position: 'bottom right', className: "error"});
                }
            },
            error: function () {
                that.notify("Произошла ошибка. Попробуйте еще раз", {
                    position: 'bottom middle',
                    className: "error"
                });
            }
        });
        return false;
    });
}

});
