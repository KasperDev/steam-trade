@extends('layout')

@section('content')
	<link href="{{ asset('assets/css/support.css') }}" rel="stylesheet">
	<script type="text/javascript">
    $(document).ready(function() {
		$(".newticket").click(function () {
			$(".support .table").hide();
			$(".support .nticket").show();
		});
		
		$(".listticket").click(function () {
			$(".support .table").show();
			$(".support .nticket").hide();
		});
		
	});
</script>
<div class="content">
	<!-- <middle> -->
	<div class="other-title">Тема сообщения</div>

	<div class="support">
	

	
	<div class="fticket">Данный тикет закрыт, новое сообщение откроет его заново	</div>
	
	<div class="sticket">
		<div class="suticket">
	<div class="avatar">
	<img src="/adm-ava.png" alt=" "="" title="">
	</div>	
	<div class="tfe">
	<div class="time">20:11</div>
<div class="title" style="color:red;">Администратор</div>
<div class="msg">Здравствуйте! где я могу получить свои вещи?</div>
	</div>		</div>
	<div class="suticket">
	<div class="avatar">
	<img src="https://steamcdn-a.akamaihd.net/steamcommunity/public/images/avatars/be/be903b0ad7e2c3aa2103b7de5a9eac6f46f06179_full.jpg" alt=" "="" title="">
	</div>	
	<div class="tfe">
	<div class="time">20:11</div>
<div class="title">Ник</div>
<div class="msg">Здравствуйте! где я могу получить свои вещи?</div>
	</div>		</div>
	<div class="newtif">
		<textarea type="text" name="" value="" placeholder="Введите ваше сообщение..." autocomplete="off"></textarea>
	<input type="submit" name="" value="Отправить">
	<span class="infsff">Ваша заявка ожидает ответа от технической поддержки. Пожалуйста, не дублируйте письма повторно мы ответим вам в течение 24 часов.</span>
	
	</div>	</div>

	</div>

</div>

@endsection