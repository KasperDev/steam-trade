@extends('layout')

@section('content')
	<link href="{{ asset('assets/css/support.css') }}" rel="stylesheet">
	<script type="text/javascript">
    $(document).ready(function() {
		$(".newticket").click(function () {
			$(".support .table").hide();
			$(".support .nticket").show();
		});
		
		$(".listticket").click(function () {
			$(".support .table").show();
			$(".support .nticket").hide();
		});
		
	});
</script>
<div class="content">
	<!-- <middle> -->
	<div class="other-title">Поддержка</div>

	<div class="support">
	
	
	<div class="newticket"><span class="ntitle">Создать новый запрос</span><span class="nabout">Написать новое сообщение 
в техническую поддержку</span></div>
	<div class="listticket"><span class="ntitle">Список тикетов</span><span class="nabout">Здесь вы сможете лицезреть
список всех ваших обращений</span></div>


<div class="table">
<div class="list">
				<div class="tb1">ID</div>
				<div class="tb2">Тема</div>
				<div class="tb3">Проблема</div>
				<div class="tb4">Статус</div>
			</div>
		   @forelse($tickets as $ticket)
			<div class="list">
				<div class="tb1"><a href="/support/{{$ticket->id}}">#{{$ticket->id}}</a></div>
				<div class="tb2"><a href="/support/{{$ticket->id}}">{{$ticket->title}}</a></div>
				<div class="tb3">{{$ticket->about}}</div>
				<div class="tb4">@if($ticket->status == 0) Открытый @else Закрытый @endif</div>
			</div>

			    @empty
                <center><h1 style="color: #33BDA6;">Тикетов нету!</h1></center>
            @endforelse
	</div>

	<div class="nticket" style="display: none;">
	<form>
	<input type="text" name="" value="" placeholder="Тема обращения" autocomplete="off">
	<input type="text" name="" value="" placeholder="Напишите причину" autocomplete="off">
	<textarea type="text" name="" value="" placeholder="Опишите вашу проблему" autocomplete="off"></textarea>
	<input type="submit" name="" value="Создать заявку">
		</form>
	</div>
	
</div>

</div>

@endsection