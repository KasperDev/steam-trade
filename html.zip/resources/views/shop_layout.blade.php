
<!doctype html>

<html class="no-js">
<head>

    <meta charset="utf-8" />
    <meta http-equiv="x-ua-compatible" content="ie=edge" />
    <title>CSGO-LIFE.COM - Luck is on your side!</title>
    <meta name="keywords" content="csgo джекпот,csgo jackpot , Luck is on your side ,Удача на вашей стороне,cs go рулетка,рулетка кс го ,cs go рулетка от 1 рубля,рулетка кс го ,рулетка cs go, csgo джекпот ,csgo jackpot ,jackpot ,steam,cs steam ,раздачи ,конкурсы ,рулетка скинов ,скины, cs go скины ,ставки рулетка ,cs:go, cs go ставки,рулетка вещей, cs go рулетка оружий ,cs go рулетка ,cs go играть рулетка ,скинов cs go лотерея ,сsgo лотерея вещей сsgo" />
    <meta name="description" content="CSGO-LIFE.COM - Испытай свою удачу!" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta name="csrf-token" content="{!!  csrf_token()   !!}">

   <link rel="shortcut icon" href="favicon.png" />
    <link href="{{ asset('assets/css/animate.css') }}" rel="stylesheet">
    <link href="{{ asset('assets/css/jquery-ui.min.css') }}" rel="stylesheet">
    <link href="{{ asset('assets/css/normalize.css') }}" rel="stylesheet">
    <link href="{{ asset('assets/css/styles.css') }}" rel="stylesheet"> 
	<link href="{{ asset('assets/css/fonts.css') }}" rel="stylesheet">

	<script src="{{ asset('assets/shop/js/app.js') }}"></script>
    <script src="{{ asset('assets/shop/js/main1.js') }}"></script>
    <script src="{{ asset('assets/shop/js/main2.js') }}"></script>
	    <script src="{{ asset('assets/js/jquery-ui.min.js') }}" ></script>
    <script src="{{ asset('assets/js/bootstrap.min.js') }}" ></script>

	
	 <script>
    @if(!Auth::guest())
	<?php if($u->ban == 1) { die(include('/var/www/resources/views/errors/404.blade.php'));} ?>	
	var avatar = '{{ $u->avatar }}';
        const USER_ID = '{{ $u->steamid64 }}';

    @endif
        var START = true;
    </script>
</head>

    <div id="loader" class="corner">
        <div class="loader-inner ball-clip-rotate-multiple blue-loader">
            <div></div><div></div>
        </div>
    </div>
	


	
	
	<div class="notific queueMsg hidden">
	<div class="title">Системное уведомление</div>
	<div class="hint"><div>?</div></div>
	<div class="clear"></div>
	<div class="text">Подождите, ваш запрос обрабатывается</br><span id="vinvoc"></span></div>
</div>

<div class="notific declineMsg hidden">
	<div class="title">Системное уведомление</div>
	<div class="hint"><div>?</div></div>
	<div class="clear"></div>
	<div class="text">Ваше предложение обмена отклонено</br><span id="tradelinkser"></span></div>
</div>

<span id="country" hidden>{{ \App\Game::strana() }}</span>

<header>

	<div class="top">
		<div class="width">

			<a href="/" class="logotype"></a>

			
			<nav class="navbar navbar-default border-nav clearfix">
                <div class="navTop-left">
                    <div style="height: 44px;">

                        <ul class="nav navbar-nav navbar-right" style="float: left; margin-top: 22px;">
                            <li><a class="ajax" href="/top">Топ</a></li>
                            <li><a class="ajax" href="/history">История игр</a></li>
                            <li><a class="ajax" href="/about">О сайте</a></li>
                            <!-- <li><a data-modal="#fairplay" style="color: #D5DA94" href="#fairplay">Честная игра</a></li> -->
                            <li><a data-modal="#support" href="#">Поддержка</a></li>
                            <li><a href="/shop" onclick="$.notify('Магазин в разработке!'); return false;" style="color: #D5DA94">Магазин</a></li>
                        </ul>

                    </div>
                </div>
                <div class="profile-block clearfix">
                    @if(Auth::guest())
                        <a href="{{ route('login') }}" class="login-link loginbox"></a>
                    @else
                        <div class="profile-block-header">
                            <div class="profile-block-img">
                                <img src="{{ $u->avatar }}">
                            </div>
                            <a href="/logout" class="logout-link">Выйти</a>
                            <div class="profile-block-username">{{ $u->username }}</div>
                            <div class="profile-block-links">
                                <ul>
                                    <li><a href="#" data-profile="{{ $u->steamid64 }}">Профиль</a></li>
                                    <li><a href="/myhistory">Мои игры</a></li>
                                    <li><a href="/myinventory">Инвентарь</a></li>
                                </ul>
                            </div>
                            <div class="offer-link">
                                <div class="input-group">
                                    <input placeholder="Вставьте ссылку на обмен..." value="{{ $u->trade_link }}" type="text">
                                    <button type="submit" class="input-group-addon save-link"></button>
                                </div>
                            </div>
                        </div>
                    @endif
                </div>
            </nav>
			<div class="clear"></div>
		</div>
	</div>



	     @yield('content')
		 
		 
	<!-- <middle> -->
</div>


<div class="content">

	<div class="other-title">Магазин скинов</div>

	<div class="store">

		<div class="top-sort">
		  @if(Auth::guest())
		

			
			     @else
					 
				 
				 
					 			<div class="balance">Баланс: <span class="update_balance">{{ $u->money }}</span> руб.</div>
			<a href="#?w=628" rel="popup_name-7" class="poplight refill">Пополнить</a>
				 
				    @endif
			<input type="text" id="searchInput" name="" placeholder="">
			<input type="submit" name="" value="Искать">
			<a href="/shop/history" class="to-sort">Мои Покупки</a>
		</div>

		<div class="bot-sort">

			<div class="sum">
				<div>Цена от</div> <input type="text" id="priceFrom" value="" placeholder="0">
				<div>до</div> <input type="text" id="priceTo" value="" placeholder="0">
				<div>руб.</div>
			</div>

			<div class="selects">
				  <select multiple="multiple" style="display: none" id="type_all">
                        </select>
				
		   <select multiple="multiple" style="display: none"  id="exterior_all">
                        </select>
				
			      <select multiple="multiple" style="display: none" id="rarity_all">
                        </select>
			</div>

		</div>

		<div class="store-items" id="items-list">
 @forelse(\App\Shop::where('status', \App\Shop::ITEM_STATUS_FOR_SALE)->get() as $item)
			<div class="short">
				<div class="picture"><img src="https://steamcommunity-a.akamaihd.net/economy/image/class/{{ \App\Http\Controllers\GameController::APPID }}/{{ $item->classid }}/76fx76f" alt="" title="" /></div>
				<ul>
					<li>{{ $item->name }}</li>
					<li>{{ $item->quality }} </li>
					<span>{{ $item->rarity }}</span>
					<li>Цена в Steam: <span>{{ $item->steam_price }} руб.</span></li>
					<!--<li><a href="#">Посмотреть в игре</a></li>-->
				</ul>
				<div class="right">
					{{ floor($item->price) }} <span>руб.</span>
					<span class="by buyItem" data-item="{{ $item->id }}">Купить</span>
				</div>
			</div>
			
			
	<!-- </middle> -->


			    @empty
                                    <div id="empty-msg" style="text-align: center">Пока что вещей нет</div>
                            @endforelse






		</div>










	</div>


<script>

    var options = {
        maxPrice : {{ ($max_price = \App\Shop::where('status', \App\Shop::ITEM_STATUS_FOR_SALE)->max('price')) ? $max_price : $max_price = 1}},
        minPrice : 0,
        searchName : $('#searchInput').val(),
     searchType : null,
            searchRarity: null,
            searchQuality: null,

        sort: 'desc'
    }, timer;
    function changeSort(btn, sort){
        if(options.sort != sort){
            $('#navbar-sort li').removeClass('active');
            $(btn).addClass('active');
            options.sort = sort;
        }
        clearTimeout(timer);
        timer = setTimeout(getSortedItems, 100);
    }

    $(function() {
        initBuy();
        setupSelects();
         setupSlider({{ $max_price }});


        $('#type_all').change(function () {
            options.searchType = $(this).val();
            clearTimeout(timer);
            timer = setTimeout(getSortedItems, 100);
            console.log(options);
        })
        $('#rarity_all').change(function () {
            options.searchRarity = $(this).val();
            clearTimeout(timer);
            timer = setTimeout(getSortedItems, 100);
            console.log(options);
        })
        $('#exterior_all').change(function () {
            options.searchQuality = $(this).val();
            clearTimeout(timer);
            timer = setTimeout(getSortedItems, 100);
            console.log(options);
        })

        $('#searchInput').keyup(function () {
            options.searchName = $(this).val();
            clearTimeout(timer);
            timer = setTimeout(getSortedItems, 100);
            console.log(options);
        })

        $('#priceTo').change(function () {
            options.maxPrice = $(this).val();
            clearTimeout(timer);
            timer = setTimeout(getSortedItems, 100);
        })
        $('#priceFrom').change(function () {
            options.minPrice = $(this).val();
            clearTimeout(timer);
            timer = setTimeout(getSortedItems, 100);
        })

   });
</script>


<!-- modals-start -->
    <div style="display: none;">
        <div id="myProfile" class="itemmodal" style=" width: 550px;">
		  
<div class="popup_block" style="display: block;position: relative      ;top: 0%;      left: 0%;">
           <div class="title">Профиль игрока: <span id="profilename"></span></div>
		   	<div class="rank">
		<div class="number" id="reputatd"></div>
		<div class="rank-edit"></div>
	</div>
	<div class="avatar"><img src="" alt="" title="" /></div>
	<div class="name" id="profilename"></div>
	<a class="link" id="pprofile" target="_blank">http://steamcommunity.com/id/user</a>
	<div class="stat">
		<div><span id="pgames"></span>игр</div>
		<div><span id="pwinsn"></span>побед</div>
		<div><span id="pwinrate"></span>уровень</div>
		<div><span id="ptotalBank"></span>в банке</div>
	</div>
	<div class="history-p">
		<div class="subtop">
			<div>Игра</div>
			<div>Шанс</div>
			<div>Джекпот</div>
			<div>Статус</div>
		</div>
		<div class="scroll" id="history-p">
		
		
			
		</div>
	</div>
	</div>
        </div>
    </div>
    <!-- modals-end -->

                     
                    @if(Auth::guest())
                       
                    @else
			
		
		
		<div class="popup_block" id="popup_name-5">
	<div class="title">Настройки профиля</div>
	<div class="text">Вам необходимо подтвердить ссылку на обмен и сохранить все параметры, нажав на кнопку “сохранить”.</div>
	<div class="url-input">
		<input type="text" id="trade" name="" value="{{ $u->trade_link }}" placeholder="Введите ссылку на обмен...">
		<input type="submit" name="" value="Сохранить" class=" save-link2">
	</div>
	<a href="http://steamcommunity.com/id/me/tradeoffers/privacy#trade_offer_access_url" target="_blank" class="get-link">Где взять ссылку?</a>
</div>

	
<div class="popup_block" id="popup_name-7">
	<div class="title">Карточки</div>
	<!--<div class="total-cards">У вас 10 карточек, стоимостью в 6580 руб.</div>
	<div class="info-cards">У вас нету карточек для депозита.<br>Купите карточки, чтобы сделать депозит.</div>-->
	<div class="balance">
			<form method="GET" action="/pay">
			<input type="hidden" name="user_id" value="{{ $u->id }}">
			<div class="bal-text">Баланс: <span class="update_balance">{{ $u->money }}</span> руб.</div>
			<input type="text" name="sum" placeholder="Введите сумму">
			<input type="submit" name="" value="Пополнить">
		</form>
	</div>
    
	
	
	<div class="buy-cards">
	 @foreach(\App\Ticket::all() as $ticket)
		<div class="ez-card">
			<div class="price">{{ $ticket->price }}р.</div>
			<span class="buy"  onclick="addTicket({{ $ticket->id }}, this)">Купить</span>
		</div>

		   @endforeach
	</div>
	<div class="quest-cards">
		<div>ДЛЯ ЧЕГО НУЖНЫ КАРТОЧКИ?</div>Вы сможете вносить депoзит карточками, вместо предметов. Карточки моментально вносится в раунд без задержек. Карточки не теряются в стоимости и вы сможете поменять их в любой момент на предметы в нашем магазине <span>FastLoot.Me</span>.
	</div>
</div>
	
   @endif

   
   