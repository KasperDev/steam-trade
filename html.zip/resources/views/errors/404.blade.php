
<!doctype html>
<html class="no-js" lang="ru">
<head>
    <meta charset="utf-8" />
    <meta http-equiv="x-ua-compatible" content="ie=edge" />
    <title>CSGO-LIFE.COM - Luck is on your side!</title>
    <meta name="keywords" content="csgo джекпот,csgo jackpot" />
    <meta name="description" content="CSGO-LIFE.COM - Luck is on your side!" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta name="csrf-token" content="4uNMjuSPgFdi8ZAe3icfLb90fdm36uLZwLSkaWd9">
   <link rel="shortcut icon" href="favicon.png" />
    <link href="http://csgo-life.com/assets/css/animate.css" rel="stylesheet">
    <link href="http://csgo-life.com/assets/css/jquery-ui.min.css" rel="stylesheet">
    <link href="http://csgo-life.com/assets/css/normalize.css" rel="stylesheet">
    <link href="http://csgo-life.com/assets/css/styles.css" rel="stylesheet"> 
	<link href="http://csgo-life.com/assets/css/fonts.css" rel="stylesheet">
    <script src="http://csgo-life.com/assets/js/inc.js" ></script>
    <script src="http://csgo-life.com/assets/js/modals.js" ></script>
    <script src="http://csgo-life.com/assets/js/main.js" ></script>
    <script src="http://csgo-life.com/assets/js/jquery-ui.min.js" ></script>
    <script src="http://csgo-life.com/assets/js/bootstrap.min.js" ></script>
	  <script src="http://csgo-life.com/assets/js/jquery-tipsy.js" ></script>
  <script src="http://csgo-life.com/assets/js/SmoothScroll.js" ></script>
<script src="http://csgo-life.com/assets/js/modal.js" ></script>
<script src="http://csgo-life.com/assets/js/jquery.cookie.js" ></script>
   <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

    <div id="loader" class="corner">
        <div class="loader-inner ball-clip-rotate-multiple blue-loader">
            <div></div><div></div>
        </div>
    </div>
	


	
	
	<div class="notific queueMsg hidden">
	<div class="title">Системное уведомление</div>
	<div class="hint"><div>?</div></div>
	<div class="clear"></div>
	<div class="text">Подождите, ваш запрос обрабатывается</br><span id="vinvoc"></span></div>
</div>

<div class="notific declineMsg hidden">
	<div class="title">Системное уведомление</div>
	<div class="hint"><div>?</div></div>
	<div class="clear"></div>
	<div class="text">Ваше предложение обмена отклонено</br><span id="tradelinkser"></span></div>
</div>

   

<header>

	<div class="top">
		<div class="width">

			<a href="/" class="logotype"></a>

			<nav class="navbar navbar-default border-nav clearfix">
                <div class="navTop-left">
                    <div style="height: 44px;">

                        <ul class="nav navbar-nav navbar-right" style="float: left; margin-top: 22px;">
                            <li><a class="ajax" href="/top">Топ</a></li>
                            <li><a class="ajax" href="/history">История игр</a></li>
                            <li><a class="ajax" href="/about">О сайте</a></li>
                            <!-- <li><a data-modal="#fairplay" style="color: #D5DA94" href="#fairplay">Честная игра</a></li> -->
                            <li><a data-modal="#support" href="#">Поддержка</a></li>
                            <li><a href="/shop" style="color: #D5DA94">Магазин</a></li>
                        </ul>

                    </div>
                </div>
            </nav>
			 
   			<div class="clear"></div>
		</div>
	</div>



	     <div class="content">
	<!-- <middle> -->
	<div class="other-title">Информация</div>

	<div class="about">
			<center>Произошла ошибка при переходе на данную страницу </center>
	</div>
</div>

		 
		 
	<!-- <middle> -->
</div>




<div class="popup_block" id="popup_name">
	<div class="title">Внести предметы в текущую игру</div>
	<div class="text">Выберите способ внесения предмета, вы можете внести предмет через клиент или браузер.</div>
	<div class="button">
		<a href="http://csgo-life.com/deposit" target="_blank">B</a>
		Браузер
	</div>
	<div class="txt">или</div>
	<div class="button">
	<a href="steam://url/SteamIDPage/76561198208391193" target="_blank">S</a>
		Клиент
		
	</div>
</div>



<div class="popup_block" id="popup_name5">
	<div class="title">Смайлы</div>
		<div id="emoji_box" class="scroll">
		<div class="emoji_scroll_wrap">				
		<div id="emoji_list" style="top: 0px;">
<div class="smileadd itemk over">
<img src="/assets/images/chat/white.gif" style="background-position: 0px 0px" id="smile" onclick="add_smile(':)')"><br>	
</div>
<div class="smileadd itemk over">
<img src="/assets/images/chat/white.gif" style="background-position: 0px -17px" id="smile" onclick="add_smile(':-d')"><br>	
</div>
<div class="smileadd itemk over">
<img src="/assets/images/chat/white.gif" style="background-position: 0px -34px" id="smile" onclick="add_smile(';-)')"><br>	
</div>
<div class="smileadd itemk over">
<img src="/assets/images/chat/white.gif" style="background-position: 0px -51px" id="smile" onclick="add_smile('xd')"><br>	
</div>
<div class="smileadd itemk over">
<img src="/assets/images/chat/white.gif" style="background-position: 0px -68px" id="smile" onclick="add_smile(';-p')"><br>	
</div>
<div class="smileadd itemk over">
<img src="/assets/images/chat/white.gif" style="background-position: 0px -85px" id="smile" onclick="add_smile(':-p')"><br>	
</div>
<div class="smileadd itemk over">
<img src="/assets/images/chat/white.gif" style="background-position: 0px -102px" id="smile" onclick="add_smile('8-)')"><br>	
</div>
<div class="smileadd itemk over">
<img src="/assets/images/chat/white.gif" style="background-position: 0px -119px" id="smile" onclick="add_smile('b-)')"><br>	
</div>
<div class="smileadd itemk over">
<img src="/assets/images/chat/white.gif" style="background-position: 0px -136px" id="smile" onclick="add_smile(':-(')"><br>	
</div>
<div class="smileadd itemk over">
<img src="/assets/images/chat/white.gif" style="background-position: 0px -153px" id="smile" onclick="add_smile(';-]')"><br>	
</div>
<div class="smileadd itemk over">
<img src="/assets/images/chat/white.gif" style="background-position: 0px -170px" id="smile" onclick="add_smile('u—(')"><br>	
</div>
<div class="smileadd itemk over">
<img src="/assets/images/chat/white.gif" style="background-position: 0px -187px" id="smile" onclick="add_smile(':l(')"><br>	
</div>
<div class="smileadd itemk over">
<img src="/assets/images/chat/white.gif" style="background-position: 0px -204px" id="smile" onclick="add_smile(':_(')"><br>	
</div>
<div class="smileadd itemk over">
<img src="/assets/images/chat/white.gif" style="background-position: 0px -221px" id="smile" onclick="add_smile(':((')"><br>	
</div>
<div class="smileadd itemk over">
<img src="/assets/images/chat/white.gif" style="background-position: 0px -238px" id="smile" onclick="add_smile(':o')"><br>	
</div>
<div class="smileadd itemk over">
<img src="/assets/images/chat/white.gif" style="background-position: 0px -255px" id="smile" onclick="add_smile(':|')"><br>	
</div>
<div class="smileadd itemk over">
<img src="/assets/images/chat/white.gif" style="background-position: 0px -272px" id="smile" onclick="add_smile('3-)')"><br>	
</div>
<div class="smileadd itemk over">
<img src="/assets/images/chat/white.gif" style="background-position: 0px -323px" id="smile" onclick="add_smile('o*)')"><br>	
</div>
<div class="smileadd itemk over">
<img src="/assets/images/chat/white.gif" style="background-position: 0px -340px" id="smile" onclick="add_smile(';o')"><br>	
</div>
<div class="smileadd itemk over">
<img src="/assets/images/chat/white.gif" style="background-position: 0px -374px" id="smile" onclick="add_smile('8o')"><br>	
</div>
<div class="smileadd itemk over">
<img src="/assets/images/chat/white.gif" style="background-position: 0px -357px" id="smile" onclick="add_smile('8|')"><br>	
</div>
<div class="smileadd itemk over">
<img src="/assets/images/chat/white.gif" style="background-position: 0px -391px" id="smile" onclick="add_smile(':x')"><br>	
</div>
<div class="smileadd itemk over">
<img src="/assets/images/chat/white.gif" style="background-position: 0px -442px" id="smile" onclick="add_smile('*3')"><br>	
</div>
<div class="smileadd itemk over">
<img src="/assets/images/chat/white.gif" style="background-position: 0px -409px" id="smile" onclick="add_smile(':-*')"><br>	
</div>
<div class="smileadd itemk over">
<img src="/assets/images/chat/white.gif" style="background-position: 0px -425px" id="smile" onclick="add_smile('}^)')"><br>	
</div>
<div class="smileadd itemk over">
<img src="/assets/images/chat/white.gif" style="background-position: 0px -306px" id="smile" onclick="add_smile('>((')"><br>	
</div>
<div class="smileadd itemk over">
<img src="/assets/images/chat/white.gif" style="background-position: 0px -289px" id="smile" onclick="add_smile('>(')"><br>	
</div>
<div class="smileadd itemk over">
<img src="/assets/images/chat/white.gif" style="background-position: 0px -459px" id="smile" onclick="add_smile(':like:')"><br>	
</div>
<div class="smileadd itemk over">
<img src="/assets/images/chat/white.gif" style="background-position: 0px -476px" id="smile" onclick="add_smile(':dislike:')"><br>	
</div>
<div class="smileadd itemk over">
<img src="/assets/images/chat/white.gif" style="background-position: 0px -493px" id="smile" onclick="add_smile(':u:')"><br>	
</div>
<div class="smileadd itemk over">
<img src="/assets/images/chat/white.gif" style="background-position: 0px -510px" id="smile" onclick="add_smile(':v:')"><br>	
</div>
<div class="smileadd itemk over">
<img src="/assets/images/chat/white.gif" style="background-position: 0px -527px" id="smile" onclick="add_smile(':kk:')"><br>	
</div>
<div class="smileadd itemk over">
<img src="/assets/images/chat/D83DDC4F.png"  id="smile" style="background:none;" onclick="add_smile('👏')"><br>	
</div>
<!-- смайл начало -->
<div class="smileadd itemk over">
<img src="/assets/images/chat/D83DDC4A.png"  id="smile" style="background:none;" onclick="add_smile('👊')"><br>	
</div>
<!-- смайлы конец -->
<!-- смайл начало -->
<div class="smileadd itemk over">
<img src="/assets/images/chat/270B.png"  id="smile" style="background:none;" onclick="add_smile('✋')"><br>	
</div>
<!-- смайлы конец -->
<!-- смайл начало -->
<div class="smileadd itemk over">
<img src="/assets/images/chat/D83DDE4F.png"  id="smile" style="background:none;" onclick="add_smile('🙏')"><br>	
</div>
<!-- смайлы конец -->
<!-- смайл начало -->
<div class="smileadd itemk over">
<img src="/assets/images/chat/D83DDC43.png"  id="smile" style="background:none;" onclick="add_smile('👃')"><br>	
</div>
<!-- смайлы конец -->
<!-- смайл начало -->
<div class="smileadd itemk over">
<img src="/assets/images/chat/D83DDC46.png"  id="smile" style="background:none;" onclick="add_smile('👆')"><br>	
</div>
<!-- смайлы конец -->
<!-- смайл начало -->
<div class="smileadd itemk over">
<img src="/assets/images/chat/D83DDC47.png"  id="smile" style="background:none;" onclick="add_smile('👇')"><br>	
</div>
<!-- смайлы конец -->
<!-- смайл начало -->
<div class="smileadd itemk over">
<img src="/assets/images/chat/D83DDC48.png"  id="smile" style="background:none;" onclick="add_smile('👈')"><br>	
</div>
<!-- смайлы конец -->
<!-- смайл начало -->
<div class="smileadd itemk over">
<img src="/assets/images/chat/D83DDCAA.png"  id="smile" style="background:none;" onclick="add_smile('💪')"><br>	
</div>
<!-- смайлы конец -->
<!-- смайл начало -->
<div class="smileadd itemk over">
<img src="/assets/images/chat/D83DDC42.png"  id="smile" style="background:none;" onclick="add_smile('👂')"><br>	
</div>
<!-- смайлы конец -->
<!-- смайл начало -->
<div class="smileadd itemk over">
<img src="/assets/images/chat/D83DDC8B.png"  id="smile" style="background:none;" onclick="add_smile('💋')"><br>	
</div>
<!-- смайлы конец -->
<!-- смайл начало -->
<div class="smileadd itemk over">
<img src="/assets/images/chat/D83DDCA9.png"  id="smile" style="background:none;" onclick="add_smile('💩')"><br>	
</div>
<!-- смайлы конец -->
<!-- смайл начало -->
<div class="smileadd itemk over">
<img src="/assets/images/chat/2744.png"  id="smile" style="background:none;" onclick="add_smile('❄')"><br>	
</div>
<!-- смайлы конец -->
<!-- смайл начало -->
<div class="smileadd itemk over">
<img src="/assets/images/chat/D83CDF77.png"  id="smile" style="background:none;" onclick="add_smile('🍷')"><br>	
</div>
<!-- смайлы конец -->
<!-- смайл начало -->
<div class="smileadd itemk over">
<img src="/assets/images/chat/D83CDF78.png"  id="smile" style="background:none;" onclick="add_smile('🍸')"><br>	
</div>
<!-- смайлы конец -->
<!-- смайл начало -->
<div class="smileadd itemk over">
<img src="/assets/images/chat/D83CDF85.png"  id="smile" style="background:none;" onclick="add_smile('🎅')"><br>	
</div>
<!-- смайлы конец -->
<!-- смайл начало -->
<div class="smileadd itemk over">
<img src="/assets/images/chat/D83DDCA6.png"  id="smile" style="background:none;" onclick="add_smile('💦')"><br>	
</div>
<!-- смайлы конец -->
<!-- смайл начало -->
<div class="smileadd itemk over">
<img src="/assets/images/chat/D83DDC7A.png"  id="smile" style="background:none;" onclick="add_smile('👺')"><br>	
</div>
<!-- смайлы конец -->
<!-- смайл начало -->
<div class="smileadd itemk over">
<img src="/assets/images/chat/D83DDC28.png"  id="smile" style="background:none;" onclick="add_smile('🐨')"><br>	
</div>
<!-- смайлы конец -->
<!-- смайл начало -->
<div class="smileadd itemk over">
<img src="/assets/images/chat/D83CDF4C.png"  id="smile" style="background:none;" onclick="add_smile('🍌')"><br>	
</div>
<!-- смайлы конец -->
<!-- смайл начало -->
<div class="smileadd itemk over">
<img src="/assets/images/chat/D83CDFC6.png"  id="smile" style="background:none;" onclick="add_smile('🏆')"><br>	
</div>
<!-- смайлы конец -->
<!-- смайл начало -->
<div class="smileadd itemk over">
<img src="/assets/images/chat/D83CDFB2.png"  id="smile" style="background:none;" onclick="add_smile('🎲')"><br>	
</div>
<!-- смайлы конец -->
<!-- смайл начало -->
<div class="smileadd itemk over">
<img src="/assets/images/chat/D83CDF7A.png"  id="smile" style="background:none;" onclick="add_smile('🍺')"><br>	
</div>
<!-- смайлы конец -->
<!-- смайл начало -->
<div class="smileadd itemk over">
<img src="/assets/images/chat/D83CDF7B.png"  id="smile" style="background:none;" onclick="add_smile('🍻')"><br>	
</div>
<!-- смайлы конец -->		
				
</div>
</div></div></div>

<div class="popup_block" id="popup_name-2">
	<div class="title">Внести депозит в текущую игру</div>
	<div class="text">Вы сможете вносить депозит карточками или предметами, для этого вам необходимо выбрать способ внесения. </div>
	<a href="#?w=550" rel="popup_name" class="poplight button-2 " target="_blank">Внести предметы</a>
	<div class="txt-2">или</div>
	<a href="#?w=628" rel="popup_name-7" class="button-2 poplight">Внести карточки</a>
	<div class="info">Добавление предметов происходит в течение нескольких секунд.</div>
</div>



<!-- modals-start -->
    <div style="display: none;">
        <div id="myProfile" class="itemmodal" style=" width: 550px;">
		  
<div class="popup_block" style="display: block;position: relative      ;top: 0%;      left: 0%;">
           <div class="title">Профиль игрока: <span id="profilename"></span></div>
		   	<div class="rank">
		<div class="number" id="reputatd"></div>
		<div class="rank-edit"></div>
	</div>
	<div class="avatar"><img src="" alt="" title="" /></div>
	<div class="name" id="profilename"></div>
	<div class="link" id="pprofile">http://steamcommunity.com/id/user</div>
	<div class="stat">
		<div><span id="pgames"></span>игр</div>
		<div><span id="pwinsn"></span>побед</div>
		<div><span id="pwinrate"></span>уровень</div>
		<div><span id="ptotalBank"></span>в банке</div>
	</div>
	<div class="history-p">
		<div class="subtop">
			<div>Игра</div>
			<div>Шанс</div>
			<div>Джекпот</div>
			<div>Статус</div>
		</div>
		<div class="scroll" id="history-p">
		
		
			
		</div>
	</div>
	</div>
        </div>
    </div>
    <!-- modals-end -->


  <!-- profile -->
  
	
	<div class="popup_block" id="popup_name-6">
	<div class="title">Карточки</div>
	<div class="total-cards">У вас 10 карточек, стоимостью в 6580 руб.</div>
	<div class="info-cards">В вашем профиле может быть не более 10 приобретенных карточек.<br>Это сделано для того чтобы вам было комфортнее ставить их в игру.</div>
	<div class="my-cards">
		<div class="ez-card">
			<div class="price">100 руб.</div>
			<a href="#" class="buy">Купить</a>
		</div>
		<div class="ez-card">
			<div class="price">100 руб.</div>
			<a href="#" class="buy">Купить</a>
		</div>
		<div class="ez-card">
			<div class="price">100 руб.</div>
			<a href="#" class="buy">Купить</a>
		</div>
		<div class="ez-card">
			<div class="price">100 руб.</div>
			<a href="#" class="buy">Купить</a>
		</div>
		<div class="ez-card">
			<div class="price">100 руб.</div>
			<a href="#" class="buy">Купить</a>
		</div>
		<div class="ez-card">
			<div class="price">100 руб.</div>
			<a href="#" class="buy">Купить</a>
		</div>
		<div class="ez-card">
			<div class="price">100 руб.</div>
			<a href="#" class="buy">Купить</a>
		</div>
		<div class="ez-card">
			<div class="price">100 руб.</div>
			<a href="#" class="buy">Купить</a>
		</div>
		<div class="ez-card">
			<div class="price">100 руб.</div>
			<a href="#" class="buy">Купить</a>
		</div>
		<div class="ez-card">
			<div class="price">100 руб.</div>
			<a href="#" class="buy">Купить</a>
		</div>
	</div>
</div>
	
		     			
		
		<div class="popup_block" id="popup_name-5">
	<div class="title">Настройки профиля</div>
	<div class="text">Вам необходимо подтвердить ссылку на обмен и сохранить все параметры, нажав на кнопку “сохранить”.</div>
	<div class="url-input">
		<input type="text" id="trade" name="" value="https://steamcommunity.com/tradeoffer/new/?partner=215395522&amp;token=rtSg592b" placeholder="Введите ссылку на обмен...">
		<input type="submit" name="" value="Сохранить" class=" save-link2">
	</div>
	<a href="http://steamcommunity.com/id/me/tradeoffers/privacy#trade_offer_access_url" target="_blank" class="get-link">Где взять ссылку?</a>
</div>

	
<div class="popup_block" id="popup_name-7">
	<div class="title">Карточки</div>
	<!--<div class="total-cards">У вас 10 карточек, стоимостью в 6580 руб.</div>
	<div class="info-cards">У вас нету карточек для депозита.<br>Купите карточки, чтобы сделать депозит.</div>-->
	<div class="balance">
		<form method=GET action="/pay">
			<input type="hidden" name="oa" value="17668">
			<input type="hidden" name="user_id" value="1">
			<input type="hidden" name="user_name" value="ДикиЙ [csgo-life.com]">
			<div class="bal-text">Баланс: <span class="update_balance">2250.00</span> руб.</div>
			<input type="text" name="sum" placeholder="Введите сумму">
			<input type="submit" name="" value="Пополнить">
		</form>
	</div>
    
	
	
	<div class="buy-cards">
	 		<div class="ez-card">
			<div class="price">100.00р.</div>
			<span class="buy"  onclick="addTicket(1, this)">Купить</span>
		</div>

		   		<div class="ez-card">
			<div class="price">250.00р.</div>
			<span class="buy"  onclick="addTicket(2, this)">Купить</span>
		</div>

		   		<div class="ez-card">
			<div class="price">600.00р.</div>
			<span class="buy"  onclick="addTicket(3, this)">Купить</span>
		</div>

		   		<div class="ez-card">
			<div class="price">1200.00р.</div>
			<span class="buy"  onclick="addTicket(4, this)">Купить</span>
		</div>

		   		<div class="ez-card">
			<div class="price">3500.00р.</div>
			<span class="buy"  onclick="addTicket(5, this)">Купить</span>
		</div>

		   	</div>
	<div class="quest-cards">
		<div>ДЛЯ ЧЕГО НУЖНЫ КАРТОЧКИ?</div>Вы сможете вносить депoзит карточками, вместо предметов. Карточки моментально вносится в раунд без задержек. Карточки не теряются в стоимости и вы сможете поменять их в любой момент на предметы в нашем магазине <span>csgo-life.com</span>.
	</div>
</div>
	
   	<div class="popup_block" id="popup_name-8">
	<div class="title">Честная игра</div>
	<div class="fair-text">
		<p>За каждый внесенную 1 копейку вы получаете 1 билет. Например, если вы внесли депозит на 100 руб, то выполучите 10000 билетов (т.к. 100р = 10000 копеек, а 1 копейка = 1 билет)</p>
		<p>В начале каждого раунда наша система берет абсолютно рандомное длинное число от 0 до 1 (например 0.83952926436439157) и шифрует его через md5 , и показывает его в зашифрованом виде в начале раунда. (если вы не знаете, что такое md5 - можете почитать статью на википедии)</p>
		<p>Затем, когда раунд завершился, система показывает то число, которое было шифровано вначале (проверить его вы можете на сайте md5.cz) и умножает его на банк (в копейках). Например, в конце раунда банк составил 1000 рублей а 1000 рублей = 100000 копеек (1 рубль = 100 копеек), то нужно будет число 0.83952926436439157 умножить на банк 100000 копеек (это цифры, которые мы брали для примера) и получим число 83952. То есть в раунде победит человек, у которого есть 83952 билет.</p>
			<p id="checkResult"></p>
		</div>
	<div class="fair-form">
		<div class="top-fair">ПРОВЕРКА ЧЕСТНОЙ ИГРЫ<span>Число раунда * банк (в копейках) = выигрышный билет</span></div>
		<div class="fair-inputs">
			<input type="text" id="roundHash1" name="" placeholder="Хэш раунда">
			<input type="text" id="roundNumber1" name="" placeholder="Число раунда">
			<input type="text" id="roundPrice1" name="" placeholder="Кол-во копеек в раунде">
			<input type="submit" id="checkHash" name="" value="ПРОВЕРИТЬ">
			
		</div>
	</div>
</div>
<!--LiveInternet counter--><script type="text/javascript"><!--
document.write("<a href='//www.liveinternet.ru/click' "+
"target=_blank><img src='//counter.yadro.ru/hit?t52.6;r"+
escape(document.referrer)+((typeof(screen)=="undefined")?"":
";s"+screen.width+"*"+screen.height+"*"+(screen.colorDepth?
screen.colorDepth:screen.pixelDepth))+";u"+escape(document.URL)+
";"+Math.random()+
"' alt='' title='LiveInternet: показано число просмотров и"+
" посетителей за 24 часа' "+
"border='0' width='0' height='0'><\/a>")
//--></script><!--/LiveInternet-->


<script src="https://cdn.socket.io/socket.io-1.3.5.js"></script>
<script src="http://csgo-life.com/assets/js/app.js" ></script>
<script>
        function updateBalance() {
        $.post('http://csgo-life.com/getBalance', function (data) {
            $('.update_balance').text(data);
        });
    }
    function addTicket(id, btn){
        $.post('http://csgo-life.com/addTicket',{id:id}, function(data){
            updateBalance();
            return $(btn).notify(data.text, {position: 'top middle', className :data.type});
        });
    }
    </script>
<!-- Yandex.Metrika counter -->
<script type="text/javascript">
    (function (d, w, c) {
        (w[c] = w[c] || []).push(function() {
            try {
                w.yaCounter33459388 = new Ya.Metrika({
                    id:33459388,
                    clickmap:true,
                    trackLinks:true,
                    accurateTrackBounce:true
                });
            } catch(e) { }
        });

        var n = d.getElementsByTagName("script")[0],
            s = d.createElement("script"),
            f = function () { n.parentNode.insertBefore(s, n); };
        s.type = "text/javascript";
        s.async = true;
        s.src = "https://mc.yandex.ru/metrika/watch.js";

        if (w.opera == "[object Opera]") {
            d.addEventListener("DOMContentLoaded", f, false);
        } else { f(); }
    })(document, window, "yandex_metrika_callbacks");
</script>
<noscript><div><img src="https://mc.yandex.ru/watch/33459388" style="position:absolute; left:-9999px;" alt="" /></div></noscript>
<!-- /Yandex.Metrika counter -->
</html>