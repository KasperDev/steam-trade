@extends('layout')


@section('content')

<div class="content">
	<!-- <middle> -->

	<div class="other-title">Топ победителей</div>

	<div class="other-page">
	<div class="table-top">
			<div class="list">
				<div class="tb1">Place</div>
				<div class="tb2">Профиль пользователя</div>
				<div class="tb3">Участий</div>
				<div class="tb4">Побед</div>
				<div class="tb5">Винрейт</div>
				<div class="tb6">Сумма банков</div>
			</div>
			@foreach($users as $user)
			<div class="list">
				<div class="tb1"><span>{{ $place++ }}</span></div>
				<div class="tb2"><img src="{{ $user->avatar }}" alt="" title=""><a href="/user/{{ $user->steamid64 }}">{{htmlspecialchars(preg_replace('/' . \App\Game::zapretsite() . '/i', '', $user->username)) }}</a></div>
				<div class="tb3">{{ $user->games_played }}</div>
				<div class="tb4">{{ $user->wins_count }}</div>
				<div class="tb5">{{ $user->win_rate }}%</div>
				<div class="tb6">{{ round($user->top_value) }} руб.</div>
			</div>
			@endforeach
	</div>

	</div>

	

@endsection