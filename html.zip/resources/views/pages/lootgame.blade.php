@extends('layout')


@section('content')
 <script src="{{ asset('assets/js/loot.js') }}" ></script>
	<link href="{{ asset('assets/css/loot.css') }}" rel="stylesheet">

<div class="content">
@foreach($loots as $loot)
<script>var GAME ='{{$loot->id}}'; 

var gameEnd = @if($loot->winner_id == 0) false @else true @endif ;</script>
	<div class="other-title">Розыгрыш {{$loot->name}}</div>

<div class="about" style=" padding: 0; ">










<span class="wineinf">
@if($loot->winner_id==0)Победитель: будет объявлен через <span class="wineinfs">{{$loot->maxuser - $loot->users}}</span> мест. @else
Победитель: {{$winner}}.
@endif
</span>
<span class="wineinf2">Информация: Вы можете занять неограниченное количество мест. Вы занимаете <span class="mez">{{$mez}}</span> мест для этого предмета.</span>
<div class="giveaway" style=" margin-left: 415px; "><img src=" @if($loot->classid == 7)  @else  https://steamcommunity-a.akamaihd.net/economy/image/class/730/{{$loot->classid}}/85fx85f @endif" original-title="{{$loot->name}}" class="giveaway_subject"></div>

<div class="panel"><span class="gusers" style=" margin-left: 130px; ">Всего <span id="gusersgi">{{$loot->users}}</span> мест занято</span>
@if($loot->winner_id==0)
	<span id="offgamess"><a class="add" id="add_to_giveaway" href='javascript://'>Занять случайное место</a></span>

@else

  <form action='https://api.random.org/verify' method='post' target="_blank">
                    <input type='hidden' name='format' value='json' />
                    <input type='hidden' name='random' value='{{$loot->randomorg_result}}' />
                    <input type='hidden' name='signature' value='{{$loot->randomorg_sign}}' />
                    <button type="submit" style="margin-left: 64px; float: left; padding: 5px; color: white; background: #73b95e;border: 0;" style="margin-top: -30px;" class="btn btn-white btn-sm btn-right">Проверить</button>
                </form>


@endif
<span class="gusers2">@if($loot->winner_id==0)Победитель: не выбран. @else Победитель: {{$winner}}. @endif</span></div>


@endforeach	

<div id="lotUsers" class="usersbox" style="overflow:hidden">
<p class="title-work" style=" margin-left: 347px; ">Места</p>




	

  
  @for ($i = 1; $i <= $loot->maxuser; $i++) 
	  
  
  
 



  @if(array_key_exists($i, $lots))

<div class="ticket ticket-{{$i}} not_animated user{{$lots[$i]['id']}}" data-place="{{$i}}" lot-idx="{{$i}}" lot-empty="false">

	<div class="lottf ticket-{{$i}}"></div>

								<a @if($loot->winner_id!=$i & $loot->winner_id !=0) style=" opacity: 0.3; " @endif target="_blank" href="http://steamcommunity.com/profiles/{{$lots[$i]['id']}}">
								
							
										<img src="{{$lots[$i]['avatar']}}">
									
									<div>{{$i}}</div>
								</a>
								
							
							</div>  
  
								@else
									
								<div class="ticket ticket-{{$i}} not_animated" data-place="{{$i}}" data-game="{{$loot->id}}" lot-idx="{{$i}}" lot-empty="true">

	

								<a @if($loot->winner_id!=$i & $loot->winner_id !=0) style=" opacity: 0.3; " @endif class="addtollot" data-place="{{$i}}" lot-idx="{{$i}}" data-game="{{$loot->id}}" lot-empty="true" href="javascript://">
								
							
										<img class="ticket-{{$i}}" src=""> 
									
									<div>{{$i}}</div>
								</a>
								
							
							</div>  
								
								@endif	
							
									  
						

				

	  
	  
	  	

										
								@endfor

													
								
									
											</div>

 
	</div>

	</div>


@endsection