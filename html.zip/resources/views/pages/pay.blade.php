@extends('layout')

@section('content')

  <form method='get' action='http://www.free-kassa.ru/merchant/cash.php'>
    <input type='hidden' name='m' value='{{ $merchant_id }}'>
    <input type='hidden' name='oa' value='{{ $order_amount }}'>
    <input type='hidden' name='o' value='{{ $order_id }}'>
    <input type='hidden' name='s' value='{{ $sign }}'>
   
    <input type='hidden' name='lang' value='ru'>
    <input type='hidden' name='us_login' value='{{ $user_name }}'>
    <input type='submit' name='pay' value='Оплатить'>
</form>


@endsection