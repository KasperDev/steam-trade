
@extends('layout')

@section('content')



<div class="content">

	<div class="other-title">Розыгрыши</div>

	<div class="store">

		<div class="top-sort">
		  @if(Auth::guest())
		

			
			     @else
					 
				 
				 
					 			<div class="balance">Баланс: <span class="update_balance">{{ $u->money }}</span> руб.</div>
			<a href="#?w=628" rel="popup_name-7" class="poplight refill">Пополнить</a>
				 	<a href="/myloothistory" style="margin-left:15px;" class="to-sort">Моя история</a>
				    @endif
		

			<a href="/loothistory" class="to-sort">История игр</a>
		</div>

</br>
@foreach($loots as $loot)
<!-- item -->
<div class="product">
	<div class="product__image">
	<div style="
    position: absolute;
    color: white;
    margin: 0px 0px 0 0px;
    padding: 10px;
    background: #5E964D;
    border-radius: 3px 0px 3px 0px;
    line-height: 10px;
" class="">{{round($loot->price)}} РУБ</div>
<div style="
    float:right;
    position: absolute;
    color: white;
    right: 0px;
    padding: 10px;
    background: #5E964D;
    border-radius: 0px 0px 0px 3px;
    line-height: 10px;
" class="">{{$loot->maxuser}} М</div>
					<a class="product__image__wrap" @if($loot->classid == 7) style="background-size: cover;background: url(https://pp.vk.me/c629526/v629526603/25d23/WopJ-TTrCnk.jpg) -15px -4px;height: 160px;" @endif href="/loot/{{$loot->id}}">
					
				<img src="@if($loot->classid == 7)  @else https://steamcommunity-a.akamaihd.net/economy/image/class/730/{{$loot->classid}}/160fx160f @endif ">
			</a>
			</div>
				<a href="/loot/{{$loot->id}}" class="product__button">{{$loot->name}}</a>
		<div class="product__info">
		@if($loot->quality != 0)
	
		 @else
															<div class="product__info__item product__info__item-cut">
											<div class="product__info__item__label">Внешний вид</div>
										<div style="">
						{{$loot->quality}}				</div>
				</div>
					 @endif 
							<div class="product__info__item product__info__item-cut">
											<div class="product__info__item__label">Раритетность</div>
										<div style="
																				">
						{{$loot->rarity}}					</div>
				</div>
					
		<div class="product__info__item product__info__item-cut">
			<div class="product__info__item__label">Цена в Steam</div>
				{{$loot->steam_price}}	 руб		</div>
			
				<div class="product__progress">
<div class="product__progress__bar js-progress-bar"  original-title="Осталось {{$loot->maxuser - $loot->users}} мест из {{$loot->maxuser}} возможных" style="width:{{(100/$loot->maxuser) * $loot->users}}%"></div>
				</div>
				

			</div>

</div>
			
	<!-- item -->	
@endforeach	
	<!-- </middle> -->


			 
                             
                      






		</div>










	</div>
@endsection