@extends('layout')

@section('content')
<div class="content">
	<!-- <middle> -->
	<div class="other-title">Информация об оплате</div>

	<div class="about">
			Произошла ошибка при оплате
	</div>
</div>

@endsection