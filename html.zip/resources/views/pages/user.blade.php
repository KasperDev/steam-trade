@extends('layout')

@section('content')
<div class="content">

<div class="other-title">Профиль {{ $username }}</div>

<div class="historys">
	<div class="profile">
			<div class="top">
				<div class="avatar"><img src="{{ $avatar }}" alt="" title=""></div>
				<ul>
					<li>Побед: <span>{{ $wins }}</span></li>
					<li>Участий: <span>{{ $games }}</span></li>
				</ul>
				<ul>
					<li>Винрейт: <span>{{ $winrate }}%</span></li>
					<li>Сумма банков: <span>{{ $totalBank }} руб.</span></li>
				</ul>
			</div>
			
			
			<div class="profile-table">
				<div class="list">
					<div class="tb1">#</div>
					<div class="tb2">Дата</div>
					<div class="tb3">Банк</div>
					<div class="tb4">Статус</div>
					<div class="tb5">Шанс</div>
				</div>
				@foreach($list as $game)
				<div class="list">
					<div class="tb1"><a href="/game/{{ $game -> id }}">#{{ $game -> id }}</a></div>
					<div class="tb2"><acronym class="tooltip tooltipstered" title="{{ $game->updated_at }}">{{ $game->created_at }}</acronym></div>
					<div class="tb3">{{ $game -> bank }} руб.</div>
					<div class="tb4">
						@if($game->win == 1)
						<span class="win">Победа</span>
						@elseif($game->win == -1)
						<span class="wait">Не завершена</span>
						@else
						<span class="lost">Поражение</span>
						@endif
					</div>
					<div class="tb5">{{ $game -> chance }}%</div>
				</div>
				@endforeach
			</div>
			

			<div class="profile-pag">
				{!! $games2->render() !!}
			</div>
		</div>

	</div>
	</div>
@endsection