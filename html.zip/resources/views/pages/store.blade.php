@extends('layout')


@section('content')

<div class="content">
	<!-- <middle> -->

	<div class="other-title">Магазин скинов</div>

	<div class="store">

		<div class="top-sort">
		  @if(Auth::guest())
		

			
			     @else
					 
				 
				 
					 			<div class="balance">Баланс: <span class="update_balance">{{ $u->money }}</span> руб.</div>
			<a href="#?w=628" rel="popup_name-7" class="poplight refill">Пополнить</a>
				 
				    @endif
			<input type="text" name="" placeholder="">
			<input type="submit" name="" value="Искать">
			<a href="#" class="to-sort">Сортировать</a>
		</div>

		<div class="bot-sort">

			<div class="sum">
				<div>Цена от</div> <input type="text" placeholder="150">
				<div>до</div> <input type="text" placeholder="500">
				<div>руб.</div>
			</div>

			<div class="selects">
				<select>
					<option>Категория</option>
					<option>-</option>
					<option>-</option>
				</select>
				<select>
					<option>Качество</option>
					<option>-</option>
					<option>-</option>
				</select>
				<select>
					<option>Редкость</option>
					<option>-</option>
					<option>-</option>
				</select>
			</div>

		</div>

		<div class="store-items">

			<div class="short">
				<div class="picture"><img src="item-3.png" alt="" title="" /></div>
				<ul>
					<li>Керамбит</li>
					<li>Тайное, Немного поношенное</li>
					<li>Цена в Steam: <span>11111 руб.</span></li>
					<!--<li><a href="#">Посмотреть в игре</a></li>-->
				</ul>
				<div class="right">
					10600 <span>руб.</span>
					<a href="#?w=550" rel="popup_name-4" class="poplight">Купить</a>
				</div>
			</div>

			






		</div>










	</div>

	<!-- </middle> -->
<div class="popup_block store-pop" id="popup_name-4">
	<div class="title">Подтверждение покупки</div>
	<div class="picture"><img src="item-4.png" alt="" title="" /></div>
	<ul>
		<li>Керамбит</li>
		<li>Внешний вид: тайное</li>
		<li>Качество: немного поношенное</li>
		<li>Цена в Steam: 11111 руб.</li>
		<li>Наша цена: 10600 руб.</li>
	</ul>
	<div class="clear"></div>
	<a href="#" class="buy">Продолжить</a>
</div>

@endsection