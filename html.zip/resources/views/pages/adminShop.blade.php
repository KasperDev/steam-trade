@extends('layout')


@section('content')

<div class="content">
	<!-- <middle> -->

	<div class="other-title">Покупки</div>

	<div class="shophistyory">

		<div class="table">

			<div class="list">
				<div class="tb1">ID</div>
				<div class="tb2" style=" background: #71b35d; ">Дата покупки</div>
				<div class="tb3">Предмет</div>
				<div class="tb4" style=" background: #71b35d; ">Качество</div>
				<div class="tb5">Цена</div>
				<div class="tb6" style=" background: #71b35d; ">Статус</div>
			</div>
       @forelse($items as $item)
			<div class="list">
				<div class="tb1">5</div>
				<div class="tb2">{{ $item->buy_at }}</div>
				<div class="tb3">{{ $item->name }}</div>
				<div class="tb4">{{ $item->quality }}</div>
				<div class="tb5">{{ $item->price }} руб.</div>
				<div class="tb6">@if($item->status == \App\Shop::ITEM_STATUS_SOLD)
                                <div class="game-status processing">Отправка предмета</div>
                            @elseif($item->status == \App\Shop::ITEM_STATUS_SEND)
                               <div class="game-status">Предмет отправлен</div>
                            @elseif($item->status == \App\Shop::ITEM_STATUS_NOT_FOUND)
                               <div class="game-status error">Предмет не найден</div>
                            @elseif($item->status == \App\Shop::ITEM_STATUS_ERROR_TO_SEND)
                              <div class="game-status error">Ошибка отправки</div>
                            @endif</div>
			</div>

		    @endforeach

		</div>

	</div>



@endsection