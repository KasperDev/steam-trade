@extends('layout')

@section('content')

<div class="content">
	<!-- <middle> -->

	<div class="other-title">Смотреть историю</div>
	
	<div class="historys">

	   @forelse($loots  as $loot)
		<div class="short">
			<div class="top">
				<div class="avatar"><img src="{{$loot->winner_avatar}}" alt="" title="" /></div>
				<ul>
					<li><a href="#" data-profile="{{$loot->winner_steamid64}}">{{htmlspecialchars(preg_replace('/' . \App\Game::zapretsite() . '/i', '', $loot->winner_username ))}}</a></li>
			
					<li>Выигрыш: <span>{{ $loot->name }}</span> </li>
			<li>Номер билета: <span>{{ $loot->winner_id }}</span></li>
				</ul>
				<div class="h-blanks">@if($loot->status_prize == \App\Game::STATUS_PRIZE_WAIT_TO_SENT)
                    <span class="order-status sended_to_our_bot">Отправка выигрыша</span>
                @elseif($loot->status_prize == \App\Game::STATUS_PRIZE_SEND)
                    <span class="order-status sended">Выигрыш отправлен</span>
                @else
                    <span class="order-status error">Ошибка отправки выигрыша</span>
                @endifИГРА <span>#{{ $loot->id }}</span><br><a href="/loot/{{ $loot->id }}">Посмотреть полную историю игры</a></div>
			</div>


			
		
			
			
	
			
	
 
		</div>
 
	
          @empty
                <center><h1 style="color: #33BDA6;">Игр нет!</h1></center>
            @endforelse
	</div>

@endsection