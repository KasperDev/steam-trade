@extends('layout')

@section('content')

</header>
 
<div class="content">
	<!-- <middle> -->
<div class="leftbar" style="
    width: 100%;
">

		
			
		<div class="total-game">
			<div class="top-inf">
				<div>Раунд <span>#<span>{{ $game->id }}</span></span> в банке <span><span>{{ round($game->price) }} руб.</span></span>
				
				
				
				
				</div><div>
				@if($game->status_prize == \App\Game::STATUS_PRIZE_WAIT_TO_SENT)
                    <span class="order-status sended_to_our_bot">Отправка выигрыша</span>
                @elseif($game->status_prize == \App\Game::STATUS_PRIZE_SEND)
                    <span class="order-status sended">Выигрыш отправлен</span>
                @else
                    <span class="order-status error">Ошибка отправки выигрыша</span>
                @endif</div>
				
			</div>

			<a href="#" class="sound">&#160;</a>
			<div class="clear"></div>

			<div class="progress">
				<div class="line" original-title="{{ $game->items }} {{ trans_choice('lang.items', $game->items) }}" style="width: {{ $game->items*2 }}%;">&nbsp;</div>
			</div>

		
			
			
			
		</div>
		
		
	
		

		<div class="end-game"> 
		<div>
		

			<div class="bottom-game">
				<div class="us-win">
					<ul>
						<li>Победил игрок: <span>{{ htmlspecialchars(preg_replace('/' . \App\Game::zapretsite() . '/i', '', $game->winner->username ))}} ({{ \App\Http\Controllers\GameController::_getUserChanceOfGame($game->winner, $game) }}%)</span></li>
						<li>Выигрыш: <span>{{ $game->price }}</span></li>
					</ul>
				</div>

				<!--<div class="buttons">
					<a href="#"></a>
					<a href="#"></a>
					<a href="#"></a>
				</div>-->

				<div class="blk-win">
					<ul>
						<li>Победный билет: <span>#{{ $game->ticket }}</span><span> (всего: {{ $bankTotal = $game->price * 100 }})</span></li>
						<li>Число раунда: <span>{{ $game->rand_number }}</span></li>
					</ul>
				</div>
			</div>	</div>
		</div>
		
	
		<div class="part @if(count($percents) == 0) hidden @endif" >
			
	     @foreach($percents as $p)
			<div class="block"><div>{{ $p->chance }}%</div><img src="{{ $p->avatar }}" alt="" title="" /></div>
        @endforeach
		</div>		

		<div class="main-game">
			<div>
			
		     @foreach($bets as $bet)
            @include('includes.bet')
        @endforeach

	

			</div>
		</div>

		<div class="start">
			<ul>
				<li>Игра началась! Вносите депозиты!</li>
				<li>Хэш раунда: <span>{{ md5($game->rand_number) }}</span></li>
			</ul>
			<a href="#?w=628" rel="popup_name-8" class="fair poplight">Честная игра</a>
		</div>

	</div>

	
	
   
@endsection