@extends('layout')

@section('content')

<div class="content">
	<!-- <middle> -->
	<div class="other-title">Стоимость моего инвентаря - <span><span id="totalPrice"></span>0 рублей</span></div>

	<div class="myinventory">
	
	
	<div class="other-page" style=" padding: 32px 0px; ">

		<div class="table" id="tbodymyinv">

			
			
		


			
				</div>

	</div>
	

<script>
    $(function(){
        loadMyInventory()
    });
</script>
@endsection