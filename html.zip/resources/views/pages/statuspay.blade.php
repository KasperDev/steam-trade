@extends('layout')

@section('content')
<div class="content">
	<!-- <middle> -->
	<div class="other-title">Информация об оплате</div>

	<div class="about">
			Оплата прошла успешно оплате
	</div>
</div>

@endsection