@extends('layout')

@section('content')

<div class="content">

<div class="other-title">История игр</div>

<div class="historys">
	   @forelse($games as $game)
		<div class="h-short">
		
		
			<div class="user-info">
				<img src="{{ $game->winner->avatar }}" alt="" title="">
				<ul>
					<li><a href="/user/{{ $game->winner->steamid64 }}">{{htmlspecialchars(preg_replace('/' . \App\Game::zapretsite() . '/i', '', $game->winner->username ))}}</a></li>
					<li>Выигрыш: <span>{{ $game->price }}</span> руб.</li>
					<li>Шанс: <span>{{ $game->percent }}%</span></li>
				</ul>
			</div>
			
			<div class="right">
				<div class="top">
					<div class="number">Игра #{{ $game->id }}</div>
					<div class="infos">
						<div><acronym original-title="{{ $game->updated_at }}">{{ $game->created_at->diffForHumans() }}</acronym></div>
						@if($game->status_prize == \App\Game::STATUS_PRIZE_WAIT_TO_SENT)
						<div class="waits">Отправка выигрыша</div>
						@elseif($game->status_prize == \App\Game::STATUS_PRIZE_SEND)
						<div class="successs">Трейд отправлен</div>
						@else
						<span class="errors">Ошибка отправки</span>
						@endif
					</div>
				</div>
				<div class="items">
				@foreach(json_decode($game->won_items) as $i)
			 		@if(!isset($i->img))
					<div class="itm" original-title="{{ $i->name }}">
						<div class="picture {{ $i->rarity }} tooltipstered"><img src="https://steamcommunity-a.akamaihd.net/economy/image/class/730/{{ $i->classid }}/70fx70f" alt="" title=""></div>
						<div class="price">{{$i->price}} руб.</div>
					</div>
					@else
					<div class="itm" alt="" original-title="{{ $i->name }}">
						<div class="picture card"><img src="http://etc.usf.edu/presentations/extras/buttons/icons_trans/22%20metallic%20gold/058.png" alt="" title=""></div>
						<div class="price">{{ round($i->price) }} р.</div>
					</div>
					@endif
				@endforeach
				</div>
			</div>
		</div>
			@empty
                <center><h1 style="color: #33BDA6;">Игр нет!</h1></center>
            @endforelse
				<div class="profile-pag">{!! $games->render() !!}</div>
</div>
@endsection