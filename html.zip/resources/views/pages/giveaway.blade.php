@extends('layout')

@section('content')
<div class="content">
	<!-- <middle> -->
	<div class="other-title">Раздачи</div>

	<div class="about" style=" padding: 0; ">




@foreach($givegame as $i)
<script src="//cdn.rawgit.com/hilios/jQuery.countdown/2.1.0/dist/jquery.countdown.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/moment.js/2.10.3/moment-with-locales.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/moment-timezone/0.4.0/moment-timezone-with-data-2010-2020.min.js"></script>



<span class="wineinf" style="margin:69px 0 0 150px;">@if($i->status == 0)Победитель: будет объявлен через <span id="countdown"></span>. @else Победитель: {{$i->winner}}.@endif 

</span>
<span class="wineinf2" style="margin:69px 170px 0 0;">Статистика раздач за все время: 1 раздача, 
1 победитель, 90 игроков</span>
<div class="giveaway" style="margin-left:465px;"><img src="https://steamcommunity-a.akamaihd.net/economy/image/class/730/{{$i->classid}}/85fx85f" original-title="{{$i->items}}" class="giveaway_subject"></div>

<div class="panel"><span class="gusers" style="margin-left:196px;">Всего <span id="gusersgi">{{count($giveaway2)}}</span> участников</span><a class="add" style="border-radius:2px;" id="add_to_giveaway" href="javascript://">Принять участие</a>
<span class="gusers2">Победитель: @if($i->winner == NULL)не выбран @else {{$i->winner}} @endif @endforeach</span></div>


<div class="giveaway_users" style="padding:10px 10px 30px 77px;" id="g_users">
<script type="text/javascript">

	function updateGiveaway() {
		$.get('/get_giveaway_users',function(data) {
			
			if(data && data.length > 0){
							$('#g_users').html('');
			for(var i in data){
			
	 var item = '<div class="block" title="'+data[i].username+'" style="background-image:url('+data[i].avatar+');">';
			
			
			$('#g_users').append(item);
				}}
			
		});
		$.get('/get_giveaway_count',function(data) {
			$('#gusers').html(data);
		});
	}
	updateGiveaway();
	u_give_users = setInterval(updateGiveaway,4000);

  // Handle timezone issue
  var timezone = 'Europe/Moscow';
  // Now the easy part, handle the countdown!
  var $clock = $('#countdown');
  var $iso = $('#iso');
  

function getWordNormal(num, str1, str2, str3) {var val = num % 100;if (val > 10 && val < 20) return num +' '+ str3;else {var val = num % 10;if (val == 1) return num +' '+ str1;else{if (val > 1 && val < 5) return num +' '+ str2;else return num +' '+ str3;}}}

  $clock.on('update.countdown', function(event) {
	var str = event.strftime(getWordNormal('%D','день','дня','дней')+' '+getWordNormal('%H','час','часа','часов')+' и '+getWordNormal('%M','минута','минуты','минут')+'');
    $(this).html(str);
	if(str=='00 дней 00:00:01') {
		setTimeout(function() {location.reload()},1500);
	}
  });

  function updateCountdown() {
    var date = moment.tz('{{$i->date}}', timezone);
    $clock.countdown(date.toDate());
    console.log(date.toISOString());
    $iso.html(date.format("YYYY-MM HH:mm Z"));
  }

  // Run forrest run!
  updateCountdown();
</script>




 @foreach($giveaway as $i)

	 
 <div class="block" title="{{$i->username}}" style="background-image:url('{{$i->avatar}}');">

</div>
 


	 @endforeach




</div>



<script>
$('#add_to_giveaway').click(function(){

	if(!$('.giveaway_subject').length) {
 		alertmessage("warning",null,'Игра окончена, или еще не начата');
	}
	else {
		
		$.ajax({
					type : "GET",
					url  : "/api/addusers",
					dataType : "json",
					cache : false,
					success : function(resultss){
						
						
						

 
		var r = resultss.reason;
		if(r=="ok") {
			$.notify("Успех! Вы участвуете в раздаче.", {className :"success"});
	
			updateGiveaway();
		}
		else if(r=="already_plays") {
			
			$.notify("Вы уже в раздаче.", {className :"error"});
			
				  
		}
		else if(r=="nogame") {
			
			
				$.notify("Игра окончена, или еще не начата", {className :"error"});
			
			
	  	}
		else if(r=="not_authed") {
			
	  	}
		else if(r=="nickname") {
			
			$.notify("Добавьте CSGO-LIFE.COM в свой ник", {className :"error"});
	
	  	}
		else if(r=="timeout") {
			alertmessage("warning",null,'Вы не можете участвовать, осталось меньше часа')
	  	}
        }
    });

	}
});

</script> 
<div class="about">
<p class="title-work" style="margin-left:300px;border-radius:0px 0px 2px 2px;">Требования для участия</p>
<ol>
	<li>На время проведения розыгрыша необходимо, чтобы в вашем никнейме было название нашего сайта: CSGO-LIFE.COM</li>
	<li>Приз выдается только тому, у кого в имени пользователя стояло на протяжении розыгрыша название нашего сайта: CSGO-LIFE.COM</li>
</ol>
</div>

	</div>
</div>

@endsection