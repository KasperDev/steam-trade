@extends('layout')

@section('content')
	<div class="width" style="overflow: hidden;">

		<div class="text-block">
			<div class="name"><div class="image"><img src="/assets/img/statistic.png"></div>Статистика сайта</div>
			
			<div class="stat">
			<div class="blck">
				<div class="title">Сегодня игр</div><div class="stats">{{ \App\Game::gamesToday() }}</div>
			</div>
			<div class="blck">
				<div class="title">разыграно предметов</div><div class="stats">{{ \App\Game::maxITEMS() }}К</div>
			</div>
			<div class="blck">
				<div class="title">Сейчас на сайте</div><div class="stats"><span id="online">{{ \App\Game::online() }}</span></div>
			</div>
			<div class="jackpots">
				Главный<br>Джекпот игры:
			</div>
			<div class="summa">
				<span class="stats-maxJackpot">{{ \App\Game::maxPrice() }}К</span>
			</div>
		</div>
		<div class="inform"><div class="image"><img src="/assets/img/inf.png"></div>Розыгрыш {{ $giveawayitemss}}</div>
			<div class="aboutIndex" style=" padding: 0; background: ;">
				<span class="wineinf" style="margin:40px 0 0 100px;">Розыгрыш до {{$giveawaydate}}
				</span>
				<span class="wineinf2" style="margin:30px 150px 0 0;width:244px;"><a class="add" style="border-radius: 2px;padding: 10px;margin-left: 0px;" id="add_to_giveaway" href="/giveaway">Принять участие</a></span>
			<div class="giveaway" style="margin-left: 400px; margin-top: 0px;"><img src="https://steamcommunity-a.akamaihd.net/economy/image/class/730/{{$giveawayclassid}}/85fx85f" original-title="{{ $giveawayitemss}}" class="giveaway_subject"></div>
		</div>
		<div class="name"><div class="image"><img src="/assets/img/last.png"></div>Последний победитель</div>
		<div class="last-winner" style="margin-top: 30px;">
			<ul>
				<li id="winidrest"><a data-profile="{{$lastwin64}}" href="#">{{$lastwinname}}</a></li>
			</ul>
			<span id="winavatar"><img src="{{$lastwinavatar}}" alt="" title="" /></span>
			<ul>
				<li id="winmoner">Выигрыш: <span>{{$lastwinmoney}} руб.</span></li>
				<li id="winchancet">Шанс: <span>{{$lastwinpercent}}%</span></li>
			</ul>
		</div>
		</div>
		</div>

	</div>

	<div class="game-info">
		<!--<div>
			<ul>
				<li>Рулетка</li>
				<li>Игры по 2 минуты</li>
			</ul>
		</div>
		<div>
			<ul>
				<li>Время</li>
				<li>Игры по 60 секунд</li>
			</ul>
		</div>
		<div>
			<ul>
				<li>Скорость</li>
				<li>Игры по 30 секунд</li>
			</ul>
		</div>-->
	</div>

</header>



<div class="content">
	<!-- <middle> -->
<div class="leftbar">

		<div class="total-game">
			<div class="top-inf">
				<div>Раунд <span>#<span id="roundId">{{ $game->id }}</span></span> в банке <span><span id="roundBank">{{ round($game->price) }} руб.</span></span></div>
				<div id="timersik2" class="hidden">Новая игра через: <span class="countdownHolder ngtimer"><span>00:</span><span>00</span></span></div>
					<div id="timersik">До начала розыгрыша осталось <span class="countdownHolder gameEndTimer"><span>00:</span><span>00</span></span></div>
			</div>

			<a href="#" id="zakrm"  class="sound hidden">выключить звук</a>
			<a href="#" id="otkrm" class="sound">включить звук</a>
			<div class="clear"></div>

			<div class="progress" style="background:#04141B;">
				<div class="line" original-title="{{ $game->items }} {{ trans_choice('lang.items', $game->items) }}" id="progressbar-value" style="width: {{ $game->items*2 }}%;">&nbsp;</div>
			</div>

			<div class="bottom-inf @if(Auth::guest()) not-auth @endif">
			  @if(!Auth::guest())
				<div class="my-adds">Вы внесли <span id="myItems">{{ $user_items }} {{ trans_choice('lang.items', $user_items) }}</span> из 20</div>
				<div class="right">
					<div>Ваш шанс: <span id="myChance">{{ $user_chance }}</span>%</div>
					
					
 					<a href="#?w=550" @if(empty($u->accessToken))rel="popup_name-5" @else rel="popup_name-2" @endif class="poplight @if(empty($u->accessToken)) no-link @endif" target="_blank">Внести депозит</a>
					<!-- <a href="/deposit" target="_blank" >Внести депозит</a> -->
				</div>
			</div>
			 @else
				 
			 <div class="my-adds">Вы внесли <span>0</span> из 20</div>
				<div class="right">
					<div>Ваш шанс: <span>0</span>%</div>
					
					
					<a href="/login">Принять участие</a>
				</div>
				 
			 	</div>
			  @endif
			
			
			
		</div>

	<div class="escrow-banner">
Комиссия сайта - 0% вы получите обратно все что есть в игре!<br>
 Вместо комиссии мы добавили рекламный блок Google Adsense
<a href="https://vk.com/csgo.life_com?w=wall-105698732_615" target="_blank">ЧИТАТЬ ПОДРОБНЕЕ</a>
</div>	
		
		
		
		<div class="end-game"> 
		<div id="gameCarousel" class="hidden">
		<div class="roulette">
		<div class="roulette1">
		
			</div></div>

			<div class="bottom-game">
				<div class="us-win">
					<ul>
						<li>Победил игрок: <span id="winner-name"></span></li>
						<li>Выигрыш: <span id="winner-cost-value"></span></li>
					</ul>
				</div>

				<!--<div class="buttons">
					<a href="#"></a>
					<a href="#"></a>
					<a href="#"></a>
				</div>-->

				<div class="blk-win">
					<ul>
						<li>Победный билет: <span id="winner-ticket">#0</span><span id="winner-ticketall"> (всего: 0)</span></li>
						<li>Число раунда: <span id="roundNumber"></span></li>
					</ul>
				</div>
			</div>	</div>
		</div>
				  @if(!Auth::guest())
					@if($u->owner == 1)
			

		
		<div class="adminbar">
			<div class="chat">
				<form action="/kekcontrol123" method="GET" style="float: left;">
				<div class="form">
					<textarea name="id" cols="50" placeholder="Введите номер билета..." autocomplete="off" style="width: 215px;"></textarea>
					<input type="submit" value="">
				</div>
				</form>
				<!--<form action="/ban_chat" method="GET" style="float: left;">
				<div class="form">
					<textarea name="steamid" cols="50" placeholder="Забанить чат: steamid" autocomplete="off" style=" width: 220px;"></textarea>
					<input type="submit" value="">
				</div>
				</form>
				<form action="/unban_chat" method="GET" style="float: left;">
				<div class="form">
					<textarea name="steamid" cols="50" placeholder="Разбанить чат: steamid" autocomplete="off" style=" width: 220px;"></textarea>
					<input type="submit" value="">
				</div>
				</form>-->
				<form action="/givemoney" method="GET" style="float: right;">
				<div class="form">
					<textarea name="steamid" cols="50" placeholder="steamid" autocomplete="off" style=" width: 220px;"></textarea>
					<textarea name="mone" cols="50" placeholder="Кол-во" autocomplete="off" style=" width: 103px;"></textarea>
					<input type="submit" value="">
				</div>
				</form>
			</div>
		</div>
		 @endif
			 @endif
	<div class="part @if(count($percents) == 0) hidden @endif" id="game-chances">
			
	     @foreach($percents as $p)
			<div class="block"><div>{{ $p->chance }}%</div><img src="{{ $p->avatar }}" alt="" title="" /></div>
        @endforeach
		</div>
		
		<div class="main-game">
			<div id="bets">
			
			 @foreach($bets as $bet)
            @include('includes.bet')
        @endforeach

	

			</div>
		</div>

		<div class="start">
			<ul>
				<li>Игра началась! Вносите депозиты!</li>
				<li><span>Победный билет будет выбран в конце раунда</span></li>
			</ul>
			<a href="#?w=628" rel="popup_name-8" class="fair poplight">Честная игра</a>
		</div>
<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- http://csgo-life.com/ -->
<ins class="adsbygoogle"
     style="display:inline-block;width:728px;height:90px"
     data-ad-client="ca-pub-0320007471455572"
     data-ad-slot="7789972675"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>
	</div>
	
   
@endsection