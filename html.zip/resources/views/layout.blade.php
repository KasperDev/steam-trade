<!doctype html>

<html class="no-js">
<head>
    <meta charset="utf-8" />
    <meta http-equiv="x-ua-compatible" content="ie=edge" />
    <title>CSGO-LIFE.COM - Luck is on your side!</title>
    <meta name="keywords" content="csgo джекпот,csgo jackpot , Luck is on your side ,Удача на вашей стороне,cs go рулетка,рулетка кс го ,cs go рулетка от 1 рубля,рулетка кс го ,рулетка cs go, csgo джекпот ,csgo jackpot ,jackpot ,steam,cs steam ,раздачи ,конкурсы ,рулетка скинов ,скины, cs go скины ,ставки рулетка ,cs:go, cs go ставки,рулетка вещей, cs go рулетка оружий ,cs go рулетка ,cs go играть рулетка ,скинов cs go лотерея ,сsgo лотерея вещей сsgo" />
    <meta name="description" content="CSGO-LIFE.COM - Испытай свою удачу!" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta name="csrf-token" content="{!!  csrf_token()   !!}">
   <link rel="shortcut icon" href="{{ asset('favicon.png') }}" />
    <link href="{{ asset('assets/css/animate.css') }}" rel="stylesheet">
    <link href="{{ asset('assets/css/jquery-ui.min.css') }}" rel="stylesheet">
    <link href="{{ asset('assets/css/normalize.css') }}" rel="stylesheet">
    <link href="{{ asset('assets/css/styles.css') }}" rel="stylesheet"> 
	<link href="{{ asset('assets/css/fonts.css') }}" rel="stylesheet">
    <script src="{{ asset('assets/js/inc.js') }}" ></script>
    <script src="{{ asset('assets/js/modals.js') }}" ></script>
    <script src="{{ asset('assets/js/main.js') }}" ></script>
    <script src="{{ asset('assets/js/jquery-ui.min.js') }}" ></script>
    <script src="{{ asset('assets/js/bootstrap.min.js') }}" ></script>

   <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

    <script>
    @if(!Auth::guest())
	<?php if($u->ban == 1) { die(include('/var/www/resources/views/errors/404.blade.php'));} ?>	
	var avatar = '{{ $u->avatar }}';
        const USER_ID = '{{ $u->steamid64 }}';

    @endif
        var START = true;
    </script>
</head>

    <div id="loader" class="corner">
        <div class="loader-inner ball-clip-rotate-multiple blue-loader">
            <div></div><div></div>
        </div>
    </div>
	


	
	
	<div class="notific queueMsg hidden">
	<div class="title">Системное уведомление</div>
	<div class="hint"><div>?</div></div>
	<div class="clear"></div>
	<div class="text">Подождите, ваш запрос обрабатывается</br><span id="vinvoc"></span></div>
</div>

<div class="notific declineMsg hidden">
	<div class="title">Системное уведомление</div>
	<div class="hint"><div>?</div></div>
	<div class="clear"></div>
	<div class="text">Ваше предложение обмена отклонено</br><span id="tradelinkser"></span></div>
</div>

<span id="country" hidden>{{ \App\Game::strana() }}</span>

<header>

	<div class="top">
		<div class="width">

			<a href="/" class="logotype"></a>

			
			<nav class="navbar navbar-default border-nav clearfix">
                <div class="navTop-left">
                    <div style="height: 44px;">

                        <ul class="nav navbar-nav navbar-right" style="float: left; margin-top: 30px;">
                            <li><a class="ajax" href="/top">Топ</a></li>
                            <li><a class="ajax" href="/history">История игр</a></li>
                            <li><a class="ajax" href="/about">О сайте</a></li>
                            <!-- <li><a data-modal="#fairplay" style="color: #D5DA94" href="#fairplay">Честная игра</a></li> -->
                            <li><a data-modal="#support" href="#">Поддержка</a></li>
                            <li><a href="https://vk.com/csgo.life_com" target="_blank" style="color: #D5DA94">ВКонтакте</a></li>
                        </ul>

                    </div>
                </div>
                <div class="profile-block clearfix">
                    @if(Auth::guest())
                        <a href="{{ route('login') }}" class="login-link loginbox"></a>
                    @else
                        <div class="profile-block-header">
                            <div class="profile-block-img">
                                <img src="{{ $u->avatar }}">
                            </div>
                            <a href="/logout" class="logout-link">Выйти</a>
                            <div class="profile-block-username">{{ $u->username }}</div>
                            <div class="profile-block-links">
                                <ul>
                                    <li><a href="/user/{{ $u->steamid64 }}" >Профиль</a></li>
                                    <li><a href="/myhistory">Мои игры</a></li>
                                    <li><a href="/myinventory">Инвентарь</a></li>
                                </ul>
                            </div>
                            <div class="offer-link">
                                <div class="input-group">
                                    <input placeholder="Вставьте ссылку на обмен..." value="{{ $u->trade_link }}" type="text">
                                    <button type="submit" class="input-group-addon save-link"></button>
                                </div>
                            </div>
                        </div>
                    @endif
                </div>
            </nav>
			<div class="clear"></div>
		</div>
	</div>



	     @yield('content')
		 
		 
	<!-- <middle> -->
</div>




<div class="popup_block" id="popup_name">
	<div class="title">Внести предметы в текущую игру</div>
	<div class="text">Выберите способ внесения предмета, вы можете внести предмет через клиент или браузер.</div>
	<div class="button">
		<a href="{{ route('deposit') }}" target="_blank">B</a>
		Браузер
	</div>
	<div class="txt">или</div>
	<div class="button">
	<a href="{{ route('deposit_client') }}" target="_blank">S</a>
		Клиент
		
	</div>
</div>

<div class="popup_block" id="popup_name-2">
	<div class="title">Внести депозит в текущую игру</div>
	<div class="text">Вы сможете вносить депозит карточками или предметами, для этого вам необходимо выбрать способ внесения. </div>
	<a href="#?w=550" rel="popup_name" class="poplight button-2 @if(empty($u->accessToken)) no-link @endif" target="_blank">Внести предметы</a>
	<div class="txt-2">или</div>
	<a href="#" rel="popup_name-7" class="button-2 poplight">Внести карточки</a>
	<div class="info">Добавление предметов происходит в течение нескольких секунд.</div>
</div>
	
@if(!Auth::guest())
	@if($u->is_admin == 1)
	<!-- modals-start chatadmin -->
	<div style="display: none;">
        <div id="chatAdmin" class="itemmodal" style=" width: 300px;">
		 <div class="popup_block" style="display: block;position: relative      ;top: 0%;      left: 0%;">
		 <div class="title">Удаление сообщений:</div>
		 <div class="adminbar">
		 <div class="chat">
		 <form action="#" method="GET" style="float: left;">
				<div class="form">
					<textarea name="message" cols="50" placeholder="Введите сообщение" autocomplete="off" style=" width: 205px;"></textarea>
					<input type="submit" value="" disabled>
				</div>
		 </form>
			<!--<div id="chat_messages"></div>-->
		 <div class="title">Забанить в чате:</div>
		 <form action="/ban_chat" method="GET" style="float: left;">
				<div class="form">
					<textarea name="steamid" cols="50" placeholder="Забанить чат: steamid" autocomplete="off" style=" width: 205px;"></textarea>
					<input type="submit" value="">
				</div>
		</form>
		<div class="title">Разбанить в чате:</div>
		<form action="/unban_chat" method="GET" style="float: left;">
				<div class="form">
					<textarea name="steamid" cols="50" placeholder="Разбанить чат: steamid" autocomplete="off" style=" width: 205px;"></textarea>
					<input type="submit" value="">
				</div>
		</form>
		@if($u->owner == 1)
		 <div class="title">Назначить модератора:</div>
		 <form action="/set_moder" method="GET" style="float: left;">
				<div class="form">
					<textarea name="steamid" cols="50" placeholder="SteamID" autocomplete="off" style=" width: 205px;"></textarea>
					<input type="submit" value="">
				</div>
		 </form>
		 @endif
		 <center><a class="vksupBtn" href="#">Отчистить чат</a></center><br>
		 </div>
		 </div>
		 </div>
        </div>
    </div>
	<!-- modals-end chatadmin -->
	@endif
@endif

  <!-- profile -->
  
	
	<div class="popup_block" id="popup_name-6">
	<div class="title">Карточки</div>
	<div class="total-cards">У вас 10 карточек, стоимостью в 6580 руб.</div>
	<div class="info-cards">В вашем профиле может быть не более 10 приобретенных карточек.<br>Это сделано для того чтобы вам было комфортнее ставить их в игру.</div>
	<div class="my-cards">
		<div class="ez-card">
			<div class="price">100 руб.</div>
			<a href="#" class="buy">Купить</a>
		</div>
		<div class="ez-card">
			<div class="price">100 руб.</div>
			<a href="#" class="buy">Купить</a>
		</div>
		<div class="ez-card">
			<div class="price">100 руб.</div>
			<a href="#" class="buy">Купить</a>
		</div>
		<div class="ez-card">
			<div class="price">100 руб.</div>
			<a href="#" class="buy">Купить</a>
		</div>
		<div class="ez-card">
			<div class="price">100 руб.</div>
			<a href="#" class="buy">Купить</a>
		</div>
		<div class="ez-card">
			<div class="price">100 руб.</div>
			<a href="#" class="buy">Купить</a>
		</div>
		<div class="ez-card">
			<div class="price">100 руб.</div>
			<a href="#" class="buy">Купить</a>
		</div>
		<div class="ez-card">
			<div class="price">100 руб.</div>
			<a href="#" class="buy">Купить</a>
		</div>
		<div class="ez-card">
			<div class="price">100 руб.</div>
			<a href="#" class="buy">Купить</a>
		</div>
		<div class="ez-card">
			<div class="price">100 руб.</div>
			<a href="#" class="buy">Купить</a>
		</div>
	</div>
</div>
	
		     @if(Auth::guest())
                       
                    @else
			
		
		<div class="popup_block" id="popup_name-5">
	<div class="title">Настройки профиля</div>
	<div class="text">Вам необходимо подтвердить ссылку на обмен и сохранить все параметры, нажав на кнопку “сохранить”.</div>
	<div class="url-input">
		<input type="text" id="trade" name="" value="{{ $u->trade_link }}" placeholder="Введите ссылку на обмен...">
		<input type="submit" name="" value="Сохранить" class=" save-link2">
	</div>
	<a href="http://steamcommunity.com/id/me/tradeoffers/privacy#trade_offer_access_url" target="_blank" class="get-link">Где взять ссылку?</a>
</div>

	 
<div class="popup_block" id="popup_name-7">
	<div class="title">Карточки</div>
	<!--<div class="total-cards">У вас 10 карточек, стоимостью в 6580 руб.</div>
	<div class="info-cards">У вас нету карточек для депозита.<br>Купите карточки, чтобы сделать депозит.</div>-->
	<div class="balance">
		<form method="GET" action="/pay">
			<input type="hidden" name="user_id" value="{{ $u->id }}">
			<div class="bal-text">Баланс: <span class="update_balance">{{ $u->money }}</span> руб.</div>
			<input type="text" name="sum" placeholder="Введите сумму">
			<input type="submit" name="" value="Пополнить">
		</form>
	</div>
    
	
	
	<div class="buy-cards">
	 @foreach(\App\Ticket::all() as $ticket)
		<div class="ez-card">
			<div class="price">{{ $ticket->price }}р.</div>
			<span class="buy"  onclick="addTicket({{ $ticket->id }}, this)">Купить</span>
		</div>

		   @endforeach
	</div>
	<div class="quest-cards">
		<div>ДЛЯ ЧЕГО НУЖНЫ КАРТОЧКИ?</div>Вы сможете вносить депoзит карточками, вместо предметов. Карточки моментально вносится в раунд без задержек. Карточки не теряются в стоимости и вы сможете поменять их в любой момент на предметы в нашем магазине <span>FastLoot.Me</span>.
	</div>
</div>
	
   @endif
	<div class="popup_block" id="popup_name-8">
	<div class="title">Честная игра</div>
	<div class="fair-text">
		<p>За каждый внесенную 1 копейку вы получаете 1 билет. Например, если вы внесли депозит на 100 руб, то выполучите 10000 билетов (т.к. 100р = 10000 копеек, а 1 копейка = 1 билет)</p>
		<p>В начале каждого раунда наша система берет абсолютно рандомное длинное число от 0 до 1 (например 0.83952926436439157) и шифрует его через md5. (если вы не знаете, что такое md5 - можете почитать статью на википедии)</p>
		<p>Затем, когда раунд завершился, система показывает то число, которое было шифровано вначале (проверить его вы можете на сайте md5.cz) и умножает его на банк (в копейках). Например, в конце раунда банк составил 1000 рублей а 1000 рублей = 100000 копеек (1 рубль = 100 копеек), то нужно будет число 0.83952926436439157 умножить на банк 100000 копеек (это цифры, которые мы брали для примера) и получим число 83952. То есть в раунде победит человек, у которого есть 83952 билет.</p>
			<p id="checkResult"></p>
		</div>
	<div class="fair-form">
		<div class="top-fair">ПРОВЕРКА ЧЕСТНОЙ ИГРЫ<span>Число раунда * банк (в копейках) = выигрышный билет</span></div>
		<div class="fair-inputs">
			<input type="text" id="roundHash1" name="" placeholder="Хэш раунда">
			<input type="text" id="roundNumber1" name="" placeholder="Число раунда">
			<input type="text" id="roundPrice1" name="" placeholder="Кол-во копеек в раунде">
			<input type="submit" id="checkHash" name="" value="ПРОВЕРИТЬ">
			
		</div>
	</div>
</div>
<footer>


		
		<a href="/" class="logotype"></a>

		<div class="social">
			<a href="http://vk.com/csgo.life_com" target="_blank"></a>
			<!-- <a href="http://twitter.com/"></a>
			<a href="http://fb.com/"></a> -->
		</div>

		<ul class="menu">
			<li><a href="/top">Топ</a></li>
			<li><a href="/history">История игр</a></li>
			<li><a href="/about">О сайте</a></li>
			<li><a data-modal="#support" href="#">Поддержка</a></li>
			@if(!Auth::guest())
			@if($u->is_admin == 1)
			<li><a data-modal="#chatAdmin" href="#">Управление чатом</a></li>
			@endif
			@endif
			<!--li><a href="/balance">Попоплнение баланса</a></li>
			<li><a href="/aboutmag">О магазине</a></li>
			<li><a href="/about">О сайте</a></li> -->
			
		</ul>

		<!--ul class="onlinefooter">
		<li class="onlinenum">Онлайн</li>
		<li class="onlinenum" id="online">25></li>
		</ul-->
		
		
<div class="chat"><a href="javascript://">Чат</a>

			<div class="sub">

			

			
			
			
				<div>
				<!--script>					$("scroll").scrollTop($("scroll")[0].scrollHeight); </script-->
                    <div id="chat_messages"></div>



				</div>

				
				
				
				@if(Auth::guest())
                <div></div>
                @else
				
				
				
<div class="form">
					<textarea name="" id="sendie" placeholder="Введите сообщение..."></textarea>
					<div style="float: right; overflow: hidden;">
						<!-- <div class="smiles"><a href="javascript://"></a>
							<div class="sub">
								<img src="/assets/img/smile/ak.png" alt="" title="" id="smile2" style="background:none;" onclick="add_smile(':ak:')"/>
								<img src="/assets/img/smile/colt.png" alt="" title="" id="smile2" style="background:none;" onclick="add_smile(':colt:')"/>
								<img src="/assets/img/smile/dagger.png" alt="" title="" id="smile2" style="background:none;" onclick="add_smile(':dagger:')"/>
								<img src="/assets/img/smile/dead.png" alt="" title="" id="smile2" style="background:none;" onclick="add_smile(':dead:')"/>
								<img src="/assets/img/smile/gogogo.png" alt="" title="" id="smile2" style="background:none;" onclick="add_smile(':gogogo:')"> 
								<img src="/assets/img/smile/hook.png" alt="" title="" id="smile2" style="background:none;" onclick="add_smile('hook')"/>
								<img src="/assets/img/smile/knife.png" alt="" title="" id="smile2" style="background:none;" onclick="add_smile(':knife:')"/>
								<img src="/assets/img/smile/n1.png" alt="" title="" id="smile2" style="background:none;" onclick="add_smile(':n1:')"/>
								<img src="/assets/img/smile/peew.png" alt="" title="" id="smile2" style="background:none;" onclick="add_smile(':peew:')"/>
								<img src="/assets/img/smile/zoom.png" alt="" title="" id="smile2" style="background:none;" onclick="add_smile(':zoom:')"/>

							</div>
						</div> -->
						<!--button class="button" type="submit" id="sendie"></button-->
						<input type="submit" id="sendie" name="Отправить" class="button" value="">
					</div>
					<div class="clear"></div>
				</div>
@endif
			</div>

		</div>


</footer>

<!--LiveInternet counter--><script type="text/javascript"><!--
document.write("<a href='//www.liveinternet.ru/click' "+
"target=_blank><img src='//counter.yadro.ru/hit?t52.6;r"+
escape(document.referrer)+((typeof(screen)=="undefined")?"":
";s"+screen.width+"*"+screen.height+"*"+(screen.colorDepth?
screen.colorDepth:screen.pixelDepth))+";u"+escape(document.URL)+
";"+Math.random()+
"' alt='' title='LiveInternet: показано число просмотров и"+
" посетителей за 24 часа' "+
"border='0' width='0' height='0'><\/a>")
//--></script><!--/LiveInternet-->


<script src="https://cdn.socket.io/socket.io-1.3.5.js"></script>
<script src="{{ asset('assets/js/app.js') }}" ></script>
<script src="{{ asset('assets/js/userChat.js') }}" ></script>
<script>
    @if(!Auth::guest())
    function updateBalance() {
        $.post('{{route('get.balance')}}', function (data) {
            $('.update_balance').text(data);
        });
    }
    function addTicket(id, btn){
        $.post('{{route('add.ticket')}}',{id:id}, function(data){
            updateBalance();
            return $(btn).notify(data.text, {position: 'top middle', className :data.type});
        });
    }
    @endif
</script>
<!-- Yandex.Metrika counter -->
<script type="text/javascript">
    (function (d, w, c) {
        (w[c] = w[c] || []).push(function() {
            try {
                w.yaCounter33459388 = new Ya.Metrika({
                    id:33459388,
                    clickmap:true,
                    trackLinks:true,
                    accurateTrackBounce:true
                });
            } catch(e) { }
        });

        var n = d.getElementsByTagName("script")[0],
            s = d.createElement("script"),
            f = function () { n.parentNode.insertBefore(s, n); };
        s.type = "text/javascript";
        s.async = true;
        s.src = "https://mc.yandex.ru/metrika/watch.js";

        if (w.opera == "[object Opera]") {
            d.addEventListener("DOMContentLoaded", f, false);
        } else { f(); }
    })(document, window, "yandex_metrika_callbacks");
</script>

<noscript><div><img src="https://mc.yandex.ru/watch/33459388" style="position:absolute; left:-9999px;" alt="" /></div></noscript>
<!-- Yandex.Metrika counter -->
<script type="text/javascript">
    (function (d, w, c) {
        (w[c] = w[c] || []).push(function() {
            try {
                w.yaCounter33695764 = new Ya.Metrika({
                    id:33695764,
                    clickmap:true,
                    trackLinks:true,
                    accurateTrackBounce:true
                });
            } catch(e) { }
        });

        var n = d.getElementsByTagName("script")[0],
            s = d.createElement("script"),
            f = function () { n.parentNode.insertBefore(s, n); };
        s.type = "text/javascript";
        s.async = true;
        s.src = "https://mc.yandex.ru/metrika/watch.js";

        if (w.opera == "[object Opera]") {
            d.addEventListener("DOMContentLoaded", f, false);
        } else { f(); }
    })(document, window, "yandex_metrika_callbacks");
		var BANNED_DOMAINS 	= '{{ \App\Game::zapretsite() }}';
</script>
<noscript><div><img src="https://mc.yandex.ru/watch/33695764" style="position:absolute; left:-9999px;" alt="" /></div></noscript>
<!-- /Yandex.Metrika counter -->
<!-- /Yandex.Metrika counter -->
</html>