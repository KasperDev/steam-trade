<div class="added">
<div class="short" id="bet_{{ $bet->id }}">
					<div class="top">
						<div class="avatar"><img src="{{ $bet->user->avatar }}" alt="" title="" /></div>
						<ul>
							<li>  <a class="username" href="/user/{{ $bet->user->steamid64 }}">{{htmlspecialchars(preg_replace('/' . \App\Game::zapretsite() . '/i', '', $bet->user->username)) }}</a>   
							
			
							<span class="chance_{{ $bet->user->steamid64 }}" style="color: #ccc">({{ \App\Http\Controllers\GameController::_getUserChanceOfGame($bet->user, $bet->game) }} %)</span></li>
							<li>Внёс: <span> 
							{{ $bet->itemsCount }} {{ trans_choice('lang.items', $bet->itemsCount) }}
							</span></li>
							<li>Общая сумма: <span>{{ $bet->price }} руб.</span></li>
						</ul>
						<div class="blanks">Билеты от <span class="from price">#{{ $bet->from }}</span> до <span class="to price">#{{ $bet->to }}</span></div>
				
			
				</div>

					<div class="items">
						 @foreach(json_decode($bet->items) as $i)
						 
						  @if(!isset($i->img))
						 
						<div class="itm" title="{{ $i->name }}">
						<div class="picture @if(!isset($i->img)){{ $i->rarity }} @else card up-card @endif"><img src="https://steamcommunity-a.akamaihd.net/economy/image/class/{{ \App\Http\Controllers\GameController::APPID }}/{{ $i->classid }}/70fx70f" alt="" title=""></div>
						<div class="price">{{ $i->price }} руб.</div>
						</div>
									 @else
							
								 <div class="itm" alt="" title="{{ $i->name }}" title="">
			<div class="price">{{ $i->price }} р.</div>
			
		</div>
				   @endif			
						
						    @endforeach
					</div>
				</div>
</div>

