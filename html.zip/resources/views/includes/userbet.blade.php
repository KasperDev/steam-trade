		<div class="block"><div>{{ \App\Http\Controllers\GameController::_getUserChanceOfGame($bet->user, $bet->game) }}%</div><img src="{{ $bet->user->avatar }}" alt="" title="" /></div>

		
