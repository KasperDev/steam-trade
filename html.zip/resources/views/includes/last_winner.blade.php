
<div class="last-winner">
	
			<img src="" alt="" title="" />
			<ul>
				<li><a href="#" data-profile=""></a></li>
				<li>Выигрыш: 8599 руб.</li>
				<li>Шанс: 65.95%</li>
			</ul>
		
		</div>
