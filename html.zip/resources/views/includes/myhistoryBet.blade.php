<div class="content">

<div class="other-title">История игр</div>

<div class="historys">
		<div class="h-short">

			<div class="user-info">
				<img src="{{ $game->winner->avatar }}" alt="" title="">
				<ul>
					<li><a href="/user/{{ $game->winner->steamid64 }}">{{htmlspecialchars(preg_replace('/' . \App\Game::zapretsite() . '/i', '', $game->winner->username ))}}</a></li>
					<li>Выигрыш: <span>{{ $game->price }}</span> руб.</li>
					<li>Шанс: <span>{{ $game->percent }}%</span></li>
				</ul>
			</div>
			
			<div class="right">
				<div class="top">
					<div class="number">Игра #{{ $game->id }}</div>
					<div class="infos">
						<div><acronym class="tooltip tooltipstered" title="{{ $game->updated_at }}">{{ $game->created_at->diffForHumans() }}</acronym></div>
						@if($game->status_prize == \App\Game::STATUS_PRIZE_WAIT_TO_SENT)
						<div class="successs">Выигрыш</div>
						@else
						<span class="errors">Проигрыш</span>
						@endif
						@else
						<span class="waits">Идёт игра...</span>
						@endif
					</div>
				</div>
				<div class="items">
				@if($bet->winner_id == $u->id)
					@foreach(json_decode($bet->won_items) as $i)
					<div class="itm tooltip" title="{{ $i->name }}">
						<div class="tooltip picture {{ $i->rarity }} tooltipstered"><img src="https://steamcommunity-a.akamaihd.net/economy/image/class/730/{{ $i->classid }}/70fx70f" alt="" title=""></div>
						<div class="price">{{$i->price}} руб.</div>
					</div>
					@endforeach
					@else
					@foreach($bet->items as $i)
					<div class="itm tooltip" alt="" title="{{ $i->name }}">
						<div class="tooltip picture card tooltipstered"><img src="http://etc.usf.edu/presentations/extras/buttons/icons_trans/22%20metallic%20gold/058.png" alt="" title=""></div>
						<div class="price">{{ round($i->price) }} р.</div>
					</div>
					@endforeach
				@endif
				</div>
			</div>
		</div>
			@empty
                <center><h1 style="color: #33BDA6;">Игр нет!</h1></center>
				<div class="profile-pag">{!! $games->render() !!}</div>
</div>