<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Lots extends Model
{
    protected $table = 'loot';

    public $timestamps = false;

    protected $fillable = ['user_id','game_id', 'to'];


}
