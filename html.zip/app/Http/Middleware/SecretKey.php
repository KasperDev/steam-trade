<?php

namespace App\Http\Middleware;

use Closure;

class SecretKey
{
    const IP_BOT = '127.0.0.1';
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        if($request->getClientIp() != self::IP_BOT) return response()->json('Invalid Request');
        return $next($request);
    }
}
