<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Carbon\Carbon;
use App\Http\Requests;
use App\Http\Controllers\Controller;

class ChatController extends Controller
{
    public function delete_message(Request $request)
    {
        $message_id = htmlspecialchars($request->get('id'));
        $admin = $this->user->is_admin;

        if($admin == 1) {
            \DB::table('chat')->where('id', $message_id)->delete();
            return response()->json(['message' => 'Сообщение успешно удалено !' , 'status' => 'success' , 'title' => 'Успех']);
        }
        else
        {
            return response()->json(['message' => 'Вы не являетесь администратором !' , 'status' => 'error' , 'title' => 'Ощибка']);
        }

    }
	
	public function ban_user(Request $request)
    {
        $steamid = htmlspecialchars($request->get('steamid'));
        $admin = $this->user->is_admin;
        $userid = $this->user->steamid64;

        if($admin == 1) {
            if($userid !== $steamid) {
                \DB::table('users')->where('steamid64', $steamid)->update(array('banchat' => 1));
                return response()->json(['message' => 'Пользователь успешно забанен', 'status' => 'success', 'title' => 'Успех']);
            }
            else{
                return response()->json(['message' => 'Вы не можете забанить самого себя', 'status' => 'error', 'title' => 'Ошибка']);
            }
        }
        else
        {
            return response()->json(['message' => 'Вы не являетесь администратором !' , 'status' => 'error' , 'title' => 'Ощибка']);
        }

    }
   
    public function add_message(Request $request)
{
   
   
    $stavki = \DB::table('bets')->where('user_id', $this->user->id)->get();
    if($stavki == 0){
       
      return response()->json(['stavki'=>'Вы должны сыиграть хотя бы один раз']);   
    }
   
   
    if($this->user->banchat==1){
return response()->json(['clear'=>'Вы забанены в чате ! Срок : Навсегда']);       
    }
   
$userid = $this->user->steamid64;
$admin = $this->user->is_admin;
$username =  htmlspecialchars($this->user->username);
$avatar = $this->user->avatar;
$messages = $this->_validateMessage($request);


   
\DB::table('chat')->insertGetId(['userid' => $userid, 'avatar' => $avatar, 'messages' => htmlspecialchars($messages), 'username' => $username , 'admin' => $admin]);

$list = array();
	foreach($messages as $key => $value){
$value['messages'] =strip_tags($value['messages']);
$value['messages'] =str_replace(":ak:","<img style='background:none;' id=smile src=/assets/img/smile/ak.png>",$value2[$i]['messages']);
$value['messages'] =str_replace(":-d","<img style='background-position: 0px -17px' id=smile src=/styles/images/chat/white.gif>",$value['messages']);
$value['messages'] =str_replace(";-)","<img style='background-position: 0px -34px' id=smile src=/styles/images/chat/white.gif>",$value['messages']);
$value['messages'] =str_replace("xd","<img style='background-position: 0px -51px' id=smile src=/styles/images/chat/white.gif>",$value['messages']);
$value['messages'] =str_replace(";-p","<img style='background-position: 0px -68px' id=smile src=/styles/images/chat/white.gif>",$value['messages']);
$value['messages'] =str_replace(":-p","<img style='background-position: 0px -85px' id=smile src=/styles/images/chat/white.gif>",$value['messages']);
$value['messages'] =str_replace("8-)","<img style='background-position: 0px -102px' id=smile src=/styles/images/chat/white.gif>",$value['messages']);
$value['messages'] =str_replace("b-)","<img style='background-position: 0px -119px' id=smile src=/styles/images/chat/white.gif>",$value['messages']);
$value['messages'] =str_replace(":-(","<img style='background-position: 0px -136px' id=smile src=/styles/images/chat/white.gif>",$value['messages']);
$value['messages'] =str_replace(";-]","<img style='background-position: 0px -153px' id=smile src=/styles/images/chat/white.gif>",$value['messages']);
$value['messages'] =str_replace("u—(","<img style='background-position: 0px -170px' id=smile src=/styles/images/chat/white.gif>",$value['messages']);
$value['messages'] =str_replace(":l(","<img style='background-position: 0px -187px' id=smile src=/styles/images/chat/white.gif>",$value['messages']);
$value['messages'] =str_replace(":_(","<img style='background-position: 0px -204px' id=smile src=/styles/images/chat/white.gif>",$value['messages']);
$value['messages'] =str_replace(":((","<img style='background-position: 0px -221px' id=smile src=/styles/images/chat/white.gif>",$value['messages']);
$value['messages'] =str_replace(":o","<img style='background-position: 0px -238px' id=smile src=/styles/images/chat/white.gif>",$value['messages']);
$value['messages'] =str_replace(":|","<img style='background-position: 0px -255px' id=smile src=/styles/images/chat/white.gif>",$value['messages']);
$value['messages'] =str_replace("3-)","<img style='background-position: 0px -272px' id=smile src=/styles/images/chat/white.gif>",$value['messages']);
$value['messages'] =str_replace("o*)","<img style='background-position: 0px -323px' id=smile src=/styles/images/chat/white.gif>",$value['messages']);
$value['messages'] =str_replace(";o","<img style='background-position: 0px -340px' id=smile src=/styles/images/chat/white.gif>",$value['messages']);
$value['messages'] =str_replace("8o","<img style='background-position: 0px -374px' id=smile src=/styles/images/chat/white.gif>",$value['messages']);
$value['messages'] =str_replace("8|","<img style='background-position: 0px -357px' id=smile src=/styles/images/chat/white.gif>",$value['messages']);
$value['messages'] =str_replace(":x","<img style='background-position: 0px -391px' id=smile src=/styles/images/chat/white.gif>",$value['messages']);
$value['messages'] =str_replace("*3","<img style='background-position: 0px -442px' id=smile src=/styles/images/chat/white.gif>",$value['messages']);
$value['messages'] =str_replace(":-*","<img style='background-position: 0px -409px' id=smile src=/styles/images/chat/white.gif>",$value['messages']);
$value['messages'] =str_replace("}^)","<img style='background-position: 0px -425px' id=smile src=/styles/images/chat/white.gif>",$value['messages']);
$value['messages'] =str_replace(">((","<img style='background-position: 0px -306px' id=smile src=/styles/images/chat/white.gif>",$value['messages']);
$value['messages'] =str_replace(">(","<img style='background-position: 0px -289px' id=smile src=/styles/images/chat/white.gif>",$value['messages']);
$value['messages'] =str_replace(":like:","<img style='background-position: 0px -459px' id=smile src=/styles/images/chat/white.gif>",$value['messages']);
$value['messages'] =str_replace(":dislike:","<img style='background-position: 0px -476px' id=smile src=/styles/images/chat/white.gif>",$value['messages']);
$value['messages'] =str_replace(":u:","<img style='background-position: 0px -493px' id=smile src=/styles/images/chat/white.gif>",$value['messages']);
$value['messages'] =str_replace(":v:","<img style='background-position: 0px -510px' id=smile src=/styles/images/chat/white.gif>",$value['messages']);
$value['messages'] =str_replace(":kk:","<img style='background-position: 0px -527px' id=smile src=/styles/images/chat/white.gif>",$value['messages']);
$value['messages'] =str_replace("👏","<img style='background:none;' id=smile src=/styles/images/chat/D83DDC4F.png>",$value['messages']);
$value['messages'] =str_replace("👊","<img style='background:none;' id=smile src=/styles/images/chat/D83DDC4A.png>",$value['messages']);
$value['messages'] =str_replace("✋","<img style='background:none;' id=smile src=/styles/images/chat/270B.png>",$value['messages']);
$value['messages'] =str_replace("🙏","<img style='background:none;' id=smile src=/styles/images/chat/D83DDE4F.png>",$value['messages']);
$value['messages'] =str_replace("👃","<img style='background:none;' id=smile src=/styles/images/chat/D83DDC43.png>",$value['messages']);
$value['messages'] =str_replace("👆","<img style='background:none;' id=smile src=/styles/images/chat/D83DDC46.png>",$value['messages']);
$value['messages'] =str_replace("👇","<img style='background:none;' id=smile src=/styles/images/chat/D83DDC47.png>",$value['messages']);
$value['messages'] =str_replace("👈","<img style='background:none;' id=smile src=/styles/images/chat/D83DDC48.png>",$value['messages']);
$value['messages'] =str_replace("💪","<img style='background:none;' id=smile src=/styles/images/chat/D83DDCAA.png>",$value['messages']);
$value['messages'] =str_replace("👂","<img style='background:none;' id=smile src=/styles/images/chat/D83DDC42.png>",$value['messages']);
$value['messages'] =str_replace("💋","<img style='background:none;' id=smile src=/styles/images/chat/D83DDC8B.png>",$value['messages']);
$value['messages'] =str_replace("💩","<img style='background:none;' id=smile src=/styles/images/chat/D83DDCA9.png>",$value['messages']);
$value['messages'] =str_replace("❄","<img style='background:none;' id=smile src=/styles/images/chat/2744.png>",$value['messages']);
$value['messages'] =str_replace("🍷","<img style='background:none;' id=smile src=/styles/images/chat/D83CDF77.png>",$value['messages']);
$value['messages'] =str_replace("🍸","<img style='background:none;' id=smile src=/styles/images/chat/D83CDF78.png>",$value['messages']);
$value['messages'] =str_replace("🎅","<img style='background:none;' id=smile src=/styles/images/chat/D83CDF85.png>",$value['messages']);
$value['messages'] =str_replace("💦","<img style='background:none;' id=smile src=/styles/images/chat/D83DDCA6.png>",$value['messages']);
$value['messages'] =str_replace("👺","<img style='background:none;' id=smile src=/styles/images/chat/D83DDC7A.png>",$value['messages']);
$value['messages'] =str_replace("🐨","<img style='background:none;' id=smile src=/styles/images/chat/D83DDC28.png>",$value['messages']);
$value['messages'] =str_replace("🍌","<img style='background:none;' id=smile src=/styles/images/chat/D83CDF4C.png>",$value['messages']);
$value['messages'] =str_replace("🏆","<img style='background:none;' id=smile src=/styles/images/chat/D83CDFC6.png>",$value['messages']);
$value['messages'] =str_replace("🎲","<img style='background:none;' id=smile src=/styles/images/chat/D83CDFB2.png>",$value['messages']);
$value['messages'] =str_replace("🍺","<img style='background:none;' id=smile src=/styles/images/chat/D83CDF7A.png>",$value['messages']);
$value['messages'] =str_replace("🍻","<img style='background:none;' id=smile src=/styles/images/chat/D83CDF7B.png>",$value['messages']);

		$list[] = $value;
	}

return response()->json(['succes'=>'Ваше сообщение отправлено']);

}
  
  
   private function _validateMessage($request)
    {
        $val = \Validator::make($request->all(), [
            'messages' => 'required|string|max:255'
        ],[
            'required' => 'Сообщение не может быть пустым!',
            'string' => 'Сообщение должно быть строкой!',
            'max' => 'Максимальный размер сообщения 255 символов.',
        ]);
        if($val->fails())
            $this->throwValidationException($request, $val);

        return $request->get('messages');
    }
  
    public function getchat(Request $request)
{
   
   
    
   
$messages = \DB::table('chat')->orderBy('id', 'desc')->take(30)->get();   

   
return $messages;   
   
}
  

}