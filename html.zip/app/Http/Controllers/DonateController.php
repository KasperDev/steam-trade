<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\Services\GDonate\GDonate;
use App\Services\GDonate\GDonateEvent;
use App\Services\Unitpay\UnitPay;
use App\Services\Unitpay\UnitPayEvent;

class DonateController extends Controller
{
	
	
	 public function GDonateDonate(Request $request)
    {
        $payment = new GDonate(
            new GDonateEvent(),
            $request
        );
        return $payment->getResult();
    }
	
	
	
	
    public function unitpayDonate(Request $request)
    {
        $payment = new UnitPay(
            new UnitPayEvent(),
            $request
        );
        return $payment->getResult();
    }
}
