<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Carbon\Carbon;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\User;
use App\Support;
class SupportController extends Controller
{
	
	
	
	public function support(Request $request)
{
$tickets = \DB::table('support')->where('user_id',$this->user->id)->orderBy('id', 'desc')->get();

return view('support.index', compact('tickets'));
}

public function ticket($ticketId){
		
		
$loots = \DB::table('lootgames')->join('loot', function($join){
                $join->on('lootgames.id', '=', 'loot.game_id')
                    ->where('loot.user_id', '=', $this->user->id);
            })->join('users', 'lootgames.user_id', '=', 'users.id') ->groupBy('lootgames.id')
            ->orderBy('lootgames.id', 'desc')
->select('lootgames.*', 'users.username as winner_username', 'users.steamid64 as winner_steamid64','users.avatar as winner_avatar')

->orderBy('id', 'steam_price')->get();

return view('support.ticket', compact('loots'));


	}
	
	
	
	
	}