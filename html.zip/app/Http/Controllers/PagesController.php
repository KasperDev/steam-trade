<?php

namespace App\Http\Controllers;

use App\Bet;
use App\Game;
use App\Item;
use App\Services\SteamItem;
use App\User;
use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\Http\Controllers\GameController;

require '/var/www/html/vendor/nesbot/carbon/src/Carbon/Carbon.php';
use Carbon\Carbon;

class PagesController extends Controller
{

	const MERCHANT_ID = 18304;
	const SECRET_WORD = 'ifhbr1';
	const SECRET_WORD2 = 'ifhbr';
    
	public function about()
    {
        return view('pages.about');
    }
	
	public function giveaway()

    {



$giveaway = \DB::table('givegame')->join('giveaway', 'givegame.id', '=', 'giveaway.giveawayid')->orderBy('id', 'desc')
				->select('giveaway.id','giveaway.userid')->take(13)->get();
            //->where('bets.user_id', $this->user->id)
			
		//$givegame = \DB::table('givegame')->orderBy('id', 'desc')->get();
		
	// $giveaway = \DB::table('givegame')->where('giveaway.id' , '=', $givegame)->orderBy('id', 'desc')->get();
		//foreach($games as $game){
				// $game->percent = GameController::_getUserChanceOfGame($game->winner, $game);
				
			
		//	}
			
			//, json_decode($game->won_items, true)
			
			
			
			$giveaway2 = \DB::table('givegame')->join('giveaway', 'givegame.id', '=', 'giveaway.giveawayid')->orderBy('id', 'desc')
				->select('giveaway.id','giveaway.userid')->get();
			
				$givegame = \DB::table('givegame')->orderBy('id', 'desc')->get();
				
				
		
		foreach($giveaway as $i){
			$user = User::find($i->userid);
	        $i->username = $user->username;
			$i->avatar = $user->avatar;
		}
				
				
				
				
					
				
			
		return view('pages.giveaway', compact('giveaway','giveaway2','givegame','givegamedate'));	
       // return $giveaway;

    }

	
	

	public function pay(Request $request)
    {
		$sum = $request->get('sum');
		$u = $this->user;
		header('Location: https://api.gdonate.ru/pay?public_key='.\App\Http\Controllers\GameController::GDonate2keypublic.'&sum='.$sum.'&account='.$u->id.'&desc=Пополнение баланса на CSGO-LIFE.COM');
		exit();
    }
	
	public function statuspay(Request $request)
    {

		return view('pages.statuspay');
	}	
	
	public function fail()
    {
		session(['order_id' => '']);
		return view('pages.fail');
	}	
	
	   public function store()
    {
        return view('pages.store');
    }
	
	
    public function top()
    {
        $users = \DB::table('users')
            ->select('users.id',
				'users.username',
                'users.avatar',
                'users.steamid64',
                \DB::raw('SUM(games.price) as top_value'),
                \DB::raw('COUNT(games.id) as wins_count')
            )
            ->join('games', 'games.winner_id', '=', 'users.id')
            ->groupBy('users.id')
            ->orderBy('top_value', 'desc')
            ->limit(20)
            ->get();
        $place = 1;
        $i = 0;
		foreach($users as $u){
			$users[$i]->games_played = count(\DB::table('games')
				->join('bets', 'games.id', '=', 'bets.game_id')
				->where('bets.user_id', $u->id)
				->groupBy('bets.game_id')
				->select('bets.id')->get());
			$users[$i]->win_rate = round($users[$i]->wins_count / $users[$i]->games_played, 3) * 100;
			$i++;
		}
        return view('pages.top', compact('users', 'place'));
    }

    public function profile()
    {
        $games = Game::where('winner_id', $this->user->id)->get();
        $wins = $games->count();
        $gamesPlayed = count(\DB::table('games')
            ->join('bets', 'games.id', '=', 'bets.game_id')
            ->where('bets.user_id', $this->user->id)
            ->groupBy('bets.game_id')
            ->select('bets.id')->get());
        $looses = $gamesPlayed - $wins;
        $win_price = $games->sum('price');
        return view('pages.profile', compact('wins', 'looses', 'win_price'));
    }

    public function settings()
    {
        return view('pages.settings');
    }

    public function myhistory()
    {
       /* $games = \DB::table('games')
            ->join('bets', function($join){
                $join->on('games.id', '=', 'bets.game_id')
                    ->where('bets.user_id', '=', $this->user->id);
            })
            ->join('users', 'games.winner_id', '=', 'users.id')
            ->groupBy('games.id')
            ->orderBy('games.id', 'desc')
            ->select('games.*', 'users.username as winner_username', 'users.steamid64 as winner_steamid64','users.avatar as winner_avatar')
            ->get();*/
		     $games = Game::with(['bets', 'winner'])->join('bets', function($join){
                $join->on('games.id', '=', 'bets.game_id')
                    ->where('bets.user_id', '=', $this->user->id);
            })
            ->join('users', 'games.winner_id', '=', 'users.id')
            ->groupBy('games.id')
            ->orderBy('games.id', 'desc')
            ->select('games.*', 'users.username as winner_username', 'users.steamid64 as winner_steamid64','users.avatar as winner_avatar')
            ->paginate(10);
			foreach($games as $game){
				 $game->percent = GameController::_getUserChanceOfGame($game->winner, $game);
				
			}
			
		/*foreach($games as $game){
			$game->percent = GameController::_getUserChanceOfGameByUser($game->id, $this->user->id, $game->price);
					
		}*/
			
        return view('pages.myhistory', compact('games'));
    }

    public function history()
    {
        $games = Game::with(['bets', 'winner'])->where('status', Game::STATUS_FINISHED)->orderBy('created_at', 'desc')->paginate(10);
		foreach($games as $game){
				 $game->percent = GameController::_getUserChanceOfGame($game->winner, $game);
				
			
			}
			
			//, json_decode($game->won_items, true)
			
			
        return view('pages.history', compact('games'));
    }
	
	  public function last_winner()
    {
		
		
      //  $games =  \DB::table('games')->where('status', Game::STATUS_FINISHED)->orderBy('created_at', 'desc')->get();
        $givegame = \DB::table('givegame')->orderBy('id', 'desc')->get();
		return view('includes.last_winner', compact('givegame'));
		//return view('pages.history', compact('games'));
    }
	
	    private function _getChancesOfGame($game, $is_object = false)
    {
        $chances = [];
        foreach($game->users() as $user){
            if($is_object){
                $chances[] = (object) [
                    'chance' => GameController::_getUserChanceOfGame($user, $game),
                    'avatar' => $user->avatar,
                    'items' => User::find($user->id)->itemsCountByGame($game),
                    'steamid64'  => $user->steamid64
                ];
            }else{
                $chances[] = [
                    'chance' => GameController::_getUserChanceOfGame($user, $game),
                    'avatar' => $user->avatar,
                    'items' => User::find($user->id)->itemsCountByGame($game),
                    'steamid64'  => $user->steamid64
                ];
            }

        }
        return $chances;
    }
	
		public function user($userId)
    {
        $user = User::where('steamid64', $userId)->first();
        if(!is_null($user)) {
            $games = Game::where('winner_id', $user->id)->get();
            $wins = $games->count();
            $gamesPlayed = \DB::table('games')
                ->join('bets', 'games.id', '=', 'bets.game_id')
                ->where('bets.user_id', $user->id)
                ->groupBy('bets.game_id')
                ->orderBy('games.created_at', 'desc')
                ->select('games.*', \DB::raw('SUM(bets.price) as betValue'))->paginate(10);
			$gamesPlayed2 = \DB::table('games')
                ->join('bets', 'games.id', '=', 'bets.game_id')
                ->where('bets.user_id', $user->id)
                ->groupBy('bets.game_id')
                ->orderBy('games.created_at', 'desc')
                ->select('games.*', \DB::raw('SUM(bets.price) as betValue'))->paginate(10);
            $gamesList = [];
            $i = 0;
            foreach ($gamesPlayed as $game) {
                $gamesList[$i] = (object)[];
                $gamesList[$i]->id = $game->id;
                $gamesList[$i]->win = false;
                $gamesList[$i]->bank = $game->price;
				$gamesList[$i]->updated_at = $game->updated_at; 
				$gamesList[$i]->created_at = Carbon::parse( $game->created_at )->diffForHumans();
                if ($game->status != Game::STATUS_FINISHED) $gamesList[$i]->win = -1;
                if ($game->winner_id == $user->id) $gamesList[$i]->win = true;
                $gamesList[$i]->chance = round($game->betValue / $game->price, 3) * 100;
                $i++;
            }
                $username = $user->username;
                $avatar = $user->avatar;
                $votes = $user->votes;
                $wins = $wins;
                $url = 'http://steamcommunity.com/profiles/' . $user->steamid64 . '/';
                $winrate = count($gamesPlayed) ? round($wins / count($gamesPlayed), 3) * 100 : 0;
                $totalBank = $games->sum('price');
                $games = count($gamesPlayed);
				$games2 = $gamesPlayed2;
                $list = $gamesList;
                $title = $username.' | ';
        }
        else
        {
            return redirect()->route('index');
        }

        return view('pages.user', compact('username', 'avatar', 'votes', 'wins', 'url' , 'winrate' , 'totalBank' , 'games', 'games2', 'list' , 'title'));
    }

    public function game($gameId)
    {
		
		
        if(isset($gameId) && Game::where('status', Game::STATUS_FINISHED)->where('id', $gameId)->count()){
            $game = Game::with(['winner'])->where('status', Game::STATUS_FINISHED)->where('id', $gameId)->first();
            $game->ticket = floor($game->rand_number * ($game->price * 100));
            $bets = $game->bets()->with(['user','game'])->get()->sortByDesc('created_at');
			
            $chances = [];
			$percents = $this->_getChancesOfGame($game, true);
            return view('pages.game', compact('game', 'bets', 'chances','percents'));
        }
        return redirect()->route('index');
    }

    public function myinventory(Request $request)
    {
        if($request->getMethod() == 'GET'){
            return view('pages.myinventory');
        }else{
            if(!\Cache::has('inventory_' . $this->user->steamid64)) {
                $jsonInventory = file_get_contents('http://steamcommunity.com/profiles/' . $this->user->steamid64 . '/inventory/json/730/2?l=russian');
                $items = json_decode($jsonInventory, true);
                if ($items['success']) {
                    foreach ($items['rgDescriptions'] as $class_instance => $item) {
                        $info = Item::where('market_hash_name', $item['market_hash_name'])->first();
                        if (is_null($info)) {
                            $info = new SteamItem($item);
                            if ($info->price != null) {
                                Item::create((array)$info);
                            }
                        }
                        $items['rgDescriptions'][$class_instance]['price'] = $info->price;
                    }

                }
                \Cache::put('inventory_' . $this->user->steamid64, $items, 15);
            }else{
                $items = \Cache::get('inventory_' . $this->user->steamid64);
            }
            return $items;
        }
    }
}
