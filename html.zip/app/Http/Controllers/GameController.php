<?php

namespace App\Http\Controllers;
use App\WinnerTicket;
use App\Bet;
use App\Game;
use App\Item;
use App\Services\SteamItem;
use App\Ticket;
use App\User;
use Carbon\Carbon;
use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;

class GameController extends Controller
{
	const GDonate2keypublic = '';
	const GDonate2key = '';
	const FILTERS    = '(CSGO-BEST|CRAZY-BETS|kickback|ez-win|LUCKYDROP|CSGOEASYSKIN|EASYSKIN|csgetto|CSGOBIX|CSGOWOW|csgoup|csgofast|csgolucky|csgo777|csgocasino|game-luck|g2a|csgostar|hellstore|cs-drop|csgo|csgoshuffle|csgotop|csbets|csgobest|csgolike|fast-jackpot|skins-up|hardluck-shop|csgogamble|csgohot|csgofairplay|csgohappy|csgomet|csgohunter|csgoluxe|csgostart|csgo-online|csgottzed|csgotrick|csgorage|csplayer|csgo-chance|csgoswag|csgopvp|mycsarena|csgostars|ezyskins|csbets|csgo-skin-raffle|exgame|csgo4bet|csgo-luxe|csgowinner|csgo-wtf|csgo-asiimov|treasuretoken|ezskinz|csgofresh|csgotrophy|csgogold|csgomagic|catskins|lucky-hand|csgorand|csgobig|csgoduck|csgoammo|csgoway|skins-pro|hard-lucky|csgo-rich|csgoeasy|game-raffle|uitems|csgo-easy|crazy-random|csgo-raffle|csgo-ezpz|csgorumble|lucky-hand|csgonice|csgodraw|csgopick|csgoninja|csgo-winner|csrandom|csgomany|csgolotter|csgokill|ezpzskins|csgofb|csgo1|csgojackpot|kinguin|realskins|csgofart|csgoline|csgoprime|csgolt|onlycs|csgoblaze|dropcsgo-ezz|csgobetes|csmonkey|d2fortune|csgoforce|csgobig|csgovulcan|dota2house|ezitems|csgofox|csgo-ez|csgohs|csgobp|csgovictory|csgo-farm|csgo-lottery|csgo777|csgobank|timeluck|easydrop|csgogift|hardlucky|CSGOSWIFT|skinbets|CSGO-SHOT|CSLOTS|BEELOTERY|CSGOBR|CSGOFAIRPLAY|CSGO-ES|DropSmurf|csgo|CSGOSKINZ|CSGODROPZ|CSGOTROPHY|SkinProfit|UPSKINS|CSGO-PLATINUM|CSGORaffling|csgod|CSGO-JACKPOT|csgo-deposit|easy-skins|ezskinz|CSGOENJOY|CSGOcraft|godrop|JackBets|TopRuletka|CSGOFakeBet|CSGOSELLER|CS-TICKET|csgo-winner|CSGOJUST|CSGOCoin|csgoselector|CSGOFLY|CSGOHAP|GODROP|CSLOTTERY|itemgrad|CSGOIN|csgohouse|csgo-dog|csgobets|CShot|RULETKACSGO|D2DELECTOR|CSGOHyper|CSGOLUX|GODROP|CSGO-MANIA|ezpzskinz|CSGOEX|evil-bets|CSGOWAR|lootbox|onbeast|CSGONOW|crimson|CSGOFORCE|CSGOI3I|CSGOBET|CSGO4FUN|CSGOQUALITY|CSGO-DROPS|EZYGAME|CSGOBLESS|D2SELECTOR|SkinoDro4|FLASHSKINS|CSGO-FIRE|csgocloud|CSGOPEAK|CSGAMBLING|csgoing|royalpot|CSGOSKINSWAR|twitch|CSGOEZY|superskins|BOOMLOTERY|CSGOFORS|MLGBets|csprize|csgoonly|CSGOFORS|flashinew|FUNGUN|csgoexpress|CSGOLDEN|CSGO-HOPE|CSGOHF|CSGO-FARMING|CSGO-SHOT|CSGOEVENT|CSGOlite|SkinsFast|CSGOEASYSKIN|CSGO-JAKPOT|CSGOPOOR|CSGOGAMBLING|CSGO-FACTORY|CSGOLOW|FASTPLAY|csgogalaxy|CSGOHELL|CSGO-BLACK|csbattle|CsgoDesert|CSGOROLLER|CSGO-VIP|CSGOJOKER|HELLBETS|csgofort|CSGO-FATE|csgofresh|OVERSKIN|CS-LOVING|csgo-speed|CSGOENERGY|CSGOWONDER|jointime|CSGOGAMES|CSGODAY|FIRESKINS|tradeigr|CSGOBRAWL|CSGOFOCUS|csgo|Rus-roulette|skinhunt|FIRSTCASE|CSGORiot|csgofarming|CSPOT|Hell-Drop|CSBULLET|CSGOMASTER|CSGOUP|ezsking|agro-bets|CSGORUN|CSPL|GOGUN|GUN|FUCKSKINS|CSGOBANG|USKINS|CSGO-BILLY|CS-SHOTS|CSGOCASE|SKINS|CSGOEZBET|CSGOFunPot|lucky-cowboy|csgoRamboPot|csgo1337|csgoforwin|SKINSFARM|SGO-HOPE|moneday|CSGОSНUFFLE|CSNova|EWRYDAY|CSGOPODARKI|csgo-lore|GOLD-FEVER|csup|CSGOEFFECT|fastday|SKINWIN|CsGoLottary|Dota-Azart|YSKIN|CSLOL|CSFARM|csgolite|CSGOSELE|REALDROP|CSGO-HF|CSJUST|CSGOLDSHOOT|cs-fortune|SHOT-DEAD|CSGOEvo|CSGORULETE|MEGALUCKY|CSGOSTICK|CSKINGS|DESIRE-LOTTERY|csgofat|FERNO|SkinsGo|CSGO-FIRST|cscool)\.(com.pl|pw|xyz|me|us|ML|in|me|as|org|ru|su|com|net|gl|tv|farm|one|tk|us|gg|pro|c|cc|esy.es|site|gq)';
    const SECRET_KEY    = '';
    const BOT_TRADE_LINK = 'https://steamcommunity.com/tradeoffer/new/?partner='; # Трейд ссылка
    const BOT_STEAMID64 = '';  # Стим id бота
	const MAX_ITEMSALL  = 50;                   # Максимально вещей в игре
	const MIN_USERS     = 2;                    # Минимально игроков для начала игры
    const MIN_PRICE     = 1;                    # Минимальная ставка
    const MAX_ITEMS     = 20;                   # Максимальное кол-во предметов в ставке
    const COMMISSION    = 0;                   # Комиссия
    const COMMISSION_FOR_FIRST_PLAYER    = 0;   # Комиссия для первого игрока сделавшего ставку.
    const APPID         = 730;                  # AppID игры: 570 - Dota2, 730 - CS:GO

    const SEND_OFFERS_LIST = 'send.offers.list';
    const NEW_BET_CHANNEL = 'newDeposit';
    const BET_DECLINE_CHANNEL = 'depositDecline';
    const INFO_CHANNEL = 'msgChannel';
    const SHOW_WINNERS = 'show.winners';

    public $game;

    protected $lastTicket = 0;

    private static $chances_cache = [];

    public function __construct()
    {
        parent::__construct();
        $this->game = $this->getLastGame();
        $this->lastTicket = $this->redis->get('last.ticket.' . $this->game->id);
        if(is_null($this->lastTicket)) $this->lastTicket = 0;
    }

    public function deposit()
    {
        return redirect(self::BOT_TRADE_LINK);
    }
	
	public function deposit_client()
    {
        return redirect('steam://url/SteamIDPage/'.self::BOT_STEAMID64 );
    }
	


    public function currentGame()
    {
        $game = Game::orderBy('id', 'desc')->first();
        $percents = $this->_getChancesOfGame($game, true);
        $bets = $game->bets()->with(['user','game'])->get()->sortByDesc('created_at');
        $user_chance = $this->_getUserChanceOfGame($this->user, $game);
				$giveaway = \DB::table('givegame')->orderBy('id', 'desc')->get();
		$shmot  = \DB::table('shop')->where('status' , '=', 0)->orderBy('price', 'desc')->take(4)->get();
			foreach($giveaway as $i){
			
	        $giveawayitemss = $i->items;
			$giveawayclassid = $i->classid;
				$giveawaydate = $i->date;
		}
			$last_winner  = \DB::table('games')->where('status' , '=', 3)->orderBy('id', 'desc')->take(1)->get();
		
foreach($last_winner as $last){
	
$user5 = User::find($last->winner_id);

$lastwinavatar = $user5->avatar;
$lastwinname = preg_replace('/' . \App\Game::zapretsite() . '/i', '',$user5->username);
$lastwinmoney = $last->price;
$lastwinpercent = GameController::_getUserChanceOfGame($user5, $last);
$lastwin64 = $user5->steamid64;


	}
		
		
		
        if(!is_null($this->user))
            $user_items = $this->user->itemsCountByGame($game);
        return view('pages.index', compact('game', 'bets', 'shmot', 'user_chance', 'user_items', 'percents','giveaway','giveawayitemss','giveawayclassid','giveawaydate','lastwinavatar','lastwinname','lastwinmoney','lastwinpercent','lastwin64'));
    }

	public function lastwinner()
    {
		
			$last_winner  = \DB::table('games')->where('status' , '=', 3)->orderBy('id', 'desc')->take(1)->get();
	
     foreach($last_winner as $last){
	
$user = User::find($last->winner_id);
 $last->username = $user->username;
$last->avatar = $user->avatar;
$last->steamid64 = $user->steamid64;
$last->percent = GameController::_getUserChanceOfGame($user, $last);



	}
	
	      $returnValue = [
            'username' => preg_replace('/' . \App\Game::zapretsite() . '/i', '',$last->username),
			'avatar' => $last->avatar,
            'steamid64' => $last->steamid64,
            'percent' => $last->percent,
			'price'            => $last->price
        ];

        return response()->json($returnValue);
	
	

    }
	
	
	
    public function getLastGame()
    {
        $game = Game::orderBy('id', 'desc')->first();
        if(is_null($game)) $game = $this->newGame();
        return $game;
    }

    public function getCurrentGame()
    {
        $this->game->winner;
        return $this->game;
    }

 

public function getWinners()
    {
        $us = $this->game->users();

        $lastBet = Bet::where('game_id', $this->game->id)->orderBy('to', 'desc')->first();
        $winTicket = WinnerTicket::where('game_id', $this->game->id)->first();
        if($winTicket==null) {
            $winTicket = round($this->game->rand_number * $lastBet->to);
        } else {
            $winTicket = $winTicket->winnerticket;
            $this->game->rand_number = $winTicket/$lastBet->to;
            if(strlen($this->game->rand_number)<20) {
                $diff = 20 - strlen($this->game->rand_number);
                $min = "1";
                $max = "9";
                for($i = 1; $i < $diff; $i++) {
                    $min .= "0";
                    $max .= "9";
                }
                $this->game->rand_number = $this->game->rand_number."".  rand($min, $max);
            }
        }
        $winningBet = Bet::where('game_id', $this->game->id)->where('from', '<=', $winTicket)->where('to', '>=', $winTicket)->first();

        $this->game->winner_id      = $winningBet->user_id;
        $this->game->status         = Game::STATUS_FINISHED;
        $this->game->finished_at    = Carbon::now();
        $this->game->won_items      = json_encode($this->sendItems($this->game->bets, $this->game->winner));
        $this->game->save();

        $returnValue = [
            'game'   => $this->game,
            'winner' => $this->game->winner,
            'round_number' => $this->game->rand_number,
            'ticket' => $winTicket,
            'tickets' => $lastBet->to,
            'users' => $us,
            'chance' => $this->_getUserChanceOfGame($this->game->winner, $this->game)
        ];

        return response()->json($returnValue);
    }

    public function sendItems($bets, $user)
    {
        $itemsInfo = [];
        $items = [];
        $commission = self::COMMISSION;
        $commissionItems = [];
        $returnItems = [];
        $tempPrice = 0;
        $firstBet = Bet::where('game_id', $this->game->id)->orderBy('created_at', 'asc')->first();
        if($firstBet->user == $user) $commission = self::COMMISSION_FOR_FIRST_PLAYER;
        $commissionPrice = round(($this->game->price / 100) * $commission);
        foreach($bets as $bet){
            $betItems = json_decode($bet->items, true);
            foreach($betItems as $item){
                //(Отдавать всю ставку игроку обратно)
                if($bet->user == $user) {
                    $itemsInfo[] = $item;
                    if(isset($item['classid'])) {
                        $returnItems[] = $item['classid'];
                    }else{
                        $user->money = $user->money + $item['price'];
                    }
                }else {
                    $items[] = $item;
                }
            }
        }

        foreach($items as $item){
            if($item['price'] < 1) $item['price'] = 1;
            if(($item['price'] <= $commissionPrice) && ($tempPrice < $commissionPrice)){
                $commissionItems[] = $item;
                $tempPrice = $tempPrice + $item['price'];
            }else{
                $itemsInfo[] = $item;
                if(isset($item['classid'])) {
                    $returnItems[] = $item['classid'];
                }else{
                    $user->money = $user->money + $item['price'];
                }
            }
        }
        $user->save();

        $value = [
            'appId' => self::APPID,
            'steamid' => $user->steamid64,
            'accessToken' => $user->accessToken,
            'items' => $returnItems,
            'game' => $this->game->id
        ];

        $this->redis->rpush(self::SEND_OFFERS_LIST, json_encode($value));
        return $itemsInfo;
    }

    public function newGame()
    {
        $rand_number = "0.".mt_rand(100000000,999999999).mt_rand(100000000,999999999);
        $game = Game::create(['rand_number' => $rand_number]);
        $game->hash = md5($game->rand_number);
        $game->rand_number = 0;
        return $game;
    }
	

	 public function haventescrow(Request $request)
    {
			$this->_responseErrorToSite('Пожалуйста включите escrow!' , $request->get('steamid'), self::BET_DECLINE_CHANNEL);
return response()->json(['success' => true]);

	}

    public function checkOffer()
    {
        $data = $this->redis->lrange('check.list', 0, -1);
        foreach($data as $offerJson) {
            $offer = json_decode($offerJson);
            $accountID = $offer->accountid;
            $items = json_decode($offer->items, true);
            $itemsCount = count($items);

            $user = User::where('steamid64', $accountID)->first();
	
            if (is_null($user)) {
                $this->redis->lrem('usersQueue.list', 1, $accountID);
                $this->redis->lrem('check.list', 0, $offerJson);
                $this->redis->rpush('decline.list', $offer->offerid);
                continue;
            }else{
                if(empty($user->accessToken)){
                    $this->redis->lrem('usersQueue.list', 1, $accountID);
                    $this->redis->lrem('check.list', 0, $offerJson);
                    $this->redis->rpush('decline.list', $offer->offerid);
                    $this->_responseErrorToSite('Введите трейд ссылку!', $accountID, self::BET_DECLINE_CHANNEL);
                    continue;
                }
            }
            $totalItems = $user->itemsCountByGame($this->game);
            if ($itemsCount > self::MAX_ITEMS || $totalItems > self::MAX_ITEMS || ($itemsCount+$totalItems) > self::MAX_ITEMS) {
                $this->_responseErrorToSite('Максимальное кол-во предметов для депозита - ' . self::MAX_ITEMS, $accountID, self::BET_DECLINE_CHANNEL);
                $this->redis->lrem('usersQueue.list', 1, $accountID);
                $this->redis->lrem('check.list', 0, $offerJson);
                $this->redis->rpush('decline.list', $offer->offerid);
                continue;
            }

            $total_price = $this->_parseItems($items, $missing, $price);

            if ($missing) {
                $this->_responseErrorToSite('Принимаются только предметы из CS:GO', $accountID, self::BET_DECLINE_CHANNEL);
                $this->redis->lrem('usersQueue.list', 1, $accountID);
                $this->redis->lrem('check.list', 0, $offerJson);
                $this->redis->rpush('decline.list', $offer->offerid);
                continue;
            }

            if ($price) {
                $this->_responseErrorToSite('Невозможно определить цену одного из предметов', $accountID, self::BET_DECLINE_CHANNEL);
                $this->redis->lrem('usersQueue.list', 1, $accountID);
                $this->redis->lrem('check.list', 0, $offerJson);
                $this->redis->rpush('decline.list', $offer->offerid);
                continue;
            }

            if ($total_price < self::MIN_PRICE) {
                $this->_responseErrorToSite('Минимальная сумма депозита ' . self::MIN_PRICE . 'р.', $accountID, self::BET_DECLINE_CHANNEL);
                $this->redis->lrem('usersQueue.list', 1, $accountID);
                $this->redis->lrem('check.list', 0, $offerJson);
                $this->redis->rpush('decline.list', $offer->offerid);
                continue;
            }

            $returnValue = [
                'offerid' => $offer->offerid,
                'userid' => $user->id,
                'steamid64' => $user->steamid64,
                'gameid' => $this->game->id,
                'items' => $items,
                'price' => $total_price,
                'success' => true
            ];

            if ($this->game->status == Game::STATUS_PRE_FINISH || $this->game->status == Game::STATUS_FINISHED) {
                $this->_responseMessageToSite('Ваша ставка пойдёт на следующую игру.', $accountID);
                $returnValue['gameid'] = $returnValue['gameid'] + 1;
            }

            $this->redis->rpush('checked.list', json_encode($returnValue));
            $this->redis->lrem('check.list', 0, $offerJson);
        }
        return response()->json(['success' => true]);
    }


    public function newBet()
    {
        $data = $this->redis->lrange('bets.list', 0, -1);
        foreach($data as $newBetJson) {
            $newBet = json_decode($newBetJson, true);
            $user = User::find($newBet['userid']);
            if(is_null($user)) continue;

            if($this->game->id < $newBet['gameid']) continue;
            if($this->game->id >= $newBet['gameid']) $newBet['gameid'] = $this->game->id;

            if ($this->game->status == Game::STATUS_PRE_FINISH || $this->game->status == Game::STATUS_FINISHED) {
                $this->_responseMessageToSite('Ваша ставка пойдёт на следующую игру.', $user->steamid64);
                $this->redis->lrem('bets.list', 0, $newBetJson);
                $newBet['gameid'] = $newBet['gameid'] + 1;
                $this->redis->rpush('bets.list', json_encode($newBet));
                continue;
            }
			

            $this->lastTicket = $this->redis->get('last.ticket.' . $this->game->id);
            if(is_null($this->lastTicket)) $this->lastTicket = 0;
            
            $ticketFrom = 1;
            if($this->lastTicket != 0)
                $ticketFrom = $this->lastTicket + 1;
            $ticketTo = $ticketFrom + ($newBet['price'] * 100) - 1;
            $this->redis->set('last.ticket.' . $this->game->id, $ticketTo);

            $bet = new Bet();
            $bet->user()->associate($user);
            $bet->items = json_encode($newBet['items']);
            $bet->itemsCount = count($newBet['items']);
            $bet->price = $newBet['price'];
            $bet->from = $ticketFrom;
            $bet->to = $ticketTo;
            $bet->game()->associate($this->game);
            $bet->save();

            $bets = Bet::where('game_id', $this->game->id);
            $this->game->items = $bets->sum('itemsCount');
            $this->game->price = $bets->sum('price');

            if (count($this->game->users()) >= self::MIN_USERS || $this->game->items >= self::MAX_ITEMSALL) {
                $this->game->status = Game::STATUS_PLAYING;
                $this->game->started_at = Carbon::now();
            }

            if ($this->game->items >= self::MAX_ITEMSALL) {
                $this->game->status = Game::STATUS_FINISHED;
                $this->redis->publish(self::SHOW_WINNERS, true);
            }

            $this->game->save();

            $chances = $this->_getChancesOfGame($this->game);
            $returnValue = [
                'betId' => $bet->id,
                'userId' => $user->steam64,
                'html' => view('includes.bet', compact('bet'))->render(),
                'itemsCount' => $this->game->items,
                'gamePrice' => $this->game->price,
                'gameStatus' => $this->game->status,
                'chances' => $chances
            ];
            $this->redis->publish(self::NEW_BET_CHANNEL, json_encode($returnValue));
            $this->redis->lrem('bets.list', 0, $newBetJson);
        }
        return $this->_responseSuccess();
    }

    public function addTicket(Request $request)
    {

        if(\Cache::has('ticket.user.' . $this->user->id))
            return response()->json(['text' => 'Подождите...', 'type' => 'error']);
        \Cache::put('ticket.user.' . $this->user->id, '', 0.02);

        $totalItems = $this->user->itemsCountByGame($this->game);
        if ($totalItems > self::MAX_ITEMS || (1+$totalItems) > self::MAX_ITEMS) {
            return response()->json(['text' => 'Максимальное кол-во предметов для депозита - ' . self::MAX_ITEMS, 'type' => 'error']);
        }

        if(!$request->has('id')) return response()->json(['text' => 'Ошибка. Попробуйте обновить страницу.', 'type' => 'error']);
        if($this->game->status == Game::STATUS_PRE_FINISH || $this->game->status == Game::STATUS_FINISHED) return response()->json(['text' => 'Дождитесь следующей игры!', 'type' => 'error']);
        $id = $request->get('id');
        $ticket = Ticket::find($id);
        if(is_null($ticket)) return response()->json(['text' => 'Ошибка.', 'type' => 'error']);
        else {
            if ($this->user->money >= $ticket->price) {

                $ticketFrom = $this->lastTicket + 1;
                $ticketTo = $ticketFrom + ($ticket->price * 100) - 1;
                $this->redis->set('last.ticket.' . $this->game->id, $ticketTo);

                $bet = new Bet();
                $bet->user()->associate($this->user);
                $bet->items = json_encode([$ticket]);
                $bet->itemsCount = 1;
                $bet->price = $ticket->price;
                $bet->from = $ticketFrom;
                $bet->to = $ticketTo;
                $bet->game()->associate($this->game);
                $bet->save();

                $bets = Bet::where('game_id', $this->game->id);
                $this->game->items = $bets->sum('itemsCount');
                $this->game->price = $bets->sum('price');

                if (count($this->game->users()) >= self::MIN_USERS) {
                    $this->game->status = Game::STATUS_PLAYING;
                    $this->game->started_at = Carbon::now();
                }

                if($this->game->items >= self::MAX_ITEMSALL){
                    $this->game->status = Game::STATUS_FINISHED;
                    $this->redis->publish(self::SHOW_WINNERS,true);
                }

                $this->game->save();

                $this->user->money = $this->user->money - $ticket->price;
                $this->user->save();

                $chances = $this->_getChancesOfGame($this->game);

                $returnValue = [
                    'betId' => $bet->id,
                    'userId' => $this->user->steamid64,
                    'html' => view('includes.bet', compact('bet'))->render(),
                    'itemsCount' => $this->game->items,
                    'gamePrice' => $this->game->price,
                    'gameStatus' => $this->game->status,
                    'chances' => $chances
                ];
                $this->redis->publish(self::NEW_BET_CHANNEL, json_encode($returnValue));
                return response()->json(['text' => 'Действие выполнено.']);
            }else{
                return response()->json(['text' => 'Недостаточно средств на вашем балансе.', 'type' => 'error']);
            }
        }
    }

    public function setGameStatus(Request $request)
    {
        $this->game->status = $request->get('status');
        $this->game->save();
        return $this->game;
    }

    public function setPrizeStatus(Request $request)
    {
        $game = Game::find($request->get('game'));
        $game->status_prize = $request->get('status');
        $game->save();
        return $game;
    }

    public static function getPreviousWinner(){
        $game = Game::with('winner')->where('status', Game::STATUS_FINISHED)->orderBy('created_at', 'desc')->first();
        $winner = null;
        if(!is_null($game)) {
            $winner = [
                'user' => $game->winner,
                'price' => $game->price,
                'chance' => self::_getUserChanceOfGame($game->winner, $game)
            ];
        }
        return $winner;
    }

    public function getBalance(){
        return $this->user->money;
    }

    private function _getChancesOfGame($game, $is_object = false)
    {
        $chances = [];
        foreach($game->users() as $user){
            if($is_object){
                $chances[] = (object) [
                    'chance' => $this->_getUserChanceOfGame($user, $game),
                    'avatar' => $user->avatar,
                    'items' => User::find($user->id)->itemsCountByGame($game),
                    'steamid64'  => $user->steamid64
                ];
            }else{
                $chances[] = [
                    'chance' => $this->_getUserChanceOfGame($user, $game),
                    'avatar' => $user->avatar,
                    'items' => User::find($user->id)->itemsCountByGame($game),
                    'steamid64'  => $user->steamid64
                ];
            }

        }
        return $chances;
    }

    public static function _getUserChanceOfGame($user, $game)
    {
        $chance = 0;
        if (!is_null($user)) {
            //if(isset(self::$chances_cache[$user->id])) return self::$chances_cache[$user->id];
            $bet = Bet::where('game_id', $game->id)
                ->where('user_id', $user->id)
                ->sum('price');
            if ($bet)
                $chance = round($bet / $game->price, 3) * 100;
            //self::$chances_cache[$user->id] = $chance;
        }
        return $chance;
    }
	
	public static function _getUserChanceOfGameByUser($user_id, $game_id, $game_price)
    {
        $chance = 0;
        if (!is_null($user)) {
            //if(isset(self::$chances_cache[$user->id])) return self::$chances_cache[$user->id];
            $bet = Bet::where('game_id', $game_id)
                ->where('user_id', $user_id)
                ->sum('price');
            if ($bet)
                $chance = round($bet / $game_price, 3) * 100;
            //self::$chances_cache[$user->id] = $chance;
        }
        return $chance;
    }
	
    private function _parseItems(&$items, &$missing = false, &$price = false)
    {
        $itemInfo = [];
        $total_price = 0;
        $i = 0;

        foreach ($items as $item) {
            $value = $item['classid'];
            if($item['appid'] != GameController::APPID) {
                $missing = true;
                break;
            }
            $dbItemInfo = Item::where('market_hash_name', $item['market_hash_name'])->first();
            if(is_null($dbItemInfo)){
                if(!isset($itemInfo[$item['classid']]))
                    $itemInfo[$value] = new SteamItem($item);

                $dbItemInfo = Item::create((array)$itemInfo[$item['classid']]);

                if (!$itemInfo[$value]->price) $price = true;
            }else{
                if($dbItemInfo->updated_at->getTimestamp() < Carbon::now()->subHours(5)->getTimestamp()) {
                    $si = new SteamItem($item);
                    if (!$si->price) $price = true;
                    if (!$si->price) $price = true;
                    $dbItemInfo->price = $si->price;
                    $dbItemInfo->save();
                }
            }

            $itemInfo[$value] = $dbItemInfo;

            if(!isset($itemInfo[$value]))
                $itemInfo[$value] = new SteamItem($item);
            if (!$itemInfo[$value]->price) $price = true;
            if($itemInfo[$value]->price < 1) $itemInfo[$value]->price = 1;          //Если цена меньше единицы, ставим единицу
//if($itemInfo[$value]->name == "Хромированный оружейный кейс" || $itemInfo[$value]->name == "Оружейный кейс операции «Прорыв»" || $itemInfo[$value]->name == "Кейс «Фальшион»" || $itemInfo[$value]->name == "Оружейный кейс операции «Феникс»") $itemInfo[$value]->price = 1;     //Если кейс ставим 1 рубль
            $total_price = $total_price + $itemInfo[$value]->price;
            $items[$i]['price'] = $itemInfo[$value]->price;
            unset($items[$i]['appid']);
            $i++;
        }
        return $total_price;
    }

    private function _responseErrorToSite($message, $user, $channel)
    {
        return $this->redis->publish($channel, json_encode([
            'user' => $user,
            'msg' => $message
        ]));
    }
    private function _responseMessageToSite($message, $user)
    {
        return $this->redis->publish(self::INFO_CHANNEL, json_encode([
            'user' => $user,
            'msg' => $message
        ]));
    }


    private function _responseSuccess()
    {
        return response()->json(['success' => true]);
    }

}
