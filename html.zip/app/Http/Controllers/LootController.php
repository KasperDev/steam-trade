<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Carbon\Carbon;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\User;
use App\Item;
use App\Loot;
use App\Lots;
use App\Services\SteamItem;
use App\Services\RandomOrgClient;
class LootController extends Controller
{
	
	
	const NEW_ITEMS_CHANNEL = 'items.to.newloot';
   // const GIVE_ITEMS_CHANNEL = 'items.to.giveloot';
   const GIVE_ITEMS_CHANNEL = 'items.to.give';
	const WINNER__CHANNEL = 'show.lootwinners';
    const STATUS_PLAYING = 0;
    const STATUS_FINISHED = 1;
	
	
	   public function setLootStatus(Request $request)
    {
        $Loot = Loot::find($request->get('id'));
        if(!is_null($Loot)){
            $Loot->status = $request->get('status');
            $Loot->save();
            return $Loot;
        }
        return response()->json(['success' => false]);
    }
	
	 
	  public function newloot(Request $request)
    {
		
		//  if(\DB::table('lootgames')->where('name', "Тест")->where('status',0)->count() == 0){
		
		//$returnValue = '[{"inventoryId":"0","classid":"7","name":"Тест","market_hash_name":"Test","rarity":"Тайное","quality":"Прямо с fastloot )","type":"Прямо с fastloot )"}]';
		//  $this->redis->rpush(self::NEW_ITEMS_CHANNEL, $returnValue);}
		$jsonItems = $this->redis->lrange(self::NEW_ITEMS_CHANNEL, 0, -1);
        foreach($jsonItems as $jsonItem){
            $items = json_decode($jsonItem, true);
            foreach($items as $item) {
                $dbItemInfo = Item::where('market_hash_name', $item['market_hash_name'])->first();
				
		/*	if($item['classid'] == 7){
	 

                    $item['steam_price'] =0;
                    $item['price'] = 0;
					$item['maxuser'] = 10; 
	Loot::create($item);
 }
                else */ 
				if (is_null($dbItemInfo)) {
                    $itemInfo = new SteamItem($item);
					$max = rand(100,200); 
                    $item['steam_price'] = $itemInfo->price;
                    $item['price'] = round($item['steam_price']/$max+rand(1,10));
					$item['maxuser'] = $max ; 
					Loot::create($item);
 }
 else{
	 $max = rand(100,200); 
                    $item['steam_price'] = $dbItemInfo->price;
                    $item['price'] = round($item['steam_price']/$max+rand(1,10));
					$item['maxuser'] = $max; 
	Loot::create($item);
 }
				
            }
            $this->redis->lrem(self::NEW_ITEMS_CHANNEL, 1, $jsonItem);
        }
        return response()->json(['success' => true]);

    }
	
	
	 public function resetloottest(Request $request)
    { 
	
	$lot = Loot::find(1);
	
	$lot->users = 0;

 $lot->randomorg_result = 0;
 $lot->randomorg_sign = 0;
  $lot->winner_id = 0;
 $lot->status = 0;

	
		$lot->user_id = 0;
	
$lot->save();

\DB::table('loot')->where('game_id', '=', 1)->delete();
 
  return response()->json([ 'success' => 'true', 'reason' => 'ok']);	
  
	}
	


	
	 public function addplaceloot(Request $request)
    { 
sleep(0.06);
$place = $request->get('place');
$lootId = $request->get('game_id');

if(Lots::where(['to' => $place, 'game_id' => $lootId])->first()) return response()->json([ 'success' => 'false', 'reason' => 'placexm']);
$lot = Loot::find($lootId);
if($place > $lot->maxuser)  return response()->json([ 'success' => 'false', 'reason' => 'placexmx']);	
if($lot->users > $lot->maxuser)  return response()->json([ 'success' => 'false', 'reason' => 'placexmx']);	
if(!isset($place) && !isset($lootId)) return response()->json([ 'success' => 'false', 'reason' => 'placeandgame']);
if($this->user->money < $lot->price) return response()->json([ 'success' => 'false', 'reason' => 'nomoney']);	
$lot->users += 1;
$lot->save();  
$user = User::find($this->user->id);
$user->money -= $lot->price;
$user->save(); 
$lots = new Lots;
$lots->to = $place;
$lots->user_id = $user->id;
$lots->game_id = $lootId;
$lots->save();

if($lot->status == 0 && $lot->users == $lot->maxuser){
$random = new RandomOrgClient();
$arrRandomInt = $random->generateIntegers(1, 1, $lot->maxuser, $lot);
$lot->randomorg_result = json_encode($random->last_response['result']['random']);
$lot->randomorg_sign = $random->last_response['result']['signature'];
$lot->winner_id = $arrRandomInt[0];
$lot->status = 1;
$this->sendItem($lot);
foreach(Lots::where('game_id', '=', $lootId)->where('to',$arrRandomInt[0])->get() as $winner){$lot->user_id = $winner->user_id;}
$lot->save();
}
return response()->json([ 'success' => 'true', 'reason' => 'ok']);	
}

 public function sendItem($item)
    {
        $value = [
            'id' => $item->id,
            'itemId' => $item->inventoryId,
            'partnerSteamId' => $this->user->steamid64,
            'accessToken' => $this->user->accessToken,
        ];

        $this->redis->rpush(self::GIVE_ITEMS_CHANNEL, json_encode($value));
    }
	
	
		public function getlootuser($lootId){
			$loots = Lots::where('game_id', '=', $lootId)->get();	

		//	
			$poisk = Lots::where('game_id', '=', $lootId)->where('user_id', '=', $this->user->id)->count();
			
		
			
			  $mez = null;
			  if(!is_null($poisk)) {
				  
				  $mez = $poisk;
			  }
			
			$i = 0; 
			
			
			
			  $users = null;
			  

		
  
			foreach($loots as $loot[$i]){
				
				
				
			
				
				  
        if(!is_null($loots)) {
			$user[$i] = User::find($loot[$i]->user_id);
            $users[$i] = [
                'user_id' => $loot[$i]->user_id,
                'username' => 0,
				'to' => $loot[$i]->to,
				'avatar' => $user[$i]->avatar,
				'username' => $user[$i]->username,
				'steamid64' => $user[$i]->steamid64,
				'mez' => $mez,
				'random' => 5
            ];
        }
		
		$i++;
		
				}
				
			
			
        return $users;
			

				
				
				
			
		}
	
	
    public function getloot($lootId)
	{
		$loots = Loot::where('id', '=', $lootId)->get();	
		
		foreach($loots as $loot){
			
			if($loot->winner_id != 0){ 
			
			$user = User::find($loot->user_id);
	$loot->winner = $user->username;
$loot->winnerava = $user->avatar;
$loot->winnersteam64 = $user->steamid64;
			}
			return $loot;
		}	

	}	
	
	
	    public function lootgame($lootId)
    {
		
		
        if(isset($lootId) &&  \DB::table('lootgames')->where('id', $lootId)->count()){
$loots = Loot::where('id', '=', $lootId)->get();		
foreach($loots as $loot){
	
	
if($loot->winner_id == 0){ $winner = 0;}else{

$user = User::find($loot->user_id);
	$winner = $user->username;
$winnerava = $user->avatar;
$winnersteam64 = $user->steamid64;
}	
	
	
	
}




$lots = [];
        foreach(Lots::where('game_id', '=', $lootId)->get() as $l)
        {
           $user = User::find($l->user_id);
            $lots[$l->to] = ['name' => $user->username, 'id' => $user->steamid64, 'avatar' => $user->avatar];
        }
if(!\Auth::guest()){$mez = Lots::where('game_id', '=', $lootId)->where('user_id', '=', $this->user->id)->count();}else {$mez = 0;}

return view('pages.lootgame', compact('loots','lots','mez','winner'));
        }
      return redirect()->route('index');
    }
		
public function listloot(Request $request)
{
$loots = \DB::table('lootgames')->where('status',0)->orderBy('id', 'steam_price')->get();
return view('pages.listloot', compact('loots'));
}
public function historyloots(Request $request)
{
$loots = \DB::table('lootgames')->where('status',1)->join('users', 'lootgames.user_id', '=', 'users.id') 
->select('lootgames.*', 'users.username as winner_username', 'users.steamid64 as winner_steamid64','users.avatar as winner_avatar')

->orderBy('id', 'steam_price')->get();

return view('pages.historyloot', compact('loots'));
}

public function myhistoryloots(Request $request)
{
$loots = \DB::table('lootgames')->join('loot', function($join){
                $join->on('lootgames.id', '=', 'loot.game_id')
                    ->where('loot.user_id', '=', $this->user->id);
            })->join('users', 'lootgames.user_id', '=', 'users.id') ->groupBy('lootgames.id')
            ->orderBy('lootgames.id', 'desc')
->select('lootgames.*', 'users.username as winner_username', 'users.steamid64 as winner_steamid64','users.avatar as winner_avatar')

->orderBy('id', 'steam_price')->get();

return view('pages.myhistoryloot', compact('loots'));
}
   
}