<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Carbon\Carbon;
use App\Http\Requests;
use App\Http\Controllers\Controller;
class online extends Controller
{
	
	 public function onlineadd(Request $request)
{
	
	session_start();
$session=$_SERVER['REMOTE_ADDR'];
$time=Carbon::now()->getTimestamp();
$time_check=$time-600;
$users = \DB::table('user_status_online')->where('session', $session)->count();
$count= $users;
if($count=="0"){
\DB::table('user_status_online')->insert(['session' => $session,'time' => $time]);
}
else {
\DB::table('user_status_online')->where('session', $session)->update(['time' => $time]);
}
\DB::table('user_status_online')->where('time', '<', $time_check)->delete();
}
	
	
 public function online(Request $request)
{

return $users = \DB::table('user_status_online')->count();
}




}
