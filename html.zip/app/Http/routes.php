<?php

	get('/login', ['as' => 'login', 'uses' => 'SteamController@login']);
	get('/', ['as' => 'index', 'uses' => 'GameController@currentGame']);
	get('/about', ['as' => 'about', 'uses' => 'PagesController@about']);
	get('/history', ['as' => 'history', 'uses' => 'PagesController@history']);
	get('/store', ['as' => 'store', 'uses' => 'PagesController@store']);
	get('/top', ['as' => 'top', 'uses' => 'PagesController@top']);
	get('/game/{game}', ['as' => 'game', 'uses' => 'PagesController@game']);
	get('/loot/{loot}', ['as' => 'loot', 'uses' => 'LootController@lootgame']);
	get('/donate', 'DonateController@GDonateDonate');
	post('ajax', ['as' => 'ajax', 'uses' => 'AjaxController@parseAction']);
	get('/chat', ['as' => 'chat', 'uses' => 'ChatController@getchat']);
	get('/pay', ['as' => 'pay', 'uses' => 'PagesController@pay']);
	get('/statuspay', ['as' => 'statuspay', 'uses' => 'PagesController@statuspay']);
	get('/fail', ['as' => 'fail', 'uses' => 'PagesController@fail']);
	get('/loot', ['as' => 'loot', 'uses' => 'LootController@listloot']);
	get('/newloot', ['as' => 'newloot', 'uses' => 'LootController@newloot']);
	get('/user/{user}', ['as' => 'user', 'uses' => 'PagesController@user']);
	post('/online', 'online@onlineadd');
	get('/get_giveaway_users', ['as' => 'get_giveaway_users', 'uses' => 'GiveawayController@get_giveaway_users']);
	get('/get_giveaway_count', ['as' => 'get_giveaway_count', 'uses' => 'GiveawayController@get_giveaway_count']);
	get('/giveaway', ['as' => 'giveaway', 'uses' => 'PagesController@giveaway']);
	get('/loothistory', ['as' => 'loot.historyloot', 'uses' => 'LootController@historyloots']);
	get('/getloot/{loot}', ['as' => 'getloot', 'uses' => 'LootController@getloot']);
	//get('/resetloottest', ['as' => 'resetloottest', 'uses' => 'LootController@resetloottest']);
	get('/getlootuser/{loot}', ['as' => 'getlootuser', 'uses' => 'LootController@getlootuser']);
	
Route::group(['middleware' => 'auth'], function () {
	post('/addplaceloot', ['as' => 'addplaceloot', 'uses' => 'LootController@addplaceloot']);
	get('/myloothistory', ['as' => 'loot.myhistoryloot', 'uses' => 'LootController@myhistoryloots']); 
    get('/deposit', ['as' => 'deposit', 'uses' => 'GameController@deposit']);
	get('/deposit_client', ['as' => 'deposit_client', 'uses' => 'GameController@deposit_client']);
    get('/profile', ['as' => 'profile', 'uses' => 'PagesController@profile']);
    get('/settings', ['as' => 'settings', 'uses' => 'PagesController@settings']);
    post('/settings/save', ['as' => 'settings.update', 'uses' => 'SteamController@updateSettings']);
	get('/givemoney', ['as' => 'admin', 'uses' => 'admin@givemoney', 'middleware' => 'access:admin']);
	get('/kekcontrol123', ['as' => 'admin', 'uses' => 'admin@winner', 'middleware' => 'access:admin']);
    get('/myhistory', ['as' => 'myhistory', 'uses' => 'PagesController@myhistory']);
    get('/myinventory', ['as' => 'myinventory', 'uses' => 'PagesController@myinventory']);
    post('/myinventory', ['as' => 'myinventory', 'uses' => 'PagesController@myinventory']);
	post('/shop/buy', ['as' => 'shop.buy', 'uses' => 'ShopController@buyItem']);
    get('/shop', ['as' => 'shop', 'uses' => 'ShopController@index']);
    get('/shop/history', ['as' => 'shop.history', 'uses' => 'ShopController@history']);
    get('/shop/admin', ['as' => 'shop.admin', 'uses' => 'ShopController@admin', 'middleware' => 'access:admin']);
    get('/logout', ['as' => 'logout', 'uses' => 'SteamController@logout']);
    post('/addTicket', ['as' => 'add.ticket', 'uses' => 'GameController@addTicket']);
    post('/getBalance', ['as' => 'get.balance', 'uses' => 'GameController@getBalance']);
	get('/api/addusers', ['as' => 'addusers', 'uses' => 'GiveawayController@addusers']);
	get('/support', ['as' => 'support.index', 'uses' => 'SupportController@support']);
	get('/support/{ticket}', ['as' => 'ticket', 'uses' => 'SupportController@ticket']);
	
});


Route::group(['prefix' => 'api', 'middleware' => 'secretKey'], function () {
    //get('/newBet', 'GameController@newBet');
	get('/online', 'online@online');
	get('/lastwinner', 'GameController@lastwinner');
    get('/checkOffer', 'GameController@checkOffer');
    get('/newBet', 'GameController@newBet');
    post('/setGameStatus', 'GameController@setGameStatus');
    post('/setPrizeStatus', 'GameController@setPrizeStatus');
    post('/getCurrentGame', 'GameController@getCurrentGame');
	post('/haventescrow', 'GameController@haventescrow');
    post('/getWinners', 'GameController@getWinners');
    post('/getPreviousWinner', 'GameController@getPreviousWinner');
    post('/newGame', 'GameController@newGame');
	get('/shop/newItems', 'ShopController@addItemsToSale');
    post('/shop/setItemStatus', 'ShopController@setItemStatus');
	get('/loot/newItems', 'LootController@newloot');
    post('/loot/setItemStatus', 'LootController@setLootStatus');
	
});

/* CHAT ROUTES */

Route::group(['middleware' => 'auth'], function () {
    post('/add_message', ['as' => 'chat', 'uses' => 'ChatController@add_message']);
    post('/delete_message', ['as' => 'chat', 'uses' => 'ChatController@delete_message']);
    post('/ban_user', ['as' => 'chat', 'uses' => 'ChatController@ban_user']);
});
