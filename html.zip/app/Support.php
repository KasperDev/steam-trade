<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Support extends Model
{
    protected $table = 'supmessages';

    public $timestamps = false;

    protected $fillable = ['user_id','messages', 'date','admin','ticket'];


}
