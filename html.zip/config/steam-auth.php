<?php

return [

    /*
     * Redirect url after login
     */
    'redirect_url' => '/login',

    'api_key' => 'A136CB9F3C612C5EAD491B62C4A758FA'

];