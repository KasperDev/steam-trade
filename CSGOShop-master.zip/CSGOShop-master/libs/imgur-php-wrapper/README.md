Imgur API PHP Wrapper 0.1
=========================
Easy to use php wrapper for imgur API. You can see example usages in examples.php

Feel free to fork and contribute to the project.

Notes
=====
This is a work in progress. There might be bugs.

Changelog
=========
0.1 Initial release
