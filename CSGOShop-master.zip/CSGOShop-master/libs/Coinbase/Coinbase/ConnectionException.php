<?php

class Coinbase_ConnectionException extends Coinbase_Exception
{
}
