CSGOShop
========

A Open-Source CS:GO Marketplace

###What is CSGOShop?

CSGOShop is a marketplace for Counter-Strike:Global Offensive founded by Matty.

###Why is this code Open-Source ?

Our servers were breached the 4th of September and because of this and other things we decided to release it as a open-source platform instead.

###Where is the bot code?

Here: https://github.com/ohMatty/CSGOShop-Steambot
