<?php
require_once './libs/CSGOShop.class.php';
$app = new CSGOShop(true);
